
try {
  new Function("import('/racelandshopfiles/frontend/main-0b50267d.js')")();
} catch (err) {
  var el = document.createElement('script');
  el.src = '/racelandshopfiles/frontend/main-0b50267d.js';
  document.body.appendChild(el);
}
  
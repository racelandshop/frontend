function e(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}function t(e){return(t=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)})(e)}function r(e,i,o){return(r="undefined"!=typeof Reflect&&Reflect.get?Reflect.get:function(e,r,i){var o=function(e,r){for(;!Object.prototype.hasOwnProperty.call(e,r)&&null!==(e=t(e)););return e}(e,r);if(o){var n=Object.getOwnPropertyDescriptor(o,r);return n.get?n.get.call(i):n.value}})(e,i,o||e)}function i(e){return function(e){if(Array.isArray(e))return e}(e)||function(e){if("undefined"!=typeof Symbol&&null!=e[Symbol.iterator]||null!=e["@@iterator"])return Array.from(e)}(e)||function(e,t){if(!e)return;if("string"==typeof e)return o(e,t);var r=Object.prototype.toString.call(e).slice(8,-1);"Object"===r&&e.constructor&&(r=e.constructor.name);if("Map"===r||"Set"===r)return Array.from(e);if("Arguments"===r||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r))return o(e,t)}(e)||function(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function o(e,t){(null==t||t>e.length)&&(t=e.length);for(var r=0,i=new Array(t);r<t;r++)i[r]=e[r];return i}function n(e){var t=function(e,t){if("object"!=typeof e||null===e)return e;var r=e[Symbol.toPrimitive];if(void 0!==r){var i=r.call(e,t||"default");if("object"!=typeof i)return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(e,"string");return"symbol"==typeof t?t:String(t)}function a(e,t,r,o){var a=function(){(function(){return e});var e={elementsDefinitionOrder:[["method"],["field"]],initializeInstanceElements:function(e,t){["method","field"].forEach((function(r){t.forEach((function(t){t.kind===r&&"own"===t.placement&&this.defineClassElement(e,t)}),this)}),this)},initializeClassElements:function(e,t){var r=e.prototype;["method","field"].forEach((function(i){t.forEach((function(t){var o=t.placement;if(t.kind===i&&("static"===o||"prototype"===o)){var n="static"===o?e:r;this.defineClassElement(n,t)}}),this)}),this)},defineClassElement:function(e,t){var r=t.descriptor;if("field"===t.kind){var i=t.initializer;r={enumerable:r.enumerable,writable:r.writable,configurable:r.configurable,value:void 0===i?void 0:i.call(e)}}Object.defineProperty(e,t.key,r)},decorateClass:function(e,t){var r=[],i=[],o={static:[],prototype:[],own:[]};if(e.forEach((function(e){this.addElementPlacement(e,o)}),this),e.forEach((function(e){if(!c(e))return r.push(e);var t=this.decorateElement(e,o);r.push(t.element),r.push.apply(r,t.extras),i.push.apply(i,t.finishers)}),this),!t)return{elements:r,finishers:i};var n=this.decorateConstructor(r,t);return i.push.apply(i,n.finishers),n.finishers=i,n},addElementPlacement:function(e,t,r){var i=t[e.placement];if(!r&&-1!==i.indexOf(e.key))throw new TypeError("Duplicated element ("+e.key+")");i.push(e.key)},decorateElement:function(e,t){for(var r=[],i=[],o=e.decorators,n=o.length-1;n>=0;n--){var a=t[e.placement];a.splice(a.indexOf(e.key),1);var s=this.fromElementDescriptor(e),l=this.toElementFinisherExtras((0,o[n])(s)||s);e=l.element,this.addElementPlacement(e,t),l.finisher&&i.push(l.finisher);var c=l.extras;if(c){for(var d=0;d<c.length;d++)this.addElementPlacement(c[d],t);r.push.apply(r,c)}}return{element:e,finishers:i,extras:r}},decorateConstructor:function(e,t){for(var r=[],i=t.length-1;i>=0;i--){var o=this.fromClassDescriptor(e),n=this.toClassDescriptor((0,t[i])(o)||o);if(void 0!==n.finisher&&r.push(n.finisher),void 0!==n.elements){e=n.elements;for(var a=0;a<e.length-1;a++)for(var s=a+1;s<e.length;s++)if(e[a].key===e[s].key&&e[a].placement===e[s].placement)throw new TypeError("Duplicated element ("+e[a].key+")")}}return{elements:e,finishers:r}},fromElementDescriptor:function(e){var t={kind:e.kind,key:e.key,placement:e.placement,descriptor:e.descriptor};return Object.defineProperty(t,Symbol.toStringTag,{value:"Descriptor",configurable:!0}),"field"===e.kind&&(t.initializer=e.initializer),t},toElementDescriptors:function(e){if(void 0!==e)return i(e).map((function(e){var t=this.toElementDescriptor(e);return this.disallowProperty(e,"finisher","An element descriptor"),this.disallowProperty(e,"extras","An element descriptor"),t}),this)},toElementDescriptor:function(e){var t=String(e.kind);if("method"!==t&&"field"!==t)throw new TypeError('An element descriptor\'s .kind property must be either "method" or "field", but a decorator created an element descriptor with .kind "'+t+'"');var r=n(e.key),i=String(e.placement);if("static"!==i&&"prototype"!==i&&"own"!==i)throw new TypeError('An element descriptor\'s .placement property must be one of "static", "prototype" or "own", but a decorator created an element descriptor with .placement "'+i+'"');var o=e.descriptor;this.disallowProperty(e,"elements","An element descriptor");var a={kind:t,key:r,placement:i,descriptor:Object.assign({},o)};return"field"!==t?this.disallowProperty(e,"initializer","A method descriptor"):(this.disallowProperty(o,"get","The property descriptor of a field descriptor"),this.disallowProperty(o,"set","The property descriptor of a field descriptor"),this.disallowProperty(o,"value","The property descriptor of a field descriptor"),a.initializer=e.initializer),a},toElementFinisherExtras:function(e){return{element:this.toElementDescriptor(e),finisher:p(e,"finisher"),extras:this.toElementDescriptors(e.extras)}},fromClassDescriptor:function(e){var t={kind:"class",elements:e.map(this.fromElementDescriptor,this)};return Object.defineProperty(t,Symbol.toStringTag,{value:"Descriptor",configurable:!0}),t},toClassDescriptor:function(e){var t=String(e.kind);if("class"!==t)throw new TypeError('A class descriptor\'s .kind property must be "class", but a decorator created a class descriptor with .kind "'+t+'"');this.disallowProperty(e,"key","A class descriptor"),this.disallowProperty(e,"placement","A class descriptor"),this.disallowProperty(e,"descriptor","A class descriptor"),this.disallowProperty(e,"initializer","A class descriptor"),this.disallowProperty(e,"extras","A class descriptor");var r=p(e,"finisher");return{elements:this.toElementDescriptors(e.elements),finisher:r}},runClassFinishers:function(e,t){for(var r=0;r<t.length;r++){var i=(0,t[r])(e);if(void 0!==i){if("function"!=typeof i)throw new TypeError("Finishers must return a constructor.");e=i}}return e},disallowProperty:function(e,t,r){if(void 0!==e[t])throw new TypeError(r+" can't have a ."+t+" property.")}};return e}();if(o)for(var h=0;h<o.length;h++)a=o[h](a);var u=t((function(e){a.initializeInstanceElements(e,f.elements)}),r),f=a.decorateClass(function(e){for(var t=[],r=function(e){return"method"===e.kind&&e.key===n.key&&e.placement===n.placement},i=0;i<e.length;i++){var o,n=e[i];if("method"===n.kind&&(o=t.find(r)))if(d(n.descriptor)||d(o.descriptor)){if(c(n)||c(o))throw new ReferenceError("Duplicated methods ("+n.key+") can't be decorated.");o.descriptor=n.descriptor}else{if(c(n)){if(c(o))throw new ReferenceError("Decorators can't be placed on different accessors with for the same property ("+n.key+").");o.decorators=n.decorators}l(n,o)}else t.push(n)}return t}(u.d.map(s)),e);return a.initializeClassElements(u.F,f.elements),a.runClassFinishers(u.F,f.finishers)}function s(e){var t,r=n(e.key);"method"===e.kind?t={value:e.value,writable:!0,configurable:!0,enumerable:!1}:"get"===e.kind?t={get:e.value,configurable:!0,enumerable:!1}:"set"===e.kind?t={set:e.value,configurable:!0,enumerable:!1}:"field"===e.kind&&(t={configurable:!0,writable:!0,enumerable:!0});var i={kind:"field"===e.kind?"field":"method",key:r,placement:e.static?"static":"field"===e.kind?"own":"prototype",descriptor:t};return e.decorators&&(i.decorators=e.decorators),"field"===e.kind&&(i.initializer=e.value),i}function l(e,t){void 0!==e.descriptor.get?t.descriptor.get=e.descriptor.get:t.descriptor.set=e.descriptor.set}function c(e){return e.decorators&&e.decorators.length}function d(e){return void 0!==e&&!(void 0===e.value&&void 0===e.writable)}function p(e,t){var r=e[t];if(void 0!==r&&"function"!=typeof r)throw new TypeError("Expected '"+t+"' to be a function");return r}const h=window.ShadowRoot&&(void 0===window.ShadyCSS||window.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,u=Symbol();class f{constructor(e,t){if(t!==u)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e}get styleSheet(){return h&&void 0===this.t&&(this.t=new CSSStyleSheet,this.t.replaceSync(this.cssText)),this.t}toString(){return this.cssText}}const m=new Map,g=e=>{let t=m.get(e);return void 0===t&&m.set(e,t=new f(e,u)),t},y=(e,...t)=>{const r=1===e.length?e[0]:t.reduce((t,r,i)=>t+(e=>{if(e instanceof f)return e.cssText;if("number"==typeof e)return e;throw Error("Value passed to 'css' function must be a 'css' function result: "+e+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(r)+e[i+1],e[0]);return g(r)},_=h?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t="";for(const r of e.cssRules)t+=r.cssText;return(e=>g("string"==typeof e?e:e+""))(t)})(e):e;var b,v,w,x;const k={toAttribute(e,t){switch(t){case Boolean:e=e?"":null;break;case Object:case Array:e=null==e?e:JSON.stringify(e)}return e},fromAttribute(e,t){let r=e;switch(t){case Boolean:r=null!==e;break;case Number:r=null===e?null:Number(e);break;case Object:case Array:try{r=JSON.parse(e)}catch(e){r=null}}return r}},C=(e,t)=>t!==e&&(t==t||e==e),P={attribute:!0,type:String,converter:k,reflect:!1,hasChanged:C};class S extends HTMLElement{constructor(){super(),this.Πi=new Map,this.Πo=void 0,this.Πl=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this.Πh=null,this.u()}static addInitializer(e){var t;null!==(t=this.v)&&void 0!==t||(this.v=[]),this.v.push(e)}static get observedAttributes(){this.finalize();const e=[];return this.elementProperties.forEach((t,r)=>{const i=this.Πp(r,t);void 0!==i&&(this.Πm.set(i,r),e.push(i))}),e}static createProperty(e,t=P){if(t.state&&(t.attribute=!1),this.finalize(),this.elementProperties.set(e,t),!t.noAccessor&&!this.prototype.hasOwnProperty(e)){const r="symbol"==typeof e?Symbol():"__"+e,i=this.getPropertyDescriptor(e,r,t);void 0!==i&&Object.defineProperty(this.prototype,e,i)}}static getPropertyDescriptor(e,t,r){return{get(){return this[t]},set(i){const o=this[e];this[t]=i,this.requestUpdate(e,o,r)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)||P}static finalize(){if(this.hasOwnProperty("finalized"))return!1;this.finalized=!0;const e=Object.getPrototypeOf(this);if(e.finalize(),this.elementProperties=new Map(e.elementProperties),this.Πm=new Map,this.hasOwnProperty("properties")){const e=this.properties,t=[...Object.getOwnPropertyNames(e),...Object.getOwnPropertySymbols(e)];for(const r of t)this.createProperty(r,e[r])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const r=new Set(e.flat(1/0).reverse());for(const e of r)t.unshift(_(e))}else void 0!==e&&t.push(_(e));return t}static"Πp"(e,t){const r=t.attribute;return!1===r?void 0:"string"==typeof r?r:"string"==typeof e?e.toLowerCase():void 0}u(){var e;this.Πg=new Promise(e=>this.enableUpdating=e),this.L=new Map,this.Π_(),this.requestUpdate(),null===(e=this.constructor.v)||void 0===e||e.forEach(e=>e(this))}addController(e){var t,r;(null!==(t=this.ΠU)&&void 0!==t?t:this.ΠU=[]).push(e),void 0!==this.renderRoot&&this.isConnected&&(null===(r=e.hostConnected)||void 0===r||r.call(e))}removeController(e){var t;null===(t=this.ΠU)||void 0===t||t.splice(this.ΠU.indexOf(e)>>>0,1)}"Π_"(){this.constructor.elementProperties.forEach((e,t)=>{this.hasOwnProperty(t)&&(this.Πi.set(t,this[t]),delete this[t])})}createRenderRoot(){var e;const t=null!==(e=this.shadowRoot)&&void 0!==e?e:this.attachShadow(this.constructor.shadowRootOptions);return((e,t)=>{h?e.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet):t.forEach(t=>{const r=document.createElement("style");r.textContent=t.cssText,e.appendChild(r)})})(t,this.constructor.elementStyles),t}connectedCallback(){var e;void 0===this.renderRoot&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),null===(e=this.ΠU)||void 0===e||e.forEach(e=>{var t;return null===(t=e.hostConnected)||void 0===t?void 0:t.call(e)}),this.Πl&&(this.Πl(),this.Πo=this.Πl=void 0)}enableUpdating(e){}disconnectedCallback(){var e;null===(e=this.ΠU)||void 0===e||e.forEach(e=>{var t;return null===(t=e.hostDisconnected)||void 0===t?void 0:t.call(e)}),this.Πo=new Promise(e=>this.Πl=e)}attributeChangedCallback(e,t,r){this.K(e,r)}"Πj"(e,t,r=P){var i,o;const n=this.constructor.Πp(e,r);if(void 0!==n&&!0===r.reflect){const a=(null!==(o=null===(i=r.converter)||void 0===i?void 0:i.toAttribute)&&void 0!==o?o:k.toAttribute)(t,r.type);this.Πh=e,null==a?this.removeAttribute(n):this.setAttribute(n,a),this.Πh=null}}K(e,t){var r,i,o;const n=this.constructor,a=n.Πm.get(e);if(void 0!==a&&this.Πh!==a){const e=n.getPropertyOptions(a),s=e.converter,l=null!==(o=null!==(i=null===(r=s)||void 0===r?void 0:r.fromAttribute)&&void 0!==i?i:"function"==typeof s?s:null)&&void 0!==o?o:k.fromAttribute;this.Πh=a,this[a]=l(t,e.type),this.Πh=null}}requestUpdate(e,t,r){let i=!0;void 0!==e&&(((r=r||this.constructor.getPropertyOptions(e)).hasChanged||C)(this[e],t)?(this.L.has(e)||this.L.set(e,t),!0===r.reflect&&this.Πh!==e&&(void 0===this.Πk&&(this.Πk=new Map),this.Πk.set(e,r))):i=!1),!this.isUpdatePending&&i&&(this.Πg=this.Πq())}async"Πq"(){this.isUpdatePending=!0;try{for(await this.Πg;this.Πo;)await this.Πo}catch(e){Promise.reject(e)}const e=this.performUpdate();return null!=e&&await e,!this.isUpdatePending}performUpdate(){var e;if(!this.isUpdatePending)return;this.hasUpdated,this.Πi&&(this.Πi.forEach((e,t)=>this[t]=e),this.Πi=void 0);let t=!1;const r=this.L;try{t=this.shouldUpdate(r),t?(this.willUpdate(r),null===(e=this.ΠU)||void 0===e||e.forEach(e=>{var t;return null===(t=e.hostUpdate)||void 0===t?void 0:t.call(e)}),this.update(r)):this.Π$()}catch(e){throw t=!1,this.Π$(),e}t&&this.E(r)}willUpdate(e){}E(e){var t;null===(t=this.ΠU)||void 0===t||t.forEach(e=>{var t;return null===(t=e.hostUpdated)||void 0===t?void 0:t.call(e)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}"Π$"(){this.L=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this.Πg}shouldUpdate(e){return!0}update(e){void 0!==this.Πk&&(this.Πk.forEach((e,t)=>this.Πj(t,this[t],e)),this.Πk=void 0),this.Π$()}updated(e){}firstUpdated(e){}}var A,E,O,T;S.finalized=!0,S.elementProperties=new Map,S.elementStyles=[],S.shadowRootOptions={mode:"open"},null===(v=(b=globalThis).reactiveElementPlatformSupport)||void 0===v||v.call(b,{ReactiveElement:S}),(null!==(w=(x=globalThis).reactiveElementVersions)&&void 0!==w?w:x.reactiveElementVersions=[]).push("1.0.0-rc.2");const N=globalThis.trustedTypes,R=N?N.createPolicy("lit-html",{createHTML:e=>e}):void 0,D=`lit$${(Math.random()+"").slice(9)}$`,I="?"+D,L=`<${I}>`,M=document,H=(e="")=>M.createComment(e),F=e=>null===e||"object"!=typeof e&&"function"!=typeof e,$=Array.isArray,z=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,j=/-->/g,B=/>/g,U=/>|[ 	\n\r](?:([^\s"'>=/]+)([ 	\n\r]*=[ 	\n\r]*(?:[^ 	\n\r"'`<>=]|("|')|))|$)/g,V=/'/g,q=/"/g,Y=/^(?:script|style|textarea)$/i,J=e=>(t,...r)=>({_$litType$:e,strings:t,values:r}),G=J(1),W=J(2),Z=Symbol.for("lit-noChange"),X=Symbol.for("lit-nothing"),K=new WeakMap,Q=M.createTreeWalker(M,129,null,!1);class ee{constructor({strings:e,_$litType$:t},r){let i;this.parts=[];let o=0,n=0;const a=e.length-1,s=this.parts,[l,c]=((e,t)=>{const r=e.length-1,i=[];let o,n=2===t?"<svg>":"",a=z;for(let t=0;t<r;t++){const r=e[t];let s,l,c=-1,d=0;for(;d<r.length&&(a.lastIndex=d,l=a.exec(r),null!==l);)d=a.lastIndex,a===z?"!--"===l[1]?a=j:void 0!==l[1]?a=B:void 0!==l[2]?(Y.test(l[2])&&(o=RegExp("</"+l[2],"g")),a=U):void 0!==l[3]&&(a=U):a===U?">"===l[0]?(a=null!=o?o:z,c=-1):void 0===l[1]?c=-2:(c=a.lastIndex-l[2].length,s=l[1],a=void 0===l[3]?U:'"'===l[3]?q:V):a===q||a===V?a=U:a===j||a===B?a=z:(a=U,o=void 0);const p=a===U&&e[t+1].startsWith("/>")?" ":"";n+=a===z?r+L:c>=0?(i.push(s),r.slice(0,c)+"$lit$"+r.slice(c)+D+p):r+D+(-2===c?(i.push(void 0),t):p)}const s=n+(e[r]||"<?>")+(2===t?"</svg>":"");return[void 0!==R?R.createHTML(s):s,i]})(e,t);if(this.el=ee.createElement(l,r),Q.currentNode=this.el.content,2===t){const e=this.el.content,t=e.firstChild;t.remove(),e.append(...t.childNodes)}for(;null!==(i=Q.nextNode())&&s.length<a;){if(1===i.nodeType){if(i.hasAttributes()){const e=[];for(const t of i.getAttributeNames())if(t.endsWith("$lit$")||t.startsWith(D)){const r=c[n++];if(e.push(t),void 0!==r){const e=i.getAttribute(r.toLowerCase()+"$lit$").split(D),t=/([.?@])?(.*)/.exec(r);s.push({type:1,index:o,name:t[2],strings:e,ctor:"."===t[1]?ne:"?"===t[1]?ae:"@"===t[1]?se:oe})}else s.push({type:6,index:o})}for(const t of e)i.removeAttribute(t)}if(Y.test(i.tagName)){const e=i.textContent.split(D),t=e.length-1;if(t>0){i.textContent=N?N.emptyScript:"";for(let r=0;r<t;r++)i.append(e[r],H()),Q.nextNode(),s.push({type:2,index:++o});i.append(e[t],H())}}}else if(8===i.nodeType)if(i.data===I)s.push({type:2,index:o});else{let e=-1;for(;-1!==(e=i.data.indexOf(D,e+1));)s.push({type:7,index:o}),e+=D.length-1}o++}}static createElement(e,t){const r=M.createElement("template");return r.innerHTML=e,r}}function te(e,t,r=e,i){var o,n,a,s;if(t===Z)return t;let l=void 0!==i?null===(o=r.Σi)||void 0===o?void 0:o[i]:r.Σo;const c=F(t)?void 0:t._$litDirective$;return(null==l?void 0:l.constructor)!==c&&(null===(n=null==l?void 0:l.O)||void 0===n||n.call(l,!1),void 0===c?l=void 0:(l=new c(e),l.T(e,r,i)),void 0!==i?(null!==(a=(s=r).Σi)&&void 0!==a?a:s.Σi=[])[i]=l:r.Σo=l),void 0!==l&&(t=te(e,l.S(e,t.values),l,i)),t}class re{constructor(e,t){this.l=[],this.N=void 0,this.D=e,this.M=t}u(e){var t;const{el:{content:r},parts:i}=this.D,o=(null!==(t=null==e?void 0:e.creationScope)&&void 0!==t?t:M).importNode(r,!0);Q.currentNode=o;let n=Q.nextNode(),a=0,s=0,l=i[0];for(;void 0!==l;){if(a===l.index){let t;2===l.type?t=new ie(n,n.nextSibling,this,e):1===l.type?t=new l.ctor(n,l.name,l.strings,this,e):6===l.type&&(t=new le(n,this,e)),this.l.push(t),l=i[++s]}a!==(null==l?void 0:l.index)&&(n=Q.nextNode(),a++)}return o}v(e){let t=0;for(const r of this.l)void 0!==r&&(void 0!==r.strings?(r.I(e,r,t),t+=r.strings.length-2):r.I(e[t])),t++}}class ie{constructor(e,t,r,i){this.type=2,this.N=void 0,this.A=e,this.B=t,this.M=r,this.options=i}setConnected(e){var t;null===(t=this.P)||void 0===t||t.call(this,e)}get parentNode(){return this.A.parentNode}get startNode(){return this.A}get endNode(){return this.B}I(e,t=this){e=te(this,e,t),F(e)?e===X||null==e||""===e?(this.H!==X&&this.R(),this.H=X):e!==this.H&&e!==Z&&this.m(e):void 0!==e._$litType$?this._(e):void 0!==e.nodeType?this.$(e):(e=>{var t;return $(e)||"function"==typeof(null===(t=e)||void 0===t?void 0:t[Symbol.iterator])})(e)?this.g(e):this.m(e)}k(e,t=this.B){return this.A.parentNode.insertBefore(e,t)}$(e){this.H!==e&&(this.R(),this.H=this.k(e))}m(e){const t=this.A.nextSibling;null!==t&&3===t.nodeType&&(null===this.B?null===t.nextSibling:t===this.B.previousSibling)?t.data=e:this.$(M.createTextNode(e)),this.H=e}_(e){var t;const{values:r,_$litType$:i}=e,o="number"==typeof i?this.C(e):(void 0===i.el&&(i.el=ee.createElement(i.h,this.options)),i);if((null===(t=this.H)||void 0===t?void 0:t.D)===o)this.H.v(r);else{const e=new re(o,this),t=e.u(this.options);e.v(r),this.$(t),this.H=e}}C(e){let t=K.get(e.strings);return void 0===t&&K.set(e.strings,t=new ee(e)),t}g(e){$(this.H)||(this.H=[],this.R());const t=this.H;let r,i=0;for(const o of e)i===t.length?t.push(r=new ie(this.k(H()),this.k(H()),this,this.options)):r=t[i],r.I(o),i++;i<t.length&&(this.R(r&&r.B.nextSibling,i),t.length=i)}R(e=this.A.nextSibling,t){var r;for(null===(r=this.P)||void 0===r||r.call(this,!1,!0,t);e&&e!==this.B;){const t=e.nextSibling;e.remove(),e=t}}}class oe{constructor(e,t,r,i,o){this.type=1,this.H=X,this.N=void 0,this.V=void 0,this.element=e,this.name=t,this.M=i,this.options=o,r.length>2||""!==r[0]||""!==r[1]?(this.H=Array(r.length-1).fill(X),this.strings=r):this.H=X}get tagName(){return this.element.tagName}I(e,t=this,r,i){const o=this.strings;let n=!1;if(void 0===o)e=te(this,e,t,0),n=!F(e)||e!==this.H&&e!==Z,n&&(this.H=e);else{const i=e;let a,s;for(e=o[0],a=0;a<o.length-1;a++)s=te(this,i[r+a],t,a),s===Z&&(s=this.H[a]),n||(n=!F(s)||s!==this.H[a]),s===X?e=X:e!==X&&(e+=(null!=s?s:"")+o[a+1]),this.H[a]=s}n&&!i&&this.W(e)}W(e){e===X?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,null!=e?e:"")}}class ne extends oe{constructor(){super(...arguments),this.type=3}W(e){this.element[this.name]=e===X?void 0:e}}class ae extends oe{constructor(){super(...arguments),this.type=4}W(e){e&&e!==X?this.element.setAttribute(this.name,""):this.element.removeAttribute(this.name)}}class se extends oe{constructor(){super(...arguments),this.type=5}I(e,t=this){var r;if((e=null!==(r=te(this,e,t,0))&&void 0!==r?r:X)===Z)return;const i=this.H,o=e===X&&i!==X||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,n=e!==X&&(i===X||o);o&&this.element.removeEventListener(this.name,this,i),n&&this.element.addEventListener(this.name,this,e),this.H=e}handleEvent(e){var t,r;"function"==typeof this.H?this.H.call(null!==(r=null===(t=this.options)||void 0===t?void 0:t.host)&&void 0!==r?r:this.element,e):this.H.handleEvent(e)}}class le{constructor(e,t,r){this.element=e,this.type=6,this.N=void 0,this.V=void 0,this.M=t,this.options=r}I(e){te(this,e)}}var ce,de,pe,he,ue,fe;null===(E=(A=globalThis).litHtmlPlatformSupport)||void 0===E||E.call(A,ee,ie),(null!==(O=(T=globalThis).litHtmlVersions)&&void 0!==O?O:T.litHtmlVersions=[]).push("2.0.0-rc.3"),(null!==(ce=(fe=globalThis).litElementVersions)&&void 0!==ce?ce:fe.litElementVersions=[]).push("3.0.0-rc.2");class me extends S{constructor(){super(...arguments),this.renderOptions={host:this},this.Φt=void 0}createRenderRoot(){var e,t;const r=super.createRenderRoot();return null!==(e=(t=this.renderOptions).renderBefore)&&void 0!==e||(t.renderBefore=r.firstChild),r}update(e){const t=this.render();super.update(e),this.Φt=((e,t,r)=>{var i,o;const n=null!==(i=null==r?void 0:r.renderBefore)&&void 0!==i?i:t;let a=n._$litPart$;if(void 0===a){const e=null!==(o=null==r?void 0:r.renderBefore)&&void 0!==o?o:null;n._$litPart$=a=new ie(t.insertBefore(H(),e),e,void 0,r)}return a.I(e),a})(t,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),null===(e=this.Φt)||void 0===e||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),null===(e=this.Φt)||void 0===e||e.setConnected(!1)}render(){return Z}}me.finalized=!0,me._$litElement$=!0,null===(pe=(de=globalThis).litElementHydrateSupport)||void 0===pe||pe.call(de,{LitElement:me}),null===(ue=(he=globalThis).litElementPlatformSupport)||void 0===ue||ue.call(he,{LitElement:me});const ge=e=>t=>"function"==typeof t?((e,t)=>(window.customElements.define(e,t),t))(e,t):((e,t)=>{const{kind:r,elements:i}=t;return{kind:r,elements:i,finisher(t){window.customElements.define(e,t)}}})(e,t),ye=(e,t)=>"method"===t.kind&&t.descriptor&&!("value"in t.descriptor)?{...t,finisher(r){r.createProperty(t.key,e)}}:{kind:"field",key:Symbol(),placement:"own",descriptor:{},originalKey:t.key,initializer(){"function"==typeof t.initializer&&(this[t.key]=t.initializer.call(this))},finisher(r){r.createProperty(t.key,e)}};function _e(e){return(t,r)=>void 0!==r?((e,t,r)=>{t.constructor.createProperty(r,e)})(e,t,r):ye(e,t)}function be(e){return _e({...e,state:!0,attribute:!1})}const ve=({finisher:e,descriptor:t})=>(r,i)=>{var o;if(void 0===i){const i=null!==(o=r.originalKey)&&void 0!==o?o:r.key,n=null!=t?{kind:"method",placement:"prototype",key:i,descriptor:t(r.key)}:{...r,key:i};return null!=e&&(n.finisher=function(t){e(t,i)}),n}{const o=r.constructor;void 0!==t&&Object.defineProperty(r,i,t(i)),null==e||e(o,i)}};function we(e){return ve({finisher:(t,r)=>{Object.assign(t.prototype[r],e)}})}function xe(e,t){return ve({descriptor:r=>{const i={get(){var t;return null===(t=this.renderRoot)||void 0===t?void 0:t.querySelector(e)},enumerable:!0,configurable:!0};if(t){const t="symbol"==typeof r?Symbol():"__"+r;i.get=function(){var r;return void 0===this[t]&&(this[t]=null===(r=this.renderRoot)||void 0===r?void 0:r.querySelector(e)),this[t]}}return i}})}function ke(e){return ve({descriptor:t=>({async get(){var t;return await this.updateComplete,null===(t=this.renderRoot)||void 0===t?void 0:t.querySelector(e)},enumerable:!0,configurable:!0})})}const Ce={"primary-background-color":"#111111","card-background-color":"#1c1c1c","secondary-background-color":"#202020","primary-text-color":"#e1e1e1","secondary-text-color":"#9b9b9b","disabled-text-color":"#6f6f6f","app-header-text-color":"#e1e1e1","app-header-background-color":"#101e24","switch-unchecked-button-color":"#999999","switch-unchecked-track-color":"#9b9b9b","divider-color":"rgba(225, 225, 225, .12)","mdc-ripple-color":"#AAAAAA","codemirror-keyword":"#C792EA","codemirror-operator":"#89DDFF","codemirror-variable":"#f07178","codemirror-variable-2":"#EEFFFF","codemirror-variable-3":"#DECB6B","codemirror-builtin":"#FFCB6B","codemirror-atom":"#F78C6C","codemirror-number":"#FF5370","codemirror-def":"#82AAFF","codemirror-string":"#C3E88D","codemirror-string-2":"#f07178","codemirror-comment":"#545454","codemirror-tag":"#FF5370","codemirror-meta":"#FFCB6B","codemirror-attribute":"#C792EA","codemirror-property":"#C792EA","codemirror-qualifier":"#DECB6B","codemirror-type":"#DECB6B","energy-grid-return-color":"#b39bdb"},Pe={"state-icon-error-color":"var(--error-state-color, var(--error-color))","state-unavailable-color":"var(--state-icon-unavailable-color, var(--disabled-text-color))","sidebar-text-color":"var(--primary-text-color)","sidebar-background-color":"var(--card-background-color)","sidebar-selected-text-color":"var(--primary-color)","sidebar-selected-icon-color":"var(--primary-color)","sidebar-icon-color":"rgba(var(--rgb-primary-text-color), 0.6)","switch-checked-color":"var(--primary-color)","switch-checked-button-color":"var(--switch-checked-color, var(--primary-background-color))","switch-checked-track-color":"var(--switch-checked-color, #000000)","switch-unchecked-button-color":"var(--switch-unchecked-color, var(--primary-background-color))","switch-unchecked-track-color":"var(--switch-unchecked-color, #000000)","slider-color":"var(--primary-color)","slider-secondary-color":"var(--light-primary-color)","slider-bar-color":"var(--disabled-text-color)","label-badge-grey":"var(--paper-grey-500)","label-badge-background-color":"var(--card-background-color)","label-badge-text-color":"rgba(var(--rgb-primary-text-color), 0.8)","paper-listbox-background-color":"var(--card-background-color)","paper-item-icon-color":"var(--state-icon-color)","paper-item-icon-active-color":"var(--state-icon-active-color)","table-row-background-color":"var(--primary-background-color)","table-row-alternative-background-color":"var(--secondary-background-color)","paper-slider-knob-color":"var(--slider-color)","paper-slider-knob-start-color":"var(--slider-color)","paper-slider-pin-color":"var(--slider-color)","paper-slider-pin-start-color":"var(--slider-color)","paper-slider-active-color":"var(--slider-color)","paper-slider-secondary-color":"var(--slider-secondary-color)","paper-slider-container-color":"var(--slider-bar-color)","data-table-background-color":"var(--card-background-color)","markdown-code-background-color":"var(--primary-background-color)","mdc-theme-primary":"var(--primary-color)","mdc-theme-secondary":"var(--accent-color)","mdc-theme-background":"var(--primary-background-color)","mdc-theme-surface":"var(--card-background-color)","mdc-theme-on-primary":"var(--text-primary-color)","mdc-theme-on-secondary":"var(--text-primary-color)","mdc-theme-on-surface":"var(--primary-text-color)","mdc-theme-text-disabled-on-light":"var(--disabled-text-color)","mdc-theme-text-primary-on-background":"var(--primary-text-color)","mdc-theme-text-secondary-on-background":"var(--secondary-text-color)","mdc-theme-text-icon-on-background":"var(--secondary-text-color)","app-header-text-color":"var(--text-primary-color)","app-header-background-color":"var(--primary-color)","mdc-checkbox-unchecked-color":"rgba(var(--rgb-primary-text-color), 0.54)","mdc-checkbox-disabled-color":"var(--disabled-text-color)","mdc-radio-unchecked-color":"rgba(var(--rgb-primary-text-color), 0.54)","mdc-radio-disabled-color":"var(--disabled-text-color)","mdc-tab-text-label-color-default":"var(--primary-text-color)","mdc-button-disabled-ink-color":"var(--disabled-text-color)","mdc-button-outline-color":"var(--divider-color)","mdc-dialog-scroll-divider-color":"var(--divider-color)","chip-background-color":"rgba(var(--rgb-primary-text-color), 0.15)","material-body-text-color":"var(--primary-text-color)","material-background-color":"var(--card-background-color)","material-secondary-background-color":"var(--secondary-background-color)","material-secondary-text-color":"var(--secondary-text-color)"},Se=y`
  button.link {
    background: none;
    color: inherit;
    border: none;
    padding: 0;
    font: inherit;
    text-align: left;
    text-decoration: underline;
    cursor: pointer;
  }
`,Ae=y`
  :host {
    font-family: var(--paper-font-body1_-_font-family);
    -webkit-font-smoothing: var(--paper-font-body1_-_-webkit-font-smoothing);
    font-size: var(--paper-font-body1_-_font-size);
    font-weight: var(--paper-font-body1_-_font-weight);
    line-height: var(--paper-font-body1_-_line-height);
  }

  app-header-layout,
  ha-app-layout {
    background-color: var(--primary-background-color);
  }

  app-header,
  app-toolbar {
    background-color: var(--app-header-background-color);
    font-weight: 400;
    color: var(--app-header-text-color, white);
  }

  app-toolbar {
    height: var(--header-height);
  }

  app-header div[sticky] {
    height: 48px;
  }

  app-toolbar [main-title] {
    margin-left: 20px;
  }

  h1 {
    font-family: var(--paper-font-headline_-_font-family);
    -webkit-font-smoothing: var(--paper-font-headline_-_-webkit-font-smoothing);
    white-space: var(--paper-font-headline_-_white-space);
    overflow: var(--paper-font-headline_-_overflow);
    text-overflow: var(--paper-font-headline_-_text-overflow);
    font-size: var(--paper-font-headline_-_font-size);
    font-weight: var(--paper-font-headline_-_font-weight);
    line-height: var(--paper-font-headline_-_line-height);
  }

  h2 {
    font-family: var(--paper-font-title_-_font-family);
    -webkit-font-smoothing: var(--paper-font-title_-_-webkit-font-smoothing);
    white-space: var(--paper-font-title_-_white-space);
    overflow: var(--paper-font-title_-_overflow);
    text-overflow: var(--paper-font-title_-_text-overflow);
    font-size: var(--paper-font-title_-_font-size);
    font-weight: var(--paper-font-title_-_font-weight);
    line-height: var(--paper-font-title_-_line-height);
  }

  h3 {
    font-family: var(--paper-font-subhead_-_font-family);
    -webkit-font-smoothing: var(--paper-font-subhead_-_-webkit-font-smoothing);
    white-space: var(--paper-font-subhead_-_white-space);
    overflow: var(--paper-font-subhead_-_overflow);
    text-overflow: var(--paper-font-subhead_-_text-overflow);
    font-size: var(--paper-font-subhead_-_font-size);
    font-weight: var(--paper-font-subhead_-_font-weight);
    line-height: var(--paper-font-subhead_-_line-height);
  }

  a {
    color: var(--primary-color);
  }

  .secondary {
    color: var(--secondary-text-color);
  }

  .error {
    color: var(--error-color);
  }

  .warning {
    color: var(--error-color);
  }

  mwc-button.warning {
    --mdc-theme-primary: var(--error-color);
  }

  ${Se}

  .card-actions a {
    text-decoration: none;
  }

  .card-actions .warning {
    --mdc-theme-primary: var(--error-color);
  }

  .layout.horizontal,
  .layout.vertical {
    display: flex;
  }
  .layout.inline {
    display: inline-flex;
  }
  .layout.horizontal {
    flex-direction: row;
  }
  .layout.vertical {
    flex-direction: column;
  }
  .layout.wrap {
    flex-wrap: wrap;
  }
  .layout.no-wrap {
    flex-wrap: nowrap;
  }
  .layout.center,
  .layout.center-center {
    align-items: center;
  }
  .layout.bottom {
    align-items: flex-end;
  }
  .layout.center-justified,
  .layout.center-center {
    justify-content: center;
  }
  .flex {
    flex: 1;
    flex-basis: 0.000000001px;
  }
  .flex-auto {
    flex: 1 1 auto;
  }
  .flex-none {
    flex: none;
  }
  .layout.justified {
    justify-content: space-between;
  }
`,Ee=y`
  /* prevent clipping of positioned elements */
  paper-dialog-scrollable {
    --paper-dialog-scrollable: {
      -webkit-overflow-scrolling: auto;
    }
  }

  /* force smooth scrolling for iOS 10 */
  paper-dialog-scrollable.can-scroll {
    --paper-dialog-scrollable: {
      -webkit-overflow-scrolling: touch;
    }
  }

  .paper-dialog-buttons {
    align-items: flex-end;
    padding: 8px;
    padding-bottom: max(env(safe-area-inset-bottom), 8px);
  }

  @media all and (min-width: 450px) and (min-height: 500px) {
    ha-paper-dialog {
      min-width: 400px;
    }
  }

  @media all and (max-width: 450px), all and (max-height: 500px) {
    paper-dialog,
    ha-paper-dialog {
      margin: 0;
      width: calc(
        100% - env(safe-area-inset-right) - env(safe-area-inset-left)
      ) !important;
      min-width: calc(
        100% - env(safe-area-inset-right) - env(safe-area-inset-left)
      ) !important;
      max-width: calc(
        100% - env(safe-area-inset-right) - env(safe-area-inset-left)
      ) !important;
      max-height: calc(100% - var(--header-height));

      position: fixed !important;
      bottom: 0px;
      left: env(safe-area-inset-left);
      right: env(safe-area-inset-right);
      overflow: scroll;
      border-bottom-left-radius: 0px;
      border-bottom-right-radius: 0px;
    }
  }

  /* mwc-dialog (ha-dialog) styles */
  ha-dialog {
    --mdc-dialog-min-width: 400px;
    --mdc-dialog-max-width: 600px;
    --mdc-dialog-heading-ink-color: var(--primary-text-color);
    --mdc-dialog-content-ink-color: var(--primary-text-color);
    --justify-action-buttons: space-between;
  }

  ha-dialog .form {
    padding-bottom: 24px;
    color: var(--primary-text-color);
  }

  a {
    color: var(--primary-color);
  }

  /* make dialog fullscreen on small screens */
  @media all and (max-width: 450px), all and (max-height: 500px) {
    ha-dialog {
      --mdc-dialog-min-width: calc(
        100vw - env(safe-area-inset-right) - env(safe-area-inset-left)
      );
      --mdc-dialog-max-width: calc(
        100vw - env(safe-area-inset-right) - env(safe-area-inset-left)
      );
      --mdc-dialog-min-height: 100%;
      --mdc-dialog-max-height: 100%;
      --mdc-shape-medium: 0px;
      --vertial-align-dialog: flex-end;
    }
  }
  mwc-button.warning {
    --mdc-theme-primary: var(--error-color);
  }
  .error {
    color: var(--error-color);
  }
`;y`
  .ha-scrollbar::-webkit-scrollbar {
    width: 0.4rem;
    height: 0.4rem;
  }

  .ha-scrollbar::-webkit-scrollbar-thumb {
    -webkit-border-radius: 4px;
    border-radius: 4px;
    background: var(--scrollbar-thumb-color);
  }

  .ha-scrollbar {
    overflow-y: auto;
    scrollbar-color: var(--scrollbar-thumb-color) transparent;
    scrollbar-width: thin;
  }
`,y`
  body {
    background-color: var(--primary-background-color);
    color: var(--primary-text-color);
    height: calc(100vh - 32px);
    width: 100vw;
  }
`;const Oe=e=>{if(6===(e=e.replace("#","")).length)return e;let t="";for(const r of e)t+=r+r;return t},Te=e=>{const t=Math.round(Math.min(Math.max(e,0),255)).toString(16);return 1===t.length?"0"+t:t},Ne=e=>(e=Oe(e),[parseInt(e.substring(0,2),16),parseInt(e.substring(2,4),16),parseInt(e.substring(4,6),16)]),Re=e=>`#${Te(e[0])}${Te(e[1])}${Te(e[2])}`,De=.137931034,Ie=.12841855,Le=e=>(e/=255)<=.04045?e/12.92:((e+.055)/1.055)**2.4,Me=e=>e>.008856452?e**(1/3):e/Ie+De,He=e=>255*(e<=.00304?12.92*e:1.055*e**(1/2.4)-.055),Fe=e=>e>.206896552?e*e*e:Ie*(e-De),$e=e=>{const[t,r,i]=(e=>{let[t,r,i]=e;t=Le(t),r=Le(r),i=Le(i);return[Me((.4124564*t+.3575761*r+.1804375*i)/.95047),Me((.2126729*t+.7151522*r+.072175*i)/1),Me((.0193339*t+.119192*r+.9503041*i)/1.08883)]})(e),o=116*r-16;return[o<0?0:o,500*(t-r),200*(r-i)]},ze=e=>{const[t,r,i]=e;let o=(t+16)/116,n=isNaN(r)?o:o+r/500,a=isNaN(i)?o:o-i/200;o=1*Fe(o),n=.95047*Fe(n),a=1.08883*Fe(a);return[He(3.2404542*n-1.5371385*o-.4985314*a),He(-.969266*n+1.8760108*o+.041556*a),He(.0556434*n-.2040259*o+1.0572252*a)]},je=(e,t=1)=>[e[0]-18*t,e[1],e[2]],Be=e=>{const t=[0,0,0];for(let r=0;r<e.length;r++){const i=e[r]/255;t[r]=i<=.03928?i/12.92:((i+.055)/1.055)**2.4}return.2126*t[0]+.7152*t[1]+.0722*t[2]},Ue=(e,t)=>{const r=Be(e),i=Be(t);return r>i?(r+.05)/(i+.05):(i+.05)/(r+.05)};let Ve={};const qe=(e,t,r,i)=>{var o,n;let a=r,s={};if(i&&(i.dark&&(a+="__dark",s={...Ce}),"default"===r)){var l;const t=i.primaryColor,r=i.accentColor;if(i.dark&&t&&(s["app-header-background-color"]=((e,t,r=50)=>{let i="";e=Oe(e),t=Oe(t);for(let o=0;o<=5;o+=2){const n=parseInt(e.substr(o,2),16),a=parseInt(t.substr(o,2),16);let s=Math.floor(a+r/100*(n-a)).toString(16);for(;s.length<2;)s="0"+s;i+=s}return"#"+i})(t,"#121212",8)),t){a=`${a}__primary_${t}`;const e=Ne(t),r=$e(e);s["primary-color"]=t;const i=ze(((e,t=1)=>je(e,-t))(r));s["light-primary-color"]=Re(i),s["dark-primary-color"]=(e=>{const t=ze(e);return Re(t)})(je(r)),s["text-primary-color"]=Ue(e,[33,33,33])<6?"#fff":"#212121",s["text-light-primary-color"]=Ue(i,[33,33,33])<6?"#fff":"#212121",s["state-icon-color"]=s["dark-primary-color"]}if(r){a=`${a}__accent_${r}`,s["accent-color"]=r;const e=Ne(r);s["text-accent-color"]=Ue(e,[33,33,33])<6?"#fff":"#212121"}if((null===(l=e._themes)||void 0===l?void 0:l.cacheKey)===a)return}if(r&&"default"!==r&&t.themes[r]){const{modes:e,...o}=t.themes[r];s={...s,...o},e&&(s=null!=i&&i.dark?{...s,...e.dark}:{...s,...e.light})}if(!(null!==(o=e._themes)&&void 0!==o&&o.keys||Object.keys(s).length))return;const c=s&&a?Ve[a]||Ye(a,s):void 0,d={...null===(n=e._themes)||void 0===n?void 0:n.keys,...null==c?void 0:c.styles};e._themes={cacheKey:a,keys:null==c?void 0:c.keys},e.updateStyles?e.updateStyles(d):window.ShadyCSS&&window.ShadyCSS.styleSubtree(e,d)},Ye=(e,t)=>{if(!t||!Object.keys(t).length)return;const r={...Pe,...t},i={},o={};for(const e of Object.keys(r)){const t="--"+e,n=String(r[e]);if(i[t]=n,o[t]="",!n.startsWith("#"))continue;const a="rgb-"+e;if(void 0===r[a])try{const e=Ne(n).join(","),t="--"+a;i[t]=e,o[t]=""}catch(e){continue}}return Ve[e]={styles:i,keys:o},{styles:i,keys:o}},Je=(e,t,r,i)=>{i=i||{},r=null==r?{}:r;const o=new Event(t,{bubbles:void 0===i.bubbles||i.bubbles,cancelable:Boolean(i.cancelable),composed:void 0===i.composed||i.composed});return o.detail=r,e.dispatchEvent(o),o},Ge="ha-main-window"===window.name?window:"ha-main-window"===parent.name?parent:top,We=(e,t)=>{const r=(null==t?void 0:t.replace)||!1;var i;r?Ge.history.replaceState(null!==(i=Ge.history.state)&&void 0!==i&&i.root?{root:!0}:null,"",e):Ge.history.pushState(null,"",e),Je(Ge,"location-changed",{replace:r})},Ze={},Xe=(e,t)=>{e.addEventListener("show-dialog",r=>{const{dialogTag:i,dialogImport:o,dialogParams:n}=r.detail;(async(e,t,r,i,o,n=!0)=>{if(!(r in Ze)){if(!o)return void(__DEV__&&console.warn("Asked to show dialog that's not loaded and can't be imported"));Ze[r]=o().then(()=>{const t=document.createElement(r);return e.provideHass(t),t})}if(n){var a,s;Ge.history.replaceState({dialog:r,open:!1,oldState:null!==(a=Ge.history.state)&&void 0!==a&&a.open&&(null===(s=Ge.history.state)||void 0===s?void 0:s.dialog)!==r?Ge.history.state:null},"");try{Ge.history.pushState({dialog:r,dialogParams:i,open:!0},"")}catch(e){Ge.history.pushState({dialog:r,dialogParams:null,open:!0},"")}}const l=await Ze[r];t.appendChild(l),l.showDialog(i)})(e,t,i,n,o)})},Ke=!(window.ShadyDOM&&window.ShadyDOM.inUse);let Qe,et;function tt(e){Qe=(!e||!e.shimcssproperties)&&(Ke||Boolean(!navigator.userAgent.match(/AppleWebKit\/601|Edge\/15/)&&window.CSS&&CSS.supports&&CSS.supports("box-shadow","0 0 0 var(--foo)")))}window.ShadyCSS&&void 0!==window.ShadyCSS.cssBuild&&(et=window.ShadyCSS.cssBuild);const rt=Boolean(window.ShadyCSS&&window.ShadyCSS.disableRuntime);window.ShadyCSS&&void 0!==window.ShadyCSS.nativeCss?Qe=window.ShadyCSS.nativeCss:window.ShadyCSS?(tt(window.ShadyCSS),window.ShadyCSS=void 0):tt(window.WebComponents&&window.WebComponents.flags);const it=Qe;class ot{constructor(){this.start=0,this.end=0,this.previous=null,this.parent=null,this.rules=null,this.parsedCssText="",this.cssText="",this.atRule=!1,this.type=0,this.keyframesName="",this.selector="",this.parsedSelector=""}}function nt(e){return function e(t,r){let i=r.substring(t.start,t.end-1);if(t.parsedCssText=t.cssText=i.trim(),t.parent){let e=t.previous?t.previous.end:t.parent.start;i=r.substring(e,t.start-1),i=function(e){return e.replace(/\\([0-9a-f]{1,6})\s/gi,(function(){let e=arguments[1],t=6-e.length;for(;t--;)e="0"+e;return"\\"+e}))}(i),i=i.replace(dt.multipleSpaces," "),i=i.substring(i.lastIndexOf(";")+1);let o=t.parsedSelector=t.selector=i.trim();t.atRule=0===o.indexOf(ut),t.atRule?0===o.indexOf(ht)?t.type=st.MEDIA_RULE:o.match(dt.keyframesRule)&&(t.type=st.KEYFRAMES_RULE,t.keyframesName=t.selector.split(dt.multipleSpaces).pop()):0===o.indexOf(pt)?t.type=st.MIXIN_RULE:t.type=st.STYLE_RULE}let o=t.rules;if(o)for(let t,i=0,n=o.length;i<n&&(t=o[i]);i++)e(t,r);return t}(function(e){let t=new ot;t.start=0,t.end=e.length;let r=t;for(let i=0,o=e.length;i<o;i++)if(e[i]===lt){r.rules||(r.rules=[]);let e=r,t=e.rules[e.rules.length-1]||null;r=new ot,r.start=i+1,r.parent=e,r.previous=t,e.rules.push(r)}else e[i]===ct&&(r.end=i+1,r=r.parent||t);return t}(e=e.replace(dt.comments,"").replace(dt.port,"")),e)}function at(e,t,r=""){let i="";if(e.cssText||e.rules){let r=e.rules;if(r&&!function(e){let t=e[0];return Boolean(t)&&Boolean(t.selector)&&0===t.selector.indexOf(pt)}(r))for(let e,o=0,n=r.length;o<n&&(e=r[o]);o++)i=at(e,t,i);else i=t?e.cssText:function(e){return function(e){return e.replace(dt.mixinApply,"").replace(dt.varApply,"")}(e=function(e){return e.replace(dt.customProp,"").replace(dt.mixinProp,"")}(e))}(e.cssText),i=i.trim(),i&&(i="  "+i+"\n")}return i&&(e.selector&&(r+=e.selector+" "+lt+"\n"),r+=i,e.selector&&(r+=ct+"\n\n")),r}const st={STYLE_RULE:1,KEYFRAMES_RULE:7,MEDIA_RULE:4,MIXIN_RULE:1e3},lt="{",ct="}",dt={comments:/\/\*[^*]*\*+([^/*][^*]*\*+)*\//gim,port:/@import[^;]*;/gim,customProp:/(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?(?:[;\n]|$)/gim,mixinProp:/(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?{[^}]*?}(?:[;\n]|$)?/gim,mixinApply:/@apply\s*\(?[^);]*\)?\s*(?:[;\n]|$)?/gim,varApply:/[^;:]*?:[^;]*?var\([^;]*\)(?:[;\n]|$)?/gim,keyframesRule:/^@[^\s]*keyframes/,multipleSpaces:/\s+/g},pt="--",ht="@media",ut="@",ft=/(?:^|[;\s{]\s*)(--[\w-]*?)\s*:\s*(?:((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};{])+)|\{([^}]*)\}(?:(?=[;\s}])|$))/gi,mt=/(?:^|\W+)@apply\s*\(?([^);\n]*)\)?/gi,gt=/@media\s(.*)/,yt=new Set;function _t(e){const t=e.textContent;if(!yt.has(t)){yt.add(t);const e=document.createElement("style");e.setAttribute("shady-unscoped",""),e.textContent=t,document.head.appendChild(e)}}function bt(e){return e.hasAttribute("shady-unscoped")}function vt(e,t){return e?("string"==typeof e&&(e=nt(e)),t&&xt(e,t),at(e,it)):""}function wt(e){return!e.__cssRules&&e.textContent&&(e.__cssRules=nt(e.textContent)),e.__cssRules||null}function xt(e,t,r,i){if(!e)return;let o=!1,n=e.type;if(i&&n===st.MEDIA_RULE){let t=e.selector.match(gt);t&&(window.matchMedia(t[1]).matches||(o=!0))}n===st.STYLE_RULE?t(e):r&&n===st.KEYFRAMES_RULE?r(e):n===st.MIXIN_RULE&&(o=!0);let a=e.rules;if(a&&!o)for(let e,o=0,n=a.length;o<n&&(e=a[o]);o++)xt(e,t,r,i)}window.ShadyDOM&&window.ShadyDOM.wrap;function kt(e){if(void 0!==et)return et;if(void 0===e.__cssBuild){const t=e.getAttribute("css-build");if(t)e.__cssBuild=t;else{const t=function(e){const t="template"===e.localName?e.content.firstChild:e.firstChild;if(t instanceof Comment){const e=t.textContent.trim().split(":");if("css-build"===e[0])return e[1]}return""}(e);""!==t&&function(e){const t="template"===e.localName?e.content.firstChild:e.firstChild;t.parentNode.removeChild(t)}(e),e.__cssBuild=t}}return e.__cssBuild||""}function Ct(e){return""!==kt(e)}function Pt(e,t){for(let r in t)null===r?e.style.removeProperty(r):e.style.setProperty(r,t[r])}function St(e,t){const r=window.getComputedStyle(e).getPropertyValue(t);return r?r.trim():""}const At=/;\s*/m,Et=/^\s*(initial)|(inherit)\s*$/,Ot=/\s*!important/;class Tt{constructor(){this._map={}}set(e,t){e=e.trim(),this._map[e]={properties:t,dependants:{}}}get(e){return e=e.trim(),this._map[e]||null}}let Nt=null;class Rt{constructor(){this._currentElement=null,this._measureElement=null,this._map=new Tt}detectMixin(e){return function(e){const t=mt.test(e)||ft.test(e);return mt.lastIndex=0,ft.lastIndex=0,t}(e)}gatherStyles(e){const t=function(e){const t=[],r=e.querySelectorAll("style");for(let e=0;e<r.length;e++){const i=r[e];bt(i)?Ke||(_t(i),i.parentNode.removeChild(i)):(t.push(i.textContent),i.parentNode.removeChild(i))}return t.join("").trim()}(e.content);if(t){const r=document.createElement("style");return r.textContent=t,e.content.insertBefore(r,e.content.firstChild),r}return null}transformTemplate(e,t){void 0===e._gatheredStyle&&(e._gatheredStyle=this.gatherStyles(e));const r=e._gatheredStyle;return r?this.transformStyle(r,t):null}transformStyle(e,t=""){let r=wt(e);return this.transformRules(r,t),e.textContent=vt(r),r}transformCustomStyle(e){let t=wt(e);return xt(t,e=>{":root"===e.selector&&(e.selector="html"),this.transformRule(e)}),e.textContent=vt(t),t}transformRules(e,t){this._currentElement=t,xt(e,e=>{this.transformRule(e)}),this._currentElement=null}transformRule(e){e.cssText=this.transformCssText(e.parsedCssText,e),":root"===e.selector&&(e.selector=":host > *")}transformCssText(e,t){return e=e.replace(ft,(e,r,i,o)=>this._produceCssProperties(e,r,i,o,t)),this._consumeCssProperties(e,t)}_getInitialValueForProperty(e){return this._measureElement||(this._measureElement=document.createElement("meta"),this._measureElement.setAttribute("apply-shim-measure",""),this._measureElement.style.all="initial",document.head.appendChild(this._measureElement)),window.getComputedStyle(this._measureElement).getPropertyValue(e)}_fallbacksFromPreviousRules(e){let t=e;for(;t.parent;)t=t.parent;const r={};let i=!1;return xt(t,t=>{i=i||t===e,i||t.selector===e.selector&&Object.assign(r,this._cssTextToMap(t.parsedCssText))}),r}_consumeCssProperties(e,t){let r=null;for(;r=mt.exec(e);){let i=r[0],o=r[1],n=r.index,a=n+i.indexOf("@apply"),s=n+i.length,l=e.slice(0,a),c=e.slice(s),d=t?this._fallbacksFromPreviousRules(t):{};Object.assign(d,this._cssTextToMap(l));let p=this._atApplyToCssProperties(o,d);e=`${l}${p}${c}`,mt.lastIndex=n+p.length}return e}_atApplyToCssProperties(e,t){e=e.replace(At,"");let r=[],i=this._map.get(e);if(i||(this._map.set(e,{}),i=this._map.get(e)),i){let o,n,a;this._currentElement&&(i.dependants[this._currentElement]=!0);const s=i.properties;for(o in s)a=t&&t[o],n=[o,": var(",e,"_-_",o],a&&n.push(",",a.replace(Ot,"")),n.push(")"),Ot.test(s[o])&&n.push(" !important"),r.push(n.join(""))}return r.join("; ")}_replaceInitialOrInherit(e,t){let r=Et.exec(t);return r&&(t=r[1]?this._getInitialValueForProperty(e):"apply-shim-inherit"),t}_cssTextToMap(e,t=!1){let r,i,o=e.split(";"),n={};for(let e,a,s=0;s<o.length;s++)e=o[s],e&&(a=e.split(":"),a.length>1&&(r=a[0].trim(),i=a.slice(1).join(":"),t&&(i=this._replaceInitialOrInherit(r,i)),n[r]=i));return n}_invalidateMixinEntry(e){if(Nt)for(let t in e.dependants)t!==this._currentElement&&Nt(t)}_produceCssProperties(e,t,r,i,o){if(r&&function e(t,r){let i=t.indexOf("var(");if(-1===i)return r(t,"","","");let o=function(e,t){let r=0;for(let i=t,o=e.length;i<o;i++)if("("===e[i])r++;else if(")"===e[i]&&0==--r)return i;return-1}(t,i+3),n=t.substring(i+4,o),a=t.substring(0,i),s=e(t.substring(o+1),r),l=n.indexOf(",");return-1===l?r(a,n.trim(),"",s):r(a,n.substring(0,l).trim(),n.substring(l+1).trim(),s)}(r,(e,t)=>{t&&this._map.get(t)&&(i=`@apply ${t};`)}),!i)return e;let n=this._consumeCssProperties(""+i,o),a=e.slice(0,e.indexOf("--")),s=this._cssTextToMap(n,!0),l=s,c=this._map.get(t),d=c&&c.properties;d?l=Object.assign(Object.create(d),s):this._map.set(t,l);let p,h,u=[],f=!1;for(p in l)h=s[p],void 0===h&&(h="initial"),d&&!(p in d)&&(f=!0),u.push(`${t}_-_${p}: ${h}`);return f&&this._invalidateMixinEntry(c),c&&(c.properties=l),r&&(a=`${e};${a}`),`${a}${u.join("; ")};`}}Rt.prototype.detectMixin=Rt.prototype.detectMixin,Rt.prototype.transformStyle=Rt.prototype.transformStyle,Rt.prototype.transformCustomStyle=Rt.prototype.transformCustomStyle,Rt.prototype.transformRules=Rt.prototype.transformRules,Rt.prototype.transformRule=Rt.prototype.transformRule,Rt.prototype.transformTemplate=Rt.prototype.transformTemplate,Rt.prototype._separator="_-_",Object.defineProperty(Rt.prototype,"invalidCallback",{get:()=>Nt,set(e){Nt=e}});const Dt={},It="_applyShimCurrentVersion",Lt="_applyShimNextVersion",Mt=Promise.resolve();function Ht(e){let t=Dt[e];t&&function(e){e[It]=e[It]||0,e._applyShimValidatingVersion=e._applyShimValidatingVersion||0,e[Lt]=(e[Lt]||0)+1}(t)}function Ft(e){return e[It]===e[Lt]}let $t,zt=null,jt=window.HTMLImports&&window.HTMLImports.whenReady||null;function Bt(e){requestAnimationFrame((function(){jt?jt(e):(zt||(zt=new Promise(e=>{$t=e}),"complete"===document.readyState?$t():document.addEventListener("readystatechange",()=>{"complete"===document.readyState&&$t()})),zt.then((function(){e&&e()})))}))}const Ut="__shadyCSSCachedStyle";let Vt=null,qt=null;class Yt{constructor(){this.customStyles=[],this.enqueued=!1,Bt(()=>{window.ShadyCSS.flushCustomStyles&&window.ShadyCSS.flushCustomStyles()})}enqueueDocumentValidation(){!this.enqueued&&qt&&(this.enqueued=!0,Bt(qt))}addCustomStyle(e){e.__seenByShadyCSS||(e.__seenByShadyCSS=!0,this.customStyles.push(e),this.enqueueDocumentValidation())}getStyleForCustomStyle(e){if(e[Ut])return e[Ut];let t;return t=e.getStyle?e.getStyle():e,t}processStyles(){const e=this.customStyles;for(let t=0;t<e.length;t++){const r=e[t];if(r[Ut])continue;const i=this.getStyleForCustomStyle(r);if(i){const e=i.__appliedElement||i;Vt&&Vt(e),r[Ut]=e}}return e}}Yt.prototype.addCustomStyle=Yt.prototype.addCustomStyle,Yt.prototype.getStyleForCustomStyle=Yt.prototype.getStyleForCustomStyle,Yt.prototype.processStyles=Yt.prototype.processStyles,Object.defineProperties(Yt.prototype,{transformCallback:{get:()=>Vt,set(e){Vt=e}},validateCallback:{get:()=>qt,set(e){let t=!1;qt||(t=!0),qt=e,t&&this.enqueueDocumentValidation()}}});const Jt=new Rt;class Gt{constructor(){this.customStyleInterface=null,Jt.invalidCallback=Ht}ensure(){this.customStyleInterface||window.ShadyCSS.CustomStyleInterface&&(this.customStyleInterface=window.ShadyCSS.CustomStyleInterface,this.customStyleInterface.transformCallback=e=>{Jt.transformCustomStyle(e)},this.customStyleInterface.validateCallback=()=>{requestAnimationFrame(()=>{this.customStyleInterface.enqueued&&this.flushCustomStyles()})})}prepareTemplate(e,t){if(this.ensure(),Ct(e))return;Dt[t]=e;let r=Jt.transformTemplate(e,t);e._styleAst=r}flushCustomStyles(){if(this.ensure(),!this.customStyleInterface)return;let e=this.customStyleInterface.processStyles();if(this.customStyleInterface.enqueued){for(let t=0;t<e.length;t++){let r=e[t],i=this.customStyleInterface.getStyleForCustomStyle(r);i&&Jt.transformCustomStyle(i)}this.customStyleInterface.enqueued=!1}}styleSubtree(e,t){if(this.ensure(),t&&Pt(e,t),e.shadowRoot){this.styleElement(e);let t=e.shadowRoot.children||e.shadowRoot.childNodes;for(let e=0;e<t.length;e++)this.styleSubtree(t[e])}else{let t=e.children||e.childNodes;for(let e=0;e<t.length;e++)this.styleSubtree(t[e])}}styleElement(e){this.ensure();let{is:t}=function(e){let t=e.localName,r="",i="";return t?t.indexOf("-")>-1?r=t:(i=t,r=e.getAttribute&&e.getAttribute("is")||""):(r=e.is,i=e.extends),{is:r,typeExtension:i}}(e),r=Dt[t];if((!r||!Ct(r))&&r&&!Ft(r)){(function(e){return!Ft(e)&&e._applyShimValidatingVersion===e[Lt]})(r)||(this.prepareTemplate(r,t),function(e){e._applyShimValidatingVersion=e[Lt],e._validating||(e._validating=!0,Mt.then((function(){e[It]=e[Lt],e._validating=!1})))}(r));let i=e.shadowRoot;if(i){let e=i.querySelector("style");e&&(e.__cssRules=r._styleAst,e.textContent=vt(r._styleAst))}}}styleDocument(e){this.ensure(),this.styleSubtree(document.body,e)}}if(!window.ShadyCSS||!window.ShadyCSS.ScopingShim){const e=new Gt;let t=window.ShadyCSS&&window.ShadyCSS.CustomStyleInterface;window.ShadyCSS={prepareTemplate(t,r,i){e.flushCustomStyles(),e.prepareTemplate(t,r)},prepareTemplateStyles(e,t,r){window.ShadyCSS.prepareTemplate(e,t,r)},prepareTemplateDom(e,t){},styleSubtree(t,r){e.flushCustomStyles(),e.styleSubtree(t,r)},styleElement(t){e.flushCustomStyles(),e.styleElement(t)},styleDocument(t){e.flushCustomStyles(),e.styleDocument(t)},getComputedStyleValue:(e,t)=>St(e,t),flushCustomStyles(){e.flushCustomStyles()},nativeCss:it,nativeShadow:Ke,cssBuild:et,disableRuntime:rt},t&&(window.ShadyCSS.CustomStyleInterface=t)}window.ShadyCSS.ApplyShim=Jt,window.JSCompiler_renameProperty=function(e,t){return e};let Wt,Zt,Xt=/(url\()([^)]*)(\))/g,Kt=/(^\/[^\/])|(^#)|(^[\w-\d]*:)/;function Qt(e,t){if(e&&Kt.test(e))return e;if("//"===e)return e;if(void 0===Wt){Wt=!1;try{const e=new URL("b","http://a");e.pathname="c%20d",Wt="http://a/c%20d"===e.href}catch(e){}}if(t||(t=document.baseURI||window.location.href),Wt)try{return new URL(e,t).href}catch(t){return e}return Zt||(Zt=document.implementation.createHTMLDocument("temp"),Zt.base=Zt.createElement("base"),Zt.head.appendChild(Zt.base),Zt.anchor=Zt.createElement("a"),Zt.body.appendChild(Zt.anchor)),Zt.base.href=t,Zt.anchor.href=e,Zt.anchor.href||e}function er(e,t){return e.replace(Xt,(function(e,r,i,o){return r+"'"+Qt(i.replace(/["']/g,""),t)+"'"+o}))}function tr(e){return e.substring(0,e.lastIndexOf("/")+1)}const rr=!window.ShadyDOM||!window.ShadyDOM.inUse;Boolean(!window.ShadyCSS||window.ShadyCSS.nativeCss);const ir=rr&&"adoptedStyleSheets"in Document.prototype&&"replaceSync"in CSSStyleSheet.prototype&&(()=>{try{const e=new CSSStyleSheet;e.replaceSync("");const t=document.createElement("div");return t.attachShadow({mode:"open"}),t.shadowRoot.adoptedStyleSheets=[e],t.shadowRoot.adoptedStyleSheets[0]===e}catch(e){return!1}})();let or=window.Polymer&&window.Polymer.rootPath||tr(document.baseURI||window.location.href),nr=window.Polymer&&window.Polymer.sanitizeDOMValue||void 0,ar=window.Polymer&&window.Polymer.setPassiveTouchGestures||!1,sr=window.Polymer&&window.Polymer.strictTemplatePolicy||!1,lr=window.Polymer&&window.Polymer.allowTemplateFromDomModule||!1,cr=window.Polymer&&window.Polymer.legacyOptimizations||!1,dr=window.Polymer&&window.Polymer.legacyWarnings||!1,pr=window.Polymer&&window.Polymer.syncInitialRender||!1,hr=window.Polymer&&window.Polymer.legacyUndefined||!1,ur=window.Polymer&&window.Polymer.orderedComputed||!1,fr=window.Polymer&&window.Polymer.removeNestedTemplates||!1,mr=window.Polymer&&window.Polymer.fastDomIf||!1,gr=window.Polymer&&window.Polymer.suppressTemplateNotifications||!1,yr=window.Polymer&&window.Polymer.legacyNoObservedAttributes||!1,_r=window.Polymer&&window.Polymer.useAdoptedStyleSheetsWithBuiltCSS||!1,br=0;const vr=function(e){let t=e.__mixinApplications;t||(t=new WeakMap,e.__mixinApplications=t);let r=br++;return function(i){let o=i.__mixinSet;if(o&&o[r])return i;let n=t,a=n.get(i);if(!a){a=e(i),n.set(i,a);let t=Object.create(a.__mixinSet||o||null);t[r]=!0,a.__mixinSet=t}return a}};let wr={},xr={};function kr(e,t){wr[e]=xr[e.toLowerCase()]=t}function Cr(e){return wr[e]||xr[e.toLowerCase()]}class Pr extends HTMLElement{static get observedAttributes(){return["id"]}static import(e,t){if(e){let r=Cr(e);return r&&t?r.querySelector(t):r}return null}attributeChangedCallback(e,t,r,i){t!==r&&this.register()}get assetpath(){if(!this.__assetpath){const e=window.HTMLImports&&HTMLImports.importForElement?HTMLImports.importForElement(this)||document:this.ownerDocument,t=Qt(this.getAttribute("assetpath")||"",e.baseURI);this.__assetpath=tr(t)}return this.__assetpath}register(e){if(e=e||this.id){if(sr&&void 0!==Cr(e))throw kr(e,null),new Error(`strictTemplatePolicy: dom-module ${e} re-registered`);this.id=e,kr(e,this),(t=this).querySelector("style")&&console.warn("dom-module %s has style outside template",t.id)}var t}}Pr.prototype.modules=wr,customElements.define("dom-module",Pr);function Sr(e){return Pr.import(e)}function Ar(e){const t=er((e.body?e.body:e).textContent,e.baseURI),r=document.createElement("style");return r.textContent=t,r}function Er(e){const t=e.trim().split(/\s+/),r=[];for(let e=0;e<t.length;e++)r.push(...Or(t[e]));return r}function Or(e){const t=Sr(e);if(!t)return console.warn("Could not find style data in module named",e),[];if(void 0===t._styles){const e=[];e.push(...Nr(t));const r=t.querySelector("template");r&&e.push(...Tr(r,t.assetpath)),t._styles=e}return t._styles}function Tr(e,t){if(!e._styles){const r=[],i=e.content.querySelectorAll("style");for(let e=0;e<i.length;e++){let o=i[e],n=o.getAttribute("include");n&&r.push(...Er(n).filter((function(e,t,r){return r.indexOf(e)===t}))),t&&(o.textContent=er(o.textContent,t)),r.push(o)}e._styles=r}return e._styles}function Nr(e){const t=[],r=e.querySelectorAll("link[rel=import][type~=css]");for(let e=0;e<r.length;e++){let i=r[e];if(i.import){const e=i.import,r=i.hasAttribute("shady-unscoped");if(r&&!e._unscopedStyle){const t=Ar(e);t.setAttribute("shady-unscoped",""),e._unscopedStyle=t}else e._style||(e._style=Ar(e));t.push(r?e._unscopedStyle:e._style)}}return t}function Rr(e){let t=Sr(e);if(t&&void 0===t._cssText){let e=function(e){let t="",r=Nr(e);for(let e=0;e<r.length;e++)t+=r[e].textContent;return t}(t),r=t.querySelector("template");r&&(e+=function(e,t){let r="";const i=Tr(e,t);for(let e=0;e<i.length;e++){let t=i[e];t.parentNode&&t.parentNode.removeChild(t),r+=t.textContent}return r}(r,t.assetpath)),t._cssText=e||null}return t||console.warn("Could not find style data in module named",e),t&&t._cssText||""}const Dr=window.ShadyDOM&&window.ShadyDOM.noPatch&&window.ShadyDOM.wrap?window.ShadyDOM.wrap:window.ShadyDOM?e=>ShadyDOM.patch(e):e=>e;function Ir(e){return e.indexOf(".")>=0}function Lr(e){let t=e.indexOf(".");return-1===t?e:e.slice(0,t)}function Mr(e,t){return 0===e.indexOf(t+".")}function Hr(e,t){return 0===t.indexOf(e+".")}function Fr(e,t,r){return t+r.slice(e.length)}function $r(e){if(Array.isArray(e)){let t=[];for(let r=0;r<e.length;r++){let i=e[r].toString().split(".");for(let e=0;e<i.length;e++)t.push(i[e])}return t.join(".")}return e}function zr(e){return Array.isArray(e)?$r(e).split("."):e.toString().split(".")}function jr(e,t,r){let i=e,o=zr(t);for(let e=0;e<o.length;e++){if(!i)return;i=i[o[e]]}return r&&(r.path=o.join(".")),i}function Br(e,t,r){let i=e,o=zr(t),n=o[o.length-1];if(o.length>1){for(let e=0;e<o.length-1;e++){if(i=i[o[e]],!i)return}i[n]=r}else i[t]=r;return o.join(".")}const Ur={},Vr=/-[a-z]/g,qr=/([A-Z])/g;function Yr(e){return Ur[e]||(Ur[e]=e.indexOf("-")<0?e:e.replace(Vr,e=>e[1].toUpperCase()))}function Jr(e){return Ur[e]||(Ur[e]=e.replace(qr,"-$1").toLowerCase())}let Gr=0,Wr=0,Zr=[],Xr=0,Kr=!1,Qr=document.createTextNode("");new window.MutationObserver((function(){Kr=!1;const e=Zr.length;for(let t=0;t<e;t++){let e=Zr[t];if(e)try{e()}catch(e){setTimeout(()=>{throw e})}}Zr.splice(0,e),Wr+=e})).observe(Qr,{characterData:!0});const ei={after:e=>({run:t=>window.setTimeout(t,e),cancel(e){window.clearTimeout(e)}}),run:(e,t)=>window.setTimeout(e,t),cancel(e){window.clearTimeout(e)}},ti={run:e=>window.requestAnimationFrame(e),cancel(e){window.cancelAnimationFrame(e)}},ri={run:e=>(Kr||(Kr=!0,Qr.textContent=Xr++),Zr.push(e),Gr++),cancel(e){const t=e-Wr;if(t>=0){if(!Zr[t])throw new Error("invalid async handle: "+e);Zr[t]=null}}},ii=ri,oi=vr(e=>class extends e{static createProperties(e){const t=this.prototype;for(let r in e)r in t||t._createPropertyAccessor(r)}static attributeNameForProperty(e){return e.toLowerCase()}static typeForProperty(e){}_createPropertyAccessor(e,t){this._addPropertyToAttributeMap(e),this.hasOwnProperty(JSCompiler_renameProperty("__dataHasAccessor",this))||(this.__dataHasAccessor=Object.assign({},this.__dataHasAccessor)),this.__dataHasAccessor[e]||(this.__dataHasAccessor[e]=!0,this._definePropertyAccessor(e,t))}_addPropertyToAttributeMap(e){this.hasOwnProperty(JSCompiler_renameProperty("__dataAttributes",this))||(this.__dataAttributes=Object.assign({},this.__dataAttributes));let t=this.__dataAttributes[e];return t||(t=this.constructor.attributeNameForProperty(e),this.__dataAttributes[t]=e),t}_definePropertyAccessor(e,t){Object.defineProperty(this,e,{get(){return this.__data[e]},set:t?function(){}:function(t){this._setPendingProperty(e,t,!0)&&this._invalidateProperties()}})}constructor(){super(),this.__dataEnabled=!1,this.__dataReady=!1,this.__dataInvalid=!1,this.__data={},this.__dataPending=null,this.__dataOld=null,this.__dataInstanceProps=null,this.__dataCounter=0,this.__serializing=!1,this._initializeProperties()}ready(){this.__dataReady=!0,this._flushProperties()}_initializeProperties(){for(let e in this.__dataHasAccessor)this.hasOwnProperty(e)&&(this.__dataInstanceProps=this.__dataInstanceProps||{},this.__dataInstanceProps[e]=this[e],delete this[e])}_initializeInstanceProperties(e){Object.assign(this,e)}_setProperty(e,t){this._setPendingProperty(e,t)&&this._invalidateProperties()}_getProperty(e){return this.__data[e]}_setPendingProperty(e,t,r){let i=this.__data[e],o=this._shouldPropertyChange(e,t,i);return o&&(this.__dataPending||(this.__dataPending={},this.__dataOld={}),this.__dataOld&&!(e in this.__dataOld)&&(this.__dataOld[e]=i),this.__data[e]=t,this.__dataPending[e]=t),o}_isPropertyPending(e){return!(!this.__dataPending||!this.__dataPending.hasOwnProperty(e))}_invalidateProperties(){!this.__dataInvalid&&this.__dataReady&&(this.__dataInvalid=!0,ii.run(()=>{this.__dataInvalid&&(this.__dataInvalid=!1,this._flushProperties())}))}_enableProperties(){this.__dataEnabled||(this.__dataEnabled=!0,this.__dataInstanceProps&&(this._initializeInstanceProperties(this.__dataInstanceProps),this.__dataInstanceProps=null),this.ready())}_flushProperties(){this.__dataCounter++;const e=this.__data,t=this.__dataPending,r=this.__dataOld;this._shouldPropertiesChange(e,t,r)&&(this.__dataPending=null,this.__dataOld=null,this._propertiesChanged(e,t,r)),this.__dataCounter--}_shouldPropertiesChange(e,t,r){return Boolean(t)}_propertiesChanged(e,t,r){}_shouldPropertyChange(e,t,r){return r!==t&&(r==r||t==t)}attributeChangedCallback(e,t,r,i){t!==r&&this._attributeToProperty(e,r),super.attributeChangedCallback&&super.attributeChangedCallback(e,t,r,i)}_attributeToProperty(e,t,r){if(!this.__serializing){const i=this.__dataAttributes,o=i&&i[e]||e;this[o]=this._deserializeValue(t,r||this.constructor.typeForProperty(o))}}_propertyToAttribute(e,t,r){this.__serializing=!0,r=arguments.length<3?this[e]:r,this._valueToNodeAttribute(this,r,t||this.constructor.attributeNameForProperty(e)),this.__serializing=!1}_valueToNodeAttribute(e,t,r){const i=this._serializeValue(t);"class"!==r&&"name"!==r&&"slot"!==r||(e=Dr(e)),void 0===i?e.removeAttribute(r):e.setAttribute(r,i)}_serializeValue(e){switch(typeof e){case"boolean":return e?"":void 0;default:return null!=e?e.toString():void 0}}_deserializeValue(e,t){switch(t){case Boolean:return null!==e;case Number:return Number(e);default:return e}}}),ni={};let ai=HTMLElement.prototype;for(;ai;){let e=Object.getOwnPropertyNames(ai);for(let t=0;t<e.length;t++)ni[e[t]]=!0;ai=Object.getPrototypeOf(ai)}const si=vr(e=>{const t=oi(e);return class extends t{static createPropertiesForAttributes(){let e=this.observedAttributes;for(let t=0;t<e.length;t++)this.prototype._createPropertyAccessor(Yr(e[t]))}static attributeNameForProperty(e){return Jr(e)}_initializeProperties(){this.__dataProto&&(this._initializeProtoProperties(this.__dataProto),this.__dataProto=null),super._initializeProperties()}_initializeProtoProperties(e){for(let t in e)this._setProperty(t,e[t])}_ensureAttribute(e,t){const r=this;r.hasAttribute(e)||this._valueToNodeAttribute(r,t,e)}_serializeValue(e){switch(typeof e){case"object":if(e instanceof Date)return e.toString();if(e)try{return JSON.stringify(e)}catch(e){return""}default:return super._serializeValue(e)}}_deserializeValue(e,t){let r;switch(t){case Object:try{r=JSON.parse(e)}catch(t){r=e}break;case Array:try{r=JSON.parse(e)}catch(t){r=null,console.warn("Polymer::Attributes: couldn't decode Array as JSON: "+e)}break;case Date:r=isNaN(e)?String(e):Number(e),r=new Date(r);break;default:r=super._deserializeValue(e,t)}return r}_definePropertyAccessor(e,t){!function(e,t){if(!ni[t]){let r=e[t];void 0!==r&&(e.__data?e._setPendingProperty(t,r):(e.__dataProto?e.hasOwnProperty(JSCompiler_renameProperty("__dataProto",e))||(e.__dataProto=Object.create(e.__dataProto)):e.__dataProto={},e.__dataProto[t]=r))}}(this,e),super._definePropertyAccessor(e,t)}_hasAccessor(e){return this.__dataHasAccessor&&this.__dataHasAccessor[e]}_isPropertyPending(e){return Boolean(this.__dataPending&&e in this.__dataPending)}}}),li={"dom-if":!0,"dom-repeat":!0};let ci=!1,di=!1;function pi(e){(function(){if(!ci){ci=!0;const e=document.createElement("textarea");e.placeholder="a",di=e.placeholder===e.textContent}return di})()&&"textarea"===e.localName&&e.placeholder&&e.placeholder===e.textContent&&(e.textContent=null)}function hi(e){let t=e.getAttribute("is");if(t&&li[t]){let r=e;for(r.removeAttribute("is"),e=r.ownerDocument.createElement(t),r.parentNode.replaceChild(e,r),e.appendChild(r);r.attributes.length;)e.setAttribute(r.attributes[0].name,r.attributes[0].value),r.removeAttribute(r.attributes[0].name)}return e}function ui(e,t){let r=t.parentInfo&&ui(e,t.parentInfo);if(!r)return e;for(let e=r.firstChild,i=0;e;e=e.nextSibling)if(t.parentIndex===i++)return e}function fi(e,t,r,i){i.id&&(t[i.id]=r)}function mi(e,t,r){if(r.events&&r.events.length)for(let i,o=0,n=r.events;o<n.length&&(i=n[o]);o++)e._addMethodEventListenerToNode(t,i.name,i.value,e)}function gi(e,t,r,i){r.templateInfo&&(t._templateInfo=r.templateInfo,t._parentTemplateInfo=i)}const yi=vr(e=>class extends e{static _parseTemplate(e,t){if(!e._templateInfo){let r=e._templateInfo={};r.nodeInfoList=[],r.nestedTemplate=Boolean(t),r.stripWhiteSpace=t&&t.stripWhiteSpace||e.hasAttribute("strip-whitespace"),this._parseTemplateContent(e,r,{parent:null})}return e._templateInfo}static _parseTemplateContent(e,t,r){return this._parseTemplateNode(e.content,t,r)}static _parseTemplateNode(e,t,r){let i=!1,o=e;return"template"!=o.localName||o.hasAttribute("preserve-content")?"slot"===o.localName&&(t.hasInsertionPoint=!0):i=this._parseTemplateNestedTemplate(o,t,r)||i,pi(o),o.firstChild&&this._parseTemplateChildNodes(o,t,r),o.hasAttributes&&o.hasAttributes()&&(i=this._parseTemplateNodeAttributes(o,t,r)||i),i||r.noted}static _parseTemplateChildNodes(e,t,r){if("script"!==e.localName&&"style"!==e.localName)for(let i,o=e.firstChild,n=0;o;o=i){if("template"==o.localName&&(o=hi(o)),i=o.nextSibling,o.nodeType===Node.TEXT_NODE){let r=i;for(;r&&r.nodeType===Node.TEXT_NODE;)o.textContent+=r.textContent,i=r.nextSibling,e.removeChild(r),r=i;if(t.stripWhiteSpace&&!o.textContent.trim()){e.removeChild(o);continue}}let a={parentIndex:n,parentInfo:r};this._parseTemplateNode(o,t,a)&&(a.infoIndex=t.nodeInfoList.push(a)-1),o.parentNode&&n++}}static _parseTemplateNestedTemplate(e,t,r){let i=e,o=this._parseTemplate(i,t);return(o.content=i.content.ownerDocument.createDocumentFragment()).appendChild(i.content),r.templateInfo=o,!0}static _parseTemplateNodeAttributes(e,t,r){let i=!1,o=Array.from(e.attributes);for(let n,a=o.length-1;n=o[a];a--)i=this._parseTemplateNodeAttribute(e,t,r,n.name,n.value)||i;return i}static _parseTemplateNodeAttribute(e,t,r,i,o){return"on-"===i.slice(0,3)?(e.removeAttribute(i),r.events=r.events||[],r.events.push({name:i.slice(3),value:o}),!0):"id"===i&&(r.id=o,!0)}static _contentForTemplate(e){let t=e._templateInfo;return t&&t.content||e.content}_stampTemplate(e,t){e&&!e.content&&window.HTMLTemplateElement&&HTMLTemplateElement.decorate&&HTMLTemplateElement.decorate(e);let r=(t=t||this.constructor._parseTemplate(e)).nodeInfoList,i=t.content||e.content,o=document.importNode(i,!0);o.__noInsertionPoint=!t.hasInsertionPoint;let n=o.nodeList=new Array(r.length);o.$={};for(let e,i=0,a=r.length;i<a&&(e=r[i]);i++){let r=n[i]=ui(o,e);fi(0,o.$,r,e),gi(0,r,e,t),mi(this,r,e)}return o=o,o}_addMethodEventListenerToNode(e,t,r,i){let o=function(e,t,r){return e=e._methodHost||e,function(t){e[r]?e[r](t,t.detail):console.warn("listener method `"+r+"` not defined")}}(i=i||e,0,r);return this._addEventListenerToNode(e,t,o),o}_addEventListenerToNode(e,t,r){e.addEventListener(t,r)}_removeEventListenerFromNode(e,t,r){e.removeEventListener(t,r)}});let _i=0;const bi=[],vi={COMPUTE:"__computeEffects",REFLECT:"__reflectEffects",NOTIFY:"__notifyEffects",PROPAGATE:"__propagateEffects",OBSERVE:"__observeEffects",READ_ONLY:"__readOnly"},wi=/[A-Z]/;function xi(e,t,r){let i=e[t];if(i){if(!e.hasOwnProperty(t)&&(i=e[t]=Object.create(e[t]),r))for(let e in i){let t=i[e],r=i[e]=Array(t.length);for(let e=0;e<t.length;e++)r[e]=t[e]}}else i=e[t]={};return i}function ki(e,t,r,i,o,n){if(t){let a=!1;const s=_i++;for(let l in r){let c=t[o?Lr(l):l];if(c)for(let t,d=0,p=c.length;d<p&&(t=c[d]);d++)t.info&&t.info.lastRun===s||o&&!Pi(l,t.trigger)||(t.info&&(t.info.lastRun=s),t.fn(e,l,r,i,t.info,o,n),a=!0)}return a}return!1}function Ci(e,t,r,i,o,n,a,s){let l=!1,c=t[a?Lr(i):i];if(c)for(let t,d=0,p=c.length;d<p&&(t=c[d]);d++)t.info&&t.info.lastRun===r||a&&!Pi(i,t.trigger)||(t.info&&(t.info.lastRun=r),t.fn(e,i,o,n,t.info,a,s),l=!0);return l}function Pi(e,t){if(t){let r=t.name;return r==e||!(!t.structured||!Mr(r,e))||!(!t.wildcard||!Hr(r,e))}return!0}function Si(e,t,r,i,o){let n="string"==typeof o.method?e[o.method]:o.method,a=o.property;n?n.call(e,e.__data[a],i[a]):o.dynamicFn||console.warn("observer method `"+o.method+"` not defined")}function Ai(e,t,r){let i=Lr(t);if(i!==t){return Ei(e,Jr(i)+"-changed",r[t],t),!0}return!1}function Ei(e,t,r,i){let o={value:r,queueProperty:!0};i&&(o.path=i),Dr(e).dispatchEvent(new CustomEvent(t,{detail:o}))}function Oi(e,t,r,i,o,n){let a=(n?Lr(t):t)!=t?t:null,s=a?jr(e,a):e.__data[t];a&&void 0===s&&(s=r[t]),Ei(e,o.eventName,s,a)}function Ti(e,t,r,i,o){let n=e.__data[t];nr&&(n=nr(n,o.attrName,"attribute",e)),e._propertyToAttribute(t,o.attrName,n)}function Ni(e,t,r,i){let o=e[vi.COMPUTE];if(o)if(ur){_i++;const n=function(e){let t=e.constructor.__orderedComputedDeps;if(!t){t=new Map;const r=e[vi.COMPUTE];let i,{counts:o,ready:n,total:a}=function(e){const t=e.__computeInfo,r={},i=e[vi.COMPUTE],o=[];let n=0;for(let e in t){const i=t[e];n+=r[e]=i.args.filter(e=>!e.literal).length+(i.dynamicFn?1:0)}for(let e in i)t[e]||o.push(e);return{counts:r,ready:o,total:n}}(e);for(;i=n.shift();){t.set(i,t.size);const e=r[i];e&&e.forEach(e=>{const t=e.info.methodInfo;--a,0==--o[t]&&n.push(t)})}if(0!==a){const t=e;console.warn(`Computed graph for ${t.localName} incomplete; circular?`)}e.constructor.__orderedComputedDeps=t}return t}(e),a=[];for(let e in t)Di(e,o,a,n,i);let s;for(;s=a.shift();)Ii(e,"",t,r,s)&&Di(s.methodInfo,o,a,n,i);Object.assign(r,e.__dataOld),Object.assign(t,e.__dataPending),e.__dataPending=null}else{let n=t;for(;ki(e,o,n,r,i);)Object.assign(r,e.__dataOld),Object.assign(t,e.__dataPending),n=e.__dataPending,e.__dataPending=null}}const Ri=(e,t,r)=>{let i=0,o=t.length-1,n=-1;for(;i<=o;){const a=i+o>>1,s=r.get(t[a].methodInfo)-r.get(e.methodInfo);if(s<0)i=a+1;else{if(!(s>0)){n=a;break}o=a-1}}n<0&&(n=o+1),t.splice(n,0,e)},Di=(e,t,r,i,o)=>{const n=t[o?Lr(e):e];if(n)for(let t=0;t<n.length;t++){const a=n[t];a.info.lastRun===_i||o&&!Pi(e,a.trigger)||(a.info.lastRun=_i,Ri(a.info,r,i))}};function Ii(e,t,r,i,o){let n=ji(e,t,r,i,o);if(n===bi)return!1;let a=o.methodInfo;return e.__dataHasAccessor&&e.__dataHasAccessor[a]?e._setPendingProperty(a,n,!0):(e[a]=n,!1)}function Li(e,t,r,i,o,n,a){r.bindings=r.bindings||[];let s={kind:i,target:o,parts:n,literal:a,isCompound:1!==n.length};if(r.bindings.push(s),function(e){return Boolean(e.target)&&"attribute"!=e.kind&&"text"!=e.kind&&!e.isCompound&&"{"===e.parts[0].mode}(s)){let{event:e,negate:t}=s.parts[0];s.listenerEvent=e||Jr(o)+"-changed",s.listenerNegate=t}let l=t.nodeInfoList.length;for(let r=0;r<s.parts.length;r++){let i=s.parts[r];i.compoundIndex=r,Mi(e,t,s,i,l)}}function Mi(e,t,r,i,o){if(!i.literal)if("attribute"===r.kind&&"-"===r.target[0])console.warn("Cannot set attribute "+r.target+' because "-" is not a valid attribute starting character');else{let n=i.dependencies,a={index:o,binding:r,part:i,evaluator:e};for(let r=0;r<n.length;r++){let i=n[r];"string"==typeof i&&(i=Yi(i),i.wildcard=!0),e._addTemplatePropertyEffect(t,i.rootProperty,{fn:Hi,info:a,trigger:i})}}}function Hi(e,t,r,i,o,n,a){let s=a[o.index],l=o.binding,c=o.part;if(n&&c.source&&t.length>c.source.length&&"property"==l.kind&&!l.isCompound&&s.__isPropertyEffectsClient&&s.__dataHasAccessor&&s.__dataHasAccessor[l.target]){let i=r[t];t=Fr(c.source,l.target,t),s._setPendingPropertyOrPath(t,i,!1,!0)&&e._enqueueClient(s)}else{let a=o.evaluator._evaluateBinding(e,c,t,r,i,n);a!==bi&&function(e,t,r,i,o){o=function(e,t,r,i){if(r.isCompound){let o=e.__dataCompoundStorage[r.target];o[i.compoundIndex]=t,t=o.join("")}"attribute"!==r.kind&&("textContent"!==r.target&&("value"!==r.target||"input"!==e.localName&&"textarea"!==e.localName)||(t=null==t?"":t));return t}(t,o,r,i),nr&&(o=nr(o,r.target,r.kind,t));if("attribute"==r.kind)e._valueToNodeAttribute(t,o,r.target);else{let i=r.target;t.__isPropertyEffectsClient&&t.__dataHasAccessor&&t.__dataHasAccessor[i]?t[vi.READ_ONLY]&&t[vi.READ_ONLY][i]||t._setPendingProperty(i,o)&&e._enqueueClient(t):e._setUnmanagedPropertyToNode(t,i,o)}}(e,s,l,c,a)}}function Fi(e,t){if(t.isCompound){let r=e.__dataCompoundStorage||(e.__dataCompoundStorage={}),i=t.parts,o=new Array(i.length);for(let e=0;e<i.length;e++)o[e]=i[e].literal;let n=t.target;r[n]=o,t.literal&&"property"==t.kind&&("className"===n&&(e=Dr(e)),e[n]=t.literal)}}function $i(e,t,r){if(r.listenerEvent){let i=r.parts[0];e.addEventListener(r.listenerEvent,(function(e){!function(e,t,r,i,o){let n,a=e.detail,s=a&&a.path;s?(i=Fr(r,i,s),n=a&&a.value):n=e.currentTarget[r],n=o?!n:n,t[vi.READ_ONLY]&&t[vi.READ_ONLY][i]||!t._setPendingPropertyOrPath(i,n,!0,Boolean(s))||a&&a.queueProperty||t._invalidateProperties()}(e,t,r.target,i.source,i.negate)}))}}function zi(e,t,r,i,o,n){n=t.static||n&&("object"!=typeof n||n[t.methodName]);let a={methodName:t.methodName,args:t.args,methodInfo:o,dynamicFn:n};for(let o,n=0;n<t.args.length&&(o=t.args[n]);n++)o.literal||e._addPropertyEffect(o.rootProperty,r,{fn:i,info:a,trigger:o});return n&&e._addPropertyEffect(t.methodName,r,{fn:i,info:a}),a}function ji(e,t,r,i,o){let n=e._methodHost||e,a=n[o.methodName];if(a){let i=e._marshalArgs(o.args,t,r);return i===bi?bi:a.apply(n,i)}o.dynamicFn||console.warn("method `"+o.methodName+"` not defined")}const Bi=[],Ui=new RegExp("(\\[\\[|{{)\\s*(?:(!)\\s*)?((?:[a-zA-Z_$][\\w.:$\\-*]*)\\s*(?:\\(\\s*(?:(?:(?:((?:[a-zA-Z_$][\\w.:$\\-*]*)|(?:[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?)|(?:(?:'(?:[^'\\\\]|\\\\.)*')|(?:\"(?:[^\"\\\\]|\\\\.)*\")))\\s*)(?:,\\s*(?:((?:[a-zA-Z_$][\\w.:$\\-*]*)|(?:[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?)|(?:(?:'(?:[^'\\\\]|\\\\.)*')|(?:\"(?:[^\"\\\\]|\\\\.)*\")))\\s*))*)?)\\)\\s*)?)(?:]]|}})","g");function Vi(e){let t="";for(let r=0;r<e.length;r++){t+=e[r].literal||""}return t}function qi(e){let t=e.match(/([^\s]+?)\(([\s\S]*)\)/);if(t){let e={methodName:t[1],static:!0,args:Bi};if(t[2].trim()){return function(e,t){return t.args=e.map((function(e){let r=Yi(e);return r.literal||(t.static=!1),r}),this),t}(t[2].replace(/\\,/g,"&comma;").split(","),e)}return e}return null}function Yi(e){let t=e.trim().replace(/&comma;/g,",").replace(/\\(.)/g,"$1"),r={name:t,value:"",literal:!1},i=t[0];switch("-"===i&&(i=t[1]),i>="0"&&i<="9"&&(i="#"),i){case"'":case'"':r.value=t.slice(1,-1),r.literal=!0;break;case"#":r.value=Number(t),r.literal=!0}return r.literal||(r.rootProperty=Lr(t),r.structured=Ir(t),r.structured&&(r.wildcard=".*"==t.slice(-2),r.wildcard&&(r.name=t.slice(0,-2)))),r}function Ji(e,t,r){let i=jr(e,r);return void 0===i&&(i=t[r]),i}function Gi(e,t,r,i){const o={indexSplices:i};hr&&!e._overrideLegacyUndefined&&(t.splices=o),e.notifyPath(r+".splices",o),e.notifyPath(r+".length",t.length),hr&&!e._overrideLegacyUndefined&&(o.indexSplices=[])}function Wi(e,t,r,i,o,n){Gi(e,t,r,[{index:i,addedCount:o,removed:n,object:t,type:"splice"}])}const Zi=vr(e=>{const t=yi(si(e));return class extends t{constructor(){super(),this.__isPropertyEffectsClient=!0,this.__dataClientsReady,this.__dataPendingClients,this.__dataToNotify,this.__dataLinkedPaths,this.__dataHasPaths,this.__dataCompoundStorage,this.__dataHost,this.__dataTemp,this.__dataClientsInitialized,this.__data,this.__dataPending,this.__dataOld,this.__computeEffects,this.__computeInfo,this.__reflectEffects,this.__notifyEffects,this.__propagateEffects,this.__observeEffects,this.__readOnly,this.__templateInfo,this._overrideLegacyUndefined}get PROPERTY_EFFECT_TYPES(){return vi}_initializeProperties(){super._initializeProperties(),this._registerHost(),this.__dataClientsReady=!1,this.__dataPendingClients=null,this.__dataToNotify=null,this.__dataLinkedPaths=null,this.__dataHasPaths=!1,this.__dataCompoundStorage=this.__dataCompoundStorage||null,this.__dataHost=this.__dataHost||null,this.__dataTemp={},this.__dataClientsInitialized=!1}_registerHost(){if(Xi.length){let e=Xi[Xi.length-1];e._enqueueClient(this),this.__dataHost=e}}_initializeProtoProperties(e){this.__data=Object.create(e),this.__dataPending=Object.create(e),this.__dataOld={}}_initializeInstanceProperties(e){let t=this[vi.READ_ONLY];for(let r in e)t&&t[r]||(this.__dataPending=this.__dataPending||{},this.__dataOld=this.__dataOld||{},this.__data[r]=this.__dataPending[r]=e[r])}_addPropertyEffect(e,t,r){this._createPropertyAccessor(e,t==vi.READ_ONLY);let i=xi(this,t,!0)[e];i||(i=this[t][e]=[]),i.push(r)}_removePropertyEffect(e,t,r){let i=xi(this,t,!0)[e],o=i.indexOf(r);o>=0&&i.splice(o,1)}_hasPropertyEffect(e,t){let r=this[t];return Boolean(r&&r[e])}_hasReadOnlyEffect(e){return this._hasPropertyEffect(e,vi.READ_ONLY)}_hasNotifyEffect(e){return this._hasPropertyEffect(e,vi.NOTIFY)}_hasReflectEffect(e){return this._hasPropertyEffect(e,vi.REFLECT)}_hasComputedEffect(e){return this._hasPropertyEffect(e,vi.COMPUTE)}_setPendingPropertyOrPath(e,t,r,i){if(i||Lr(Array.isArray(e)?e[0]:e)!==e){if(!i){let r=jr(this,e);if(!(e=Br(this,e,t))||!super._shouldPropertyChange(e,t,r))return!1}if(this.__dataHasPaths=!0,this._setPendingProperty(e,t,r))return function(e,t,r){let i=e.__dataLinkedPaths;if(i){let o;for(let n in i){let a=i[n];Hr(n,t)?(o=Fr(n,a,t),e._setPendingPropertyOrPath(o,r,!0,!0)):Hr(a,t)&&(o=Fr(a,n,t),e._setPendingPropertyOrPath(o,r,!0,!0))}}}(this,e,t),!0}else{if(this.__dataHasAccessor&&this.__dataHasAccessor[e])return this._setPendingProperty(e,t,r);this[e]=t}return!1}_setUnmanagedPropertyToNode(e,t,r){r===e[t]&&"object"!=typeof r||("className"===t&&(e=Dr(e)),e[t]=r)}_setPendingProperty(e,t,r){let i=this.__dataHasPaths&&Ir(e),o=i?this.__dataTemp:this.__data;return!!this._shouldPropertyChange(e,t,o[e])&&(this.__dataPending||(this.__dataPending={},this.__dataOld={}),e in this.__dataOld||(this.__dataOld[e]=this.__data[e]),i?this.__dataTemp[e]=t:this.__data[e]=t,this.__dataPending[e]=t,(i||this[vi.NOTIFY]&&this[vi.NOTIFY][e])&&(this.__dataToNotify=this.__dataToNotify||{},this.__dataToNotify[e]=r),!0)}_setProperty(e,t){this._setPendingProperty(e,t,!0)&&this._invalidateProperties()}_invalidateProperties(){this.__dataReady&&this._flushProperties()}_enqueueClient(e){this.__dataPendingClients=this.__dataPendingClients||[],e!==this&&this.__dataPendingClients.push(e)}_flushClients(){this.__dataClientsReady?this.__enableOrFlushClients():(this.__dataClientsReady=!0,this._readyClients(),this.__dataReady=!0)}__enableOrFlushClients(){let e=this.__dataPendingClients;if(e){this.__dataPendingClients=null;for(let t=0;t<e.length;t++){let r=e[t];r.__dataEnabled?r.__dataPending&&r._flushProperties():r._enableProperties()}}}_readyClients(){this.__enableOrFlushClients()}setProperties(e,t){for(let r in e)!t&&this[vi.READ_ONLY]&&this[vi.READ_ONLY][r]||this._setPendingPropertyOrPath(r,e[r],!0);this._invalidateProperties()}ready(){this._flushProperties(),this.__dataClientsReady||this._flushClients(),this.__dataPending&&this._flushProperties()}_propertiesChanged(e,t,r){let i,o=this.__dataHasPaths;this.__dataHasPaths=!1,Ni(this,t,r,o),i=this.__dataToNotify,this.__dataToNotify=null,this._propagatePropertyChanges(t,r,o),this._flushClients(),ki(this,this[vi.REFLECT],t,r,o),ki(this,this[vi.OBSERVE],t,r,o),i&&function(e,t,r,i,o){let n,a,s=e[vi.NOTIFY],l=_i++;for(let a in t)t[a]&&(s&&Ci(e,s,l,a,r,i,o)||o&&Ai(e,a,r))&&(n=!0);n&&(a=e.__dataHost)&&a._invalidateProperties&&a._invalidateProperties()}(this,i,t,r,o),1==this.__dataCounter&&(this.__dataTemp={})}_propagatePropertyChanges(e,t,r){this[vi.PROPAGATE]&&ki(this,this[vi.PROPAGATE],e,t,r),this.__templateInfo&&this._runEffectsForTemplate(this.__templateInfo,e,t,r)}_runEffectsForTemplate(e,t,r,i){const o=(t,i)=>{ki(this,e.propertyEffects,t,r,i,e.nodeList);for(let o=e.firstChild;o;o=o.nextSibling)this._runEffectsForTemplate(o,t,r,i)};e.runEffects?e.runEffects(o,t,i):o(t,i)}linkPaths(e,t){e=$r(e),t=$r(t),this.__dataLinkedPaths=this.__dataLinkedPaths||{},this.__dataLinkedPaths[e]=t}unlinkPaths(e){e=$r(e),this.__dataLinkedPaths&&delete this.__dataLinkedPaths[e]}notifySplices(e,t){let r={path:""};Gi(this,jr(this,e,r),r.path,t)}get(e,t){return jr(t||this,e)}set(e,t,r){r?Br(r,e,t):this[vi.READ_ONLY]&&this[vi.READ_ONLY][e]||this._setPendingPropertyOrPath(e,t,!0)&&this._invalidateProperties()}push(e,...t){let r={path:""},i=jr(this,e,r),o=i.length,n=i.push(...t);return t.length&&Wi(this,i,r.path,o,t.length,[]),n}pop(e){let t={path:""},r=jr(this,e,t),i=Boolean(r.length),o=r.pop();return i&&Wi(this,r,t.path,r.length,0,[o]),o}splice(e,t,r,...i){let o,n={path:""},a=jr(this,e,n);return t<0?t=a.length-Math.floor(-t):t&&(t=Math.floor(t)),o=2===arguments.length?a.splice(t):a.splice(t,r,...i),(i.length||o.length)&&Wi(this,a,n.path,t,i.length,o),o}shift(e){let t={path:""},r=jr(this,e,t),i=Boolean(r.length),o=r.shift();return i&&Wi(this,r,t.path,0,0,[o]),o}unshift(e,...t){let r={path:""},i=jr(this,e,r),o=i.unshift(...t);return t.length&&Wi(this,i,r.path,0,t.length,[]),o}notifyPath(e,t){let r;if(1==arguments.length){let i={path:""};t=jr(this,e,i),r=i.path}else r=Array.isArray(e)?$r(e):e;this._setPendingPropertyOrPath(r,t,!0,!0)&&this._invalidateProperties()}_createReadOnlyProperty(e,t){var r;this._addPropertyEffect(e,vi.READ_ONLY),t&&(this["_set"+(r=e,r[0].toUpperCase()+r.substring(1))]=function(t){this._setProperty(e,t)})}_createPropertyObserver(e,t,r){let i={property:e,method:t,dynamicFn:Boolean(r)};this._addPropertyEffect(e,vi.OBSERVE,{fn:Si,info:i,trigger:{name:e}}),r&&this._addPropertyEffect(t,vi.OBSERVE,{fn:Si,info:i,trigger:{name:t}})}_createMethodObserver(e,t){let r=qi(e);if(!r)throw new Error("Malformed observer expression '"+e+"'");zi(this,r,vi.OBSERVE,ji,null,t)}_createNotifyingProperty(e){this._addPropertyEffect(e,vi.NOTIFY,{fn:Oi,info:{eventName:Jr(e)+"-changed",property:e}})}_createReflectedProperty(e){let t=this.constructor.attributeNameForProperty(e);"-"===t[0]?console.warn("Property "+e+" cannot be reflected to attribute "+t+' because "-" is not a valid starting attribute name. Use a lowercase first letter for the property instead.'):this._addPropertyEffect(e,vi.REFLECT,{fn:Ti,info:{attrName:t}})}_createComputedProperty(e,t,r){let i=qi(t);if(!i)throw new Error("Malformed computed expression '"+t+"'");const o=zi(this,i,vi.COMPUTE,Ii,e,r);xi(this,"__computeInfo")[e]=o}_marshalArgs(e,t,r){const i=this.__data,o=[];for(let n=0,a=e.length;n<a;n++){let{name:a,structured:s,wildcard:l,value:c,literal:d}=e[n];if(!d)if(l){const e=Hr(a,t),o=Ji(i,r,e?t:a);c={path:e?t:a,value:o,base:e?jr(i,a):o}}else c=s?Ji(i,r,a):i[a];if(hr&&!this._overrideLegacyUndefined&&void 0===c&&e.length>1)return bi;o[n]=c}return o}static addPropertyEffect(e,t,r){this.prototype._addPropertyEffect(e,t,r)}static createPropertyObserver(e,t,r){this.prototype._createPropertyObserver(e,t,r)}static createMethodObserver(e,t){this.prototype._createMethodObserver(e,t)}static createNotifyingProperty(e){this.prototype._createNotifyingProperty(e)}static createReadOnlyProperty(e,t){this.prototype._createReadOnlyProperty(e,t)}static createReflectedProperty(e){this.prototype._createReflectedProperty(e)}static createComputedProperty(e,t,r){this.prototype._createComputedProperty(e,t,r)}static bindTemplate(e){return this.prototype._bindTemplate(e)}_bindTemplate(e,t){let r=this.constructor._parseTemplate(e),i=this.__preBoundTemplateInfo==r;if(!i)for(let e in r.propertyEffects)this._createPropertyAccessor(e);if(t)if(r=Object.create(r),r.wasPreBound=i,this.__templateInfo){const t=e._parentTemplateInfo||this.__templateInfo,i=t.lastChild;r.parent=t,t.lastChild=r,r.previousSibling=i,i?i.nextSibling=r:t.firstChild=r}else this.__templateInfo=r;else this.__preBoundTemplateInfo=r;return r}static _addTemplatePropertyEffect(e,t,r){(e.hostProps=e.hostProps||{})[t]=!0;let i=e.propertyEffects=e.propertyEffects||{};(i[t]=i[t]||[]).push(r)}_stampTemplate(e,t){t=t||this._bindTemplate(e,!0),Xi.push(this);let r=super._stampTemplate(e,t);if(Xi.pop(),t.nodeList=r.nodeList,!t.wasPreBound){let e=t.childNodes=[];for(let t=r.firstChild;t;t=t.nextSibling)e.push(t)}return r.templateInfo=t,function(e,t){let{nodeList:r,nodeInfoList:i}=t;if(i.length)for(let t=0;t<i.length;t++){let o=i[t],n=r[t],a=o.bindings;if(a)for(let t=0;t<a.length;t++){let r=a[t];Fi(n,r),$i(n,e,r)}n.__dataHost=e}}(this,t),this.__dataClientsReady&&(this._runEffectsForTemplate(t,this.__data,null,!1),this._flushClients()),r}_removeBoundDom(e){const t=e.templateInfo,{previousSibling:r,nextSibling:i,parent:o}=t;r?r.nextSibling=i:o&&(o.firstChild=i),i?i.previousSibling=r:o&&(o.lastChild=r),t.nextSibling=t.previousSibling=null;let n=t.childNodes;for(let e=0;e<n.length;e++){let t=n[e];Dr(Dr(t).parentNode).removeChild(t)}}static _parseTemplateNode(e,r,i){let o=t._parseTemplateNode.call(this,e,r,i);if(e.nodeType===Node.TEXT_NODE){let t=this._parseBindings(e.textContent,r);t&&(e.textContent=Vi(t)||" ",Li(this,r,i,"text","textContent",t),o=!0)}return o}static _parseTemplateNodeAttribute(e,r,i,o,n){let a=this._parseBindings(n,r);if(a){let t=o,n="property";wi.test(o)?n="attribute":"$"==o[o.length-1]&&(o=o.slice(0,-1),n="attribute");let s=Vi(a);return s&&"attribute"==n&&("class"==o&&e.hasAttribute("class")&&(s+=" "+e.getAttribute(o)),e.setAttribute(o,s)),"attribute"==n&&"disable-upgrade$"==t&&e.setAttribute(o,""),"input"===e.localName&&"value"===t&&e.setAttribute(t,""),e.removeAttribute(t),"property"===n&&(o=Yr(o)),Li(this,r,i,n,o,a,s),!0}return t._parseTemplateNodeAttribute.call(this,e,r,i,o,n)}static _parseTemplateNestedTemplate(e,r,i){let o=t._parseTemplateNestedTemplate.call(this,e,r,i);const n=e.parentNode,a=i.templateInfo,s="dom-if"===n.localName,l="dom-repeat"===n.localName;fr&&(s||l)&&(n.removeChild(e),(i=i.parentInfo).templateInfo=a,i.noted=!0,o=!1);let c=a.hostProps;if(mr&&s)c&&(r.hostProps=Object.assign(r.hostProps||{},c),fr||(i.parentInfo.noted=!0));else{let e="{";for(let t in c){Li(this,r,i,"property","_host_"+t,[{mode:e,source:t,dependencies:[t],hostProp:!0}])}}return o}static _parseBindings(e,t){let r,i=[],o=0;for(;null!==(r=Ui.exec(e));){r.index>o&&i.push({literal:e.slice(o,r.index)});let n=r[1][0],a=Boolean(r[2]),s=r[3].trim(),l=!1,c="",d=-1;"{"==n&&(d=s.indexOf("::"))>0&&(c=s.substring(d+2),s=s.substring(0,d),l=!0);let p=qi(s),h=[];if(p){let{args:e,methodName:r}=p;for(let t=0;t<e.length;t++){let r=e[t];r.literal||h.push(r)}let i=t.dynamicFns;(i&&i[r]||p.static)&&(h.push(r),p.dynamicFn=!0)}else h.push(s);i.push({source:s,mode:n,negate:a,customEvent:l,signature:p,dependencies:h,event:c}),o=Ui.lastIndex}if(o&&o<e.length){let t=e.substring(o);t&&i.push({literal:t})}return i.length?i:null}static _evaluateBinding(e,t,r,i,o,n){let a;return a=t.signature?ji(e,r,i,0,t.signature):r!=t.source?jr(e,t.source):n&&Ir(r)?jr(e,r):e.__data[r],t.negate&&(a=!a),a}}}),Xi=[];const Ki=vr(e=>{const t=oi(e);function r(e){const t=Object.getPrototypeOf(e);return t.prototype instanceof o?t:null}function i(e){if(!e.hasOwnProperty(JSCompiler_renameProperty("__ownProperties",e))){let t=null;if(e.hasOwnProperty(JSCompiler_renameProperty("properties",e))){const r=e.properties;r&&(t=function(e){const t={};for(let r in e){const i=e[r];t[r]="function"==typeof i?{type:i}:i}return t}(r))}e.__ownProperties=t}return e.__ownProperties}class o extends t{static get observedAttributes(){if(!this.hasOwnProperty(JSCompiler_renameProperty("__observedAttributes",this))){this.prototype;const e=this._properties;this.__observedAttributes=e?Object.keys(e).map(e=>this.prototype._addPropertyToAttributeMap(e)):[]}return this.__observedAttributes}static finalize(){if(!this.hasOwnProperty(JSCompiler_renameProperty("__finalized",this))){const e=r(this);e&&e.finalize(),this.__finalized=!0,this._finalizeClass()}}static _finalizeClass(){const e=i(this);e&&this.createProperties(e)}static get _properties(){if(!this.hasOwnProperty(JSCompiler_renameProperty("__properties",this))){const e=r(this);this.__properties=Object.assign({},e&&e._properties,i(this))}return this.__properties}static typeForProperty(e){const t=this._properties[e];return t&&t.type}_initializeProperties(){this.constructor.finalize(),super._initializeProperties()}connectedCallback(){super.connectedCallback&&super.connectedCallback(),this._enableProperties()}disconnectedCallback(){super.disconnectedCallback&&super.disconnectedCallback()}}return o}),Qi=window.ShadyCSS&&window.ShadyCSS.cssBuild,eo=vr(e=>{const t=Ki(Zi(e));function r(e,t,r,i){r.computed&&(r.readOnly=!0),r.computed&&(e._hasReadOnlyEffect(t)?console.warn(`Cannot redefine computed property '${t}'.`):e._createComputedProperty(t,r.computed,i)),r.readOnly&&!e._hasReadOnlyEffect(t)?e._createReadOnlyProperty(t,!r.computed):!1===r.readOnly&&e._hasReadOnlyEffect(t)&&console.warn(`Cannot make readOnly property '${t}' non-readOnly.`),r.reflectToAttribute&&!e._hasReflectEffect(t)?e._createReflectedProperty(t):!1===r.reflectToAttribute&&e._hasReflectEffect(t)&&console.warn(`Cannot make reflected property '${t}' non-reflected.`),r.notify&&!e._hasNotifyEffect(t)?e._createNotifyingProperty(t):!1===r.notify&&e._hasNotifyEffect(t)&&console.warn(`Cannot make notify property '${t}' non-notify.`),r.observer&&e._createPropertyObserver(t,r.observer,i[r.observer]),e._addPropertyToAttributeMap(t)}function i(e,t,r,i){if(!Qi){const o=t.content.querySelectorAll("style"),n=Tr(t),a=function(e){let t=Sr(e);return t?Nr(t):[]}(r),s=t.content.firstElementChild;for(let r=0;r<a.length;r++){let o=a[r];o.textContent=e._processStyleText(o.textContent,i),t.content.insertBefore(o,s)}let l=0;for(let t=0;t<n.length;t++){let r=n[t],a=o[l];a!==r?(r=r.cloneNode(!0),a.parentNode.insertBefore(r,a)):l++,r.textContent=e._processStyleText(r.textContent,i)}}if(window.ShadyCSS&&window.ShadyCSS.prepareTemplate(t,r),_r&&Qi&&ir){const r=t.content.querySelectorAll("style");if(r){let t="";Array.from(r).forEach(e=>{t+=e.textContent,e.parentNode.removeChild(e)}),e._styleSheet=new CSSStyleSheet,e._styleSheet.replaceSync(t)}}}return class extends t{static get polymerElementVersion(){return"3.4.1"}static _finalizeClass(){t._finalizeClass.call(this);const e=((r=this).hasOwnProperty(JSCompiler_renameProperty("__ownObservers",r))||(r.__ownObservers=r.hasOwnProperty(JSCompiler_renameProperty("observers",r))?r.observers:null),r.__ownObservers);var r;e&&this.createObservers(e,this._properties),this._prepareTemplate()}static _prepareTemplate(){let e=this.template;e&&("string"==typeof e?(console.error("template getter must return HTMLTemplateElement"),e=null):cr||(e=e.cloneNode(!0))),this.prototype._template=e}static createProperties(e){for(let t in e)r(this.prototype,t,e[t],e)}static createObservers(e,t){const r=this.prototype;for(let i=0;i<e.length;i++)r._createMethodObserver(e[i],t)}static get template(){if(!this.hasOwnProperty(JSCompiler_renameProperty("_template",this))){const e=this.prototype.hasOwnProperty(JSCompiler_renameProperty("_template",this.prototype))?this.prototype._template:void 0;this._template=void 0!==e?e:this.hasOwnProperty(JSCompiler_renameProperty("is",this))&&function(e){let t=null;if(e&&(!sr||lr)&&(t=Pr.import(e,"template"),sr&&!t))throw new Error("strictTemplatePolicy: expecting dom-module or null template for "+e);return t}(this.is)||Object.getPrototypeOf(this.prototype).constructor.template}return this._template}static set template(e){this._template=e}static get importPath(){if(!this.hasOwnProperty(JSCompiler_renameProperty("_importPath",this))){const e=this.importMeta;if(e)this._importPath=tr(e.url);else{const e=Pr.import(this.is);this._importPath=e&&e.assetpath||Object.getPrototypeOf(this.prototype).constructor.importPath}}return this._importPath}constructor(){super(),this._template,this._importPath,this.rootPath,this.importPath,this.root,this.$}_initializeProperties(){this.constructor.finalize(),this.constructor._finalizeTemplate(this.localName),super._initializeProperties(),this.rootPath=or,this.importPath=this.constructor.importPath;let e=function(e){if(!e.hasOwnProperty(JSCompiler_renameProperty("__propertyDefaults",e))){e.__propertyDefaults=null;let t=e._properties;for(let r in t){let i=t[r];"value"in i&&(e.__propertyDefaults=e.__propertyDefaults||{},e.__propertyDefaults[r]=i)}}return e.__propertyDefaults}(this.constructor);if(e)for(let t in e){let r=e[t];if(this._canApplyPropertyDefault(t)){let e="function"==typeof r.value?r.value.call(this):r.value;this._hasAccessor(t)?this._setPendingProperty(t,e,!0):this[t]=e}}}_canApplyPropertyDefault(e){return!this.hasOwnProperty(e)}static _processStyleText(e,t){return er(e,t)}static _finalizeTemplate(e){const t=this.prototype._template;if(t&&!t.__polymerFinalized){t.__polymerFinalized=!0;const r=this.importPath;i(this,t,e,r?Qt(r):""),this.prototype._bindTemplate(t)}}connectedCallback(){window.ShadyCSS&&this._template&&window.ShadyCSS.styleElement(this),super.connectedCallback()}ready(){this._template&&(this.root=this._stampTemplate(this._template),this.$=this.root.$),super.ready()}_readyClients(){this._template&&(this.root=this._attachDom(this.root)),super._readyClients()}_attachDom(e){const t=Dr(this);if(t.attachShadow)return e?(t.shadowRoot||(t.attachShadow({mode:"open",shadyUpgradeFragment:e}),t.shadowRoot.appendChild(e),this.constructor._styleSheet&&(t.shadowRoot.adoptedStyleSheets=[this.constructor._styleSheet])),pr&&window.ShadyDOM&&window.ShadyDOM.flushInitial(t.shadowRoot),t.shadowRoot):null;throw new Error("ShadowDOM not available. PolymerElement can create dom as children instead of in ShadowDOM by setting `this.root = this;` before `ready`.")}updateStyles(e){window.ShadyCSS&&window.ShadyCSS.styleSubtree(this,e)}resolveUrl(e,t){return!t&&this.importPath&&(t=Qt(this.importPath)),Qt(e,t)}static _parseTemplateContent(e,r,i){return r.dynamicFns=r.dynamicFns||this._properties,t._parseTemplateContent.call(this,e,r,i)}static _addTemplatePropertyEffect(e,r,i){return!dr||r in this._properties||i.info.part.signature&&i.info.part.signature.static||i.info.part.hostProp||e.nestedTemplate||console.warn(`Property '${r}' used in template but not declared in 'properties'; attribute will not be observed.`),t._addTemplatePropertyEffect.call(this,e,r,i)}}});class to{constructor(){this._asyncModule=null,this._callback=null,this._timer=null}setConfig(e,t){this._asyncModule=e,this._callback=t,this._timer=this._asyncModule.run(()=>{this._timer=null,ro.delete(this),this._callback()})}cancel(){this.isActive()&&(this._cancelAsync(),ro.delete(this))}_cancelAsync(){this.isActive()&&(this._asyncModule.cancel(this._timer),this._timer=null)}flush(){this.isActive()&&(this.cancel(),this._callback())}isActive(){return null!=this._timer}static debounce(e,t,r){return e instanceof to?e._cancelAsync():e=new to,e.setConfig(t,r),e}}let ro=new Set;const io=function(e){ro.add(e)},oo=function(){const e=Boolean(ro.size);return ro.forEach(e=>{try{e.flush()}catch(e){setTimeout(()=>{throw e})}}),e};let no="string"==typeof document.head.style.touchAction,ao="__polymerGesturesHandled",so="__polymerGesturesTouchAction",lo=["mousedown","mousemove","mouseup","click"],co=[0,1,4,2],po=function(){try{return 1===new MouseEvent("test",{buttons:1}).buttons}catch(e){return!1}}();function ho(e){return lo.indexOf(e)>-1}let uo=!1;function fo(e){if(!ho(e)&&"touchend"!==e)return no&&uo&&ar?{passive:!0}:void 0}!function(){try{let e=Object.defineProperty({},"passive",{get(){uo=!0}});window.addEventListener("test",null,e),window.removeEventListener("test",null,e)}catch(e){}}();let mo=navigator.userAgent.match(/iP(?:[oa]d|hone)|Android/);const go=[],yo={button:!0,input:!0,keygen:!0,meter:!0,output:!0,textarea:!0,progress:!0,select:!0},_o={button:!0,command:!0,fieldset:!0,input:!0,keygen:!0,optgroup:!0,option:!0,select:!0,textarea:!0};function bo(e){let t=Array.prototype.slice.call(e.labels||[]);if(!t.length){t=[];let r=e.getRootNode();if(e.id){let i=r.querySelectorAll(`label[for = ${e.id}]`);for(let e=0;e<i.length;e++)t.push(i[e])}}return t}let vo=function(e){let t=e.sourceCapabilities;var r;if((!t||t.firesTouchEvents)&&(e[ao]={skip:!0},"click"===e.type)){let t=!1,i=So(e);for(let e=0;e<i.length;e++){if(i[e].nodeType===Node.ELEMENT_NODE)if("label"===i[e].localName)go.push(i[e]);else if(r=i[e],yo[r.localName]){let r=bo(i[e]);for(let e=0;e<r.length;e++)t=t||go.indexOf(r[e])>-1}if(i[e]===ko.mouse.target)return}if(t)return;e.preventDefault(),e.stopPropagation()}};function wo(e){let t=mo?["click"]:lo;for(let r,i=0;i<t.length;i++)r=t[i],e?(go.length=0,document.addEventListener(r,vo,!0)):document.removeEventListener(r,vo,!0)}function xo(e){let t=e.type;if(!ho(t))return!1;if("mousemove"===t){let t=void 0===e.buttons?1:e.buttons;return e instanceof window.MouseEvent&&!po&&(t=co[e.which]||0),Boolean(1&t)}return 0===(void 0===e.button?0:e.button)}let ko={mouse:{target:null,mouseIgnoreJob:null},touch:{x:0,y:0,id:-1,scrollDecided:!1}};function Co(e,t,r){e.movefn=t,e.upfn=r,document.addEventListener("mousemove",t),document.addEventListener("mouseup",r)}function Po(e){document.removeEventListener("mousemove",e.movefn),document.removeEventListener("mouseup",e.upfn),e.movefn=null,e.upfn=null}document.addEventListener("touchend",(function(e){ko.mouse.mouseIgnoreJob||wo(!0),ko.mouse.target=So(e)[0],ko.mouse.mouseIgnoreJob=to.debounce(ko.mouse.mouseIgnoreJob,ei.after(2500),(function(){wo(),ko.mouse.target=null,ko.mouse.mouseIgnoreJob=null}))}),!!uo&&{passive:!0});const So=window.ShadyDOM&&window.ShadyDOM.noPatch?window.ShadyDOM.composedPath:e=>e.composedPath&&e.composedPath()||[],Ao={},Eo=[];function Oo(e){const t=So(e);return t.length>0?t[0]:e.target}function To(e){let t,r=e.type,i=e.currentTarget.__polymerGestures;if(!i)return;let o=i[r];if(o){if(!e[ao]&&(e[ao]={},"touch"===r.slice(0,5))){let t=(e=e).changedTouches[0];if("touchstart"===r&&1===e.touches.length&&(ko.touch.id=t.identifier),ko.touch.id!==t.identifier)return;no||"touchstart"!==r&&"touchmove"!==r||function(e){let t=e.changedTouches[0],r=e.type;if("touchstart"===r)ko.touch.x=t.clientX,ko.touch.y=t.clientY,ko.touch.scrollDecided=!1;else if("touchmove"===r){if(ko.touch.scrollDecided)return;ko.touch.scrollDecided=!0;let r=function(e){let t="auto",r=So(e);for(let e,i=0;i<r.length;i++)if(e=r[i],e[so]){t=e[so];break}return t}(e),i=!1,o=Math.abs(ko.touch.x-t.clientX),n=Math.abs(ko.touch.y-t.clientY);e.cancelable&&("none"===r?i=!0:"pan-x"===r?i=n>o:"pan-y"===r&&(i=o>n)),i?e.preventDefault():Mo("track")}}(e)}if(t=e[ao],!t.skip){for(let r,i=0;i<Eo.length;i++)r=Eo[i],o[r.name]&&!t[r.name]&&r.flow&&r.flow.start.indexOf(e.type)>-1&&r.reset&&r.reset();for(let i,n=0;n<Eo.length;n++)i=Eo[n],o[i.name]&&!t[i.name]&&(t[i.name]=!0,i[r](e))}}}function No(e,t,r){return!!Ao[t]&&(function(e,t,r){let i=Ao[t],o=i.deps,n=i.name,a=e.__polymerGestures;a||(e.__polymerGestures=a={});for(let t,r,i=0;i<o.length;i++)t=o[i],mo&&ho(t)&&"click"!==t||(r=a[t],r||(a[t]=r={_count:0}),0===r._count&&e.addEventListener(t,To,fo(t)),r[n]=(r[n]||0)+1,r._count=(r._count||0)+1);e.addEventListener(t,r),i.touchAction&&Io(e,i.touchAction)}(e,t,r),!0)}function Ro(e,t,r){return!!Ao[t]&&(function(e,t,r){let i=Ao[t],o=i.deps,n=i.name,a=e.__polymerGestures;if(a)for(let t,r,i=0;i<o.length;i++)t=o[i],r=a[t],r&&r[n]&&(r[n]=(r[n]||1)-1,r._count=(r._count||1)-1,0===r._count&&e.removeEventListener(t,To,fo(t)));e.removeEventListener(t,r)}(e,t,r),!0)}function Do(e){Eo.push(e);for(let t=0;t<e.emits.length;t++)Ao[e.emits[t]]=e}function Io(e,t){no&&e instanceof HTMLElement&&ri.run(()=>{e.style.touchAction=t}),e[so]=t}function Lo(e,t,r){let i=new Event(t,{bubbles:!0,cancelable:!0,composed:!0});if(i.detail=r,Dr(e).dispatchEvent(i),i.defaultPrevented){let e=r.preventer||r.sourceEvent;e&&e.preventDefault&&e.preventDefault()}}function Mo(e){let t=function(e){for(let t,r=0;r<Eo.length;r++){t=Eo[r];for(let r,i=0;i<t.emits.length;i++)if(r=t.emits[i],r===e)return t}return null}(e);t.info&&(t.info.prevent=!0)}function Ho(e,t,r,i){t&&Lo(t,e,{x:r.clientX,y:r.clientY,sourceEvent:r,preventer:i,prevent:function(e){return Mo(e)}})}function Fo(e,t,r){if(e.prevent)return!1;if(e.started)return!0;let i=Math.abs(e.x-t),o=Math.abs(e.y-r);return i>=5||o>=5}function $o(e,t,r){if(!t)return;let i,o=e.moves[e.moves.length-2],n=e.moves[e.moves.length-1],a=n.x-e.x,s=n.y-e.y,l=0;o&&(i=n.x-o.x,l=n.y-o.y),Lo(t,"track",{state:e.state,x:r.clientX,y:r.clientY,dx:a,dy:s,ddx:i,ddy:l,sourceEvent:r,hover:function(){return function(e,t){let r=document.elementFromPoint(e,t),i=r;for(;i&&i.shadowRoot&&!window.ShadyDOM;){let o=i;if(i=i.shadowRoot.elementFromPoint(e,t),o===i)break;i&&(r=i)}return r}(r.clientX,r.clientY)}})}function zo(e,t,r){let i=Math.abs(t.clientX-e.x),o=Math.abs(t.clientY-e.y),n=Oo(r||t);!n||_o[n.localName]&&n.hasAttribute("disabled")||(isNaN(i)||isNaN(o)||i<=25&&o<=25||function(e){if("click"===e.type){if(0===e.detail)return!0;let t=Oo(e);if(!t.nodeType||t.nodeType!==Node.ELEMENT_NODE)return!0;let r=t.getBoundingClientRect(),i=e.pageX,o=e.pageY;return!(i>=r.left&&i<=r.right&&o>=r.top&&o<=r.bottom)}return!1}(t))&&(e.prevent||Lo(n,"tap",{x:t.clientX,y:t.clientY,sourceEvent:t,preventer:r}))}Do({name:"downup",deps:["mousedown","touchstart","touchend"],flow:{start:["mousedown","touchstart"],end:["mouseup","touchend"]},emits:["down","up"],info:{movefn:null,upfn:null},reset:function(){Po(this.info)},mousedown:function(e){if(!xo(e))return;let t=Oo(e),r=this;Co(this.info,(function(e){xo(e)||(Ho("up",t,e),Po(r.info))}),(function(e){xo(e)&&Ho("up",t,e),Po(r.info)})),Ho("down",t,e)},touchstart:function(e){Ho("down",Oo(e),e.changedTouches[0],e)},touchend:function(e){Ho("up",Oo(e),e.changedTouches[0],e)}}),Do({name:"track",touchAction:"none",deps:["mousedown","touchstart","touchmove","touchend"],flow:{start:["mousedown","touchstart"],end:["mouseup","touchend"]},emits:["track"],info:{x:0,y:0,state:"start",started:!1,moves:[],addMove:function(e){this.moves.length>2&&this.moves.shift(),this.moves.push(e)},movefn:null,upfn:null,prevent:!1},reset:function(){this.info.state="start",this.info.started=!1,this.info.moves=[],this.info.x=0,this.info.y=0,this.info.prevent=!1,Po(this.info)},mousedown:function(e){if(!xo(e))return;let t=Oo(e),r=this,i=function(e){let i=e.clientX,o=e.clientY;Fo(r.info,i,o)&&(r.info.state=r.info.started?"mouseup"===e.type?"end":"track":"start","start"===r.info.state&&Mo("tap"),r.info.addMove({x:i,y:o}),xo(e)||(r.info.state="end",Po(r.info)),t&&$o(r.info,t,e),r.info.started=!0)};Co(this.info,i,(function(e){r.info.started&&i(e),Po(r.info)})),this.info.x=e.clientX,this.info.y=e.clientY},touchstart:function(e){let t=e.changedTouches[0];this.info.x=t.clientX,this.info.y=t.clientY},touchmove:function(e){let t=Oo(e),r=e.changedTouches[0],i=r.clientX,o=r.clientY;Fo(this.info,i,o)&&("start"===this.info.state&&Mo("tap"),this.info.addMove({x:i,y:o}),$o(this.info,t,r),this.info.state="track",this.info.started=!0)},touchend:function(e){let t=Oo(e),r=e.changedTouches[0];this.info.started&&(this.info.state="end",this.info.addMove({x:r.clientX,y:r.clientY}),$o(this.info,t,r))}}),Do({name:"tap",deps:["mousedown","click","touchstart","touchend"],flow:{start:["mousedown","touchstart"],end:["click","touchend"]},emits:["tap"],info:{x:NaN,y:NaN,prevent:!1},reset:function(){this.info.x=NaN,this.info.y=NaN,this.info.prevent=!1},mousedown:function(e){xo(e)&&(this.info.x=e.clientX,this.info.y=e.clientY)},click:function(e){xo(e)&&zo(this.info,e)},touchstart:function(e){const t=e.changedTouches[0];this.info.x=t.clientX,this.info.y=t.clientY},touchend:function(e){zo(this.info,e.changedTouches[0],e)}});const jo=Oo,Bo=vr(e=>class extends e{_addEventListenerToNode(e,t,r){No(e,t,r)||super._addEventListenerToNode(e,t,r)}_removeEventListenerFromNode(e,t,r){Ro(e,t,r)||super._removeEventListenerFromNode(e,t,r)}}),Uo=/:host\(:dir\((ltr|rtl)\)\)/g,Vo=/([\s\w-#\.\[\]\*]*):dir\((ltr|rtl)\)/g,qo=/:dir\((?:ltr|rtl)\)/,Yo=Boolean(window.ShadyDOM&&window.ShadyDOM.inUse),Jo=[];let Go=null,Wo="";function Zo(){Wo=document.documentElement.getAttribute("dir")}function Xo(e){if(!e.__autoDirOptOut){e.setAttribute("dir",Wo)}}function Ko(){Zo(),Wo=document.documentElement.getAttribute("dir");for(let e=0;e<Jo.length;e++)Xo(Jo[e])}const Qo=vr(e=>{Yo||Go||(Zo(),Go=new MutationObserver(Ko),Go.observe(document.documentElement,{attributes:!0,attributeFilter:["dir"]}));const t=si(e);class r extends t{static _processStyleText(e,r){return e=t._processStyleText.call(this,e,r),!Yo&&qo.test(e)&&(e=this._replaceDirInCssText(e),this.__activateDir=!0),e}static _replaceDirInCssText(e){let t=e;return t=t.replace(Uo,':host([dir="$1"])'),t=t.replace(Vo,':host([dir="$2"]) $1'),t}constructor(){super(),this.__autoDirOptOut=!1}ready(){super.ready(),this.__autoDirOptOut=this.hasAttribute("dir")}connectedCallback(){t.prototype.connectedCallback&&super.connectedCallback(),this.constructor.__activateDir&&(Go&&Go.takeRecords().length&&Ko(),Jo.push(this),Xo(this))}disconnectedCallback(){if(t.prototype.disconnectedCallback&&super.disconnectedCallback(),this.constructor.__activateDir){const e=Jo.indexOf(this);e>-1&&Jo.splice(e,1)}}}return r.__activateDir=!1,r});function en(){document.body.removeAttribute("unresolved")}function tn(e,t,r){return{index:e,removed:t,addedCount:r}}"interactive"===document.readyState||"complete"===document.readyState?en():window.addEventListener("DOMContentLoaded",en);function rn(e,t,r,i,o,n){let a,s=0,l=0,c=Math.min(r-t,n-o);if(0==t&&0==o&&(s=function(e,t,r){for(let i=0;i<r;i++)if(!nn(e[i],t[i]))return i;return r}(e,i,c)),r==e.length&&n==i.length&&(l=function(e,t,r){let i=e.length,o=t.length,n=0;for(;n<r&&nn(e[--i],t[--o]);)n++;return n}(e,i,c-s)),o+=s,n-=l,(r-=l)-(t+=s)==0&&n-o==0)return[];if(t==r){for(a=tn(t,[],0);o<n;)a.removed.push(i[o++]);return[a]}if(o==n)return[tn(t,[],r-t)];let d=function(e){let t=e.length-1,r=e[0].length-1,i=e[t][r],o=[];for(;t>0||r>0;){if(0==t){o.push(2),r--;continue}if(0==r){o.push(3),t--;continue}let n,a=e[t-1][r-1],s=e[t-1][r],l=e[t][r-1];n=s<l?s<a?s:a:l<a?l:a,n==a?(a==i?o.push(0):(o.push(1),i=a),t--,r--):n==s?(o.push(3),t--,i=s):(o.push(2),r--,i=l)}return o.reverse(),o}(function(e,t,r,i,o,n){let a=n-o+1,s=r-t+1,l=new Array(a);for(let e=0;e<a;e++)l[e]=new Array(s),l[e][0]=e;for(let e=0;e<s;e++)l[0][e]=e;for(let r=1;r<a;r++)for(let n=1;n<s;n++)if(nn(e[t+n-1],i[o+r-1]))l[r][n]=l[r-1][n-1];else{let e=l[r-1][n]+1,t=l[r][n-1]+1;l[r][n]=e<t?e:t}return l}(e,t,r,i,o,n));a=void 0;let p=[],h=t,u=o;for(let e=0;e<d.length;e++)switch(d[e]){case 0:a&&(p.push(a),a=void 0),h++,u++;break;case 1:a||(a=tn(h,[],0)),a.addedCount++,h++,a.removed.push(i[u]),u++;break;case 2:a||(a=tn(h,[],0)),a.addedCount++,h++;break;case 3:a||(a=tn(h,[],0)),a.removed.push(i[u]),u++}return a&&p.push(a),p}function on(e,t){return rn(e,0,e.length,t,0,t.length)}function nn(e,t){return e===t}function an(e){return"slot"===e.localName}let sn=class{static getFlattenedNodes(e){const t=Dr(e);return an(e)?(e=e,t.assignedNodes({flatten:!0})):Array.from(t.childNodes).map(e=>an(e)?Dr(e=e).assignedNodes({flatten:!0}):[e]).reduce((e,t)=>e.concat(t),[])}constructor(e,t){this._shadyChildrenObserver=null,this._nativeChildrenObserver=null,this._connected=!1,this._target=e,this.callback=t,this._effectiveNodes=[],this._observer=null,this._scheduled=!1,this._boundSchedule=()=>{this._schedule()},this.connect(),this._schedule()}connect(){an(this._target)?this._listenSlots([this._target]):Dr(this._target).children&&(this._listenSlots(Dr(this._target).children),window.ShadyDOM?this._shadyChildrenObserver=window.ShadyDOM.observeChildren(this._target,e=>{this._processMutations(e)}):(this._nativeChildrenObserver=new MutationObserver(e=>{this._processMutations(e)}),this._nativeChildrenObserver.observe(this._target,{childList:!0}))),this._connected=!0}disconnect(){an(this._target)?this._unlistenSlots([this._target]):Dr(this._target).children&&(this._unlistenSlots(Dr(this._target).children),window.ShadyDOM&&this._shadyChildrenObserver?(window.ShadyDOM.unobserveChildren(this._shadyChildrenObserver),this._shadyChildrenObserver=null):this._nativeChildrenObserver&&(this._nativeChildrenObserver.disconnect(),this._nativeChildrenObserver=null)),this._connected=!1}_schedule(){this._scheduled||(this._scheduled=!0,ri.run(()=>this.flush()))}_processMutations(e){this._processSlotMutations(e),this.flush()}_processSlotMutations(e){if(e)for(let t=0;t<e.length;t++){let r=e[t];r.addedNodes&&this._listenSlots(r.addedNodes),r.removedNodes&&this._unlistenSlots(r.removedNodes)}}flush(){if(!this._connected)return!1;window.ShadyDOM&&ShadyDOM.flush(),this._nativeChildrenObserver?this._processSlotMutations(this._nativeChildrenObserver.takeRecords()):this._shadyChildrenObserver&&this._processSlotMutations(this._shadyChildrenObserver.takeRecords()),this._scheduled=!1;let e={target:this._target,addedNodes:[],removedNodes:[]},t=this.constructor.getFlattenedNodes(this._target),r=on(t,this._effectiveNodes);for(let t,i=0;i<r.length&&(t=r[i]);i++)for(let r,i=0;i<t.removed.length&&(r=t.removed[i]);i++)e.removedNodes.push(r);for(let i,o=0;o<r.length&&(i=r[o]);o++)for(let r=i.index;r<i.index+i.addedCount;r++)e.addedNodes.push(t[r]);this._effectiveNodes=t;let i=!1;return(e.addedNodes.length||e.removedNodes.length)&&(i=!0,this.callback.call(this._target,e)),i}_listenSlots(e){for(let t=0;t<e.length;t++){let r=e[t];an(r)&&r.addEventListener("slotchange",this._boundSchedule)}}_unlistenSlots(e){for(let t=0;t<e.length;t++){let r=e[t];an(r)&&r.removeEventListener("slotchange",this._boundSchedule)}}};const ln=function(){let e,t;do{e=window.ShadyDOM&&ShadyDOM.flush(),window.ShadyCSS&&window.ShadyCSS.ScopingShim&&window.ShadyCSS.ScopingShim.flush(),t=oo()}while(e||t)},cn=Element.prototype,dn=cn.matches||cn.matchesSelector||cn.mozMatchesSelector||cn.msMatchesSelector||cn.oMatchesSelector||cn.webkitMatchesSelector,pn=function(e,t){return dn.call(e,t)};class hn{constructor(e){window.ShadyDOM&&window.ShadyDOM.inUse&&window.ShadyDOM.patch(e),this.node=e}observeNodes(e){return new sn(this.node,e)}unobserveNodes(e){e.disconnect()}notifyObserver(){}deepContains(e){if(Dr(this.node).contains(e))return!0;let t=e,r=e.ownerDocument;for(;t&&t!==r&&t!==this.node;)t=Dr(t).parentNode||Dr(t).host;return t===this.node}getOwnerRoot(){return Dr(this.node).getRootNode()}getDistributedNodes(){return"slot"===this.node.localName?Dr(this.node).assignedNodes({flatten:!0}):[]}getDestinationInsertionPoints(){let e=[],t=Dr(this.node).assignedSlot;for(;t;)e.push(t),t=Dr(t).assignedSlot;return e}importNode(e,t){let r=this.node instanceof Document?this.node:this.node.ownerDocument;return Dr(r).importNode(e,t)}getEffectiveChildNodes(){return sn.getFlattenedNodes(this.node)}queryDistributedElements(e){let t=this.getEffectiveChildNodes(),r=[];for(let i,o=0,n=t.length;o<n&&(i=t[o]);o++)i.nodeType===Node.ELEMENT_NODE&&pn(i,e)&&r.push(i);return r}get activeElement(){let e=this.node;return void 0!==e._activeElement?e._activeElement:e.activeElement}}function un(e,t){for(let r=0;r<t.length;r++){let i=t[r];Object.defineProperty(e,i,{get:function(){return this.node[i]},configurable:!0})}}class fn{constructor(e){this.event=e}get rootTarget(){return this.path[0]}get localTarget(){return this.event.target}get path(){return this.event.composedPath()}}hn.prototype.cloneNode,hn.prototype.appendChild,hn.prototype.insertBefore,hn.prototype.removeChild,hn.prototype.replaceChild,hn.prototype.setAttribute,hn.prototype.removeAttribute,hn.prototype.querySelector,hn.prototype.querySelectorAll,hn.prototype.parentNode,hn.prototype.firstChild,hn.prototype.lastChild,hn.prototype.nextSibling,hn.prototype.previousSibling,hn.prototype.firstElementChild,hn.prototype.lastElementChild,hn.prototype.nextElementSibling,hn.prototype.previousElementSibling,hn.prototype.childNodes,hn.prototype.children,hn.prototype.classList,hn.prototype.textContent,hn.prototype.innerHTML;let mn=hn;if(window.ShadyDOM&&window.ShadyDOM.inUse&&window.ShadyDOM.noPatch&&window.ShadyDOM.Wrapper){class e extends window.ShadyDOM.Wrapper{}Object.getOwnPropertyNames(hn.prototype).forEach(t=>{"activeElement"!=t&&(e.prototype[t]=hn.prototype[t])}),un(e.prototype,["classList"]),mn=e,Object.defineProperties(fn.prototype,{localTarget:{get(){const e=this.event.currentTarget,t=e&&gn(e).getOwnerRoot(),r=this.path;for(let e=0;e<r.length;e++){const i=r[e];if(gn(i).getOwnerRoot()===t)return i}},configurable:!0},path:{get(){return window.ShadyDOM.composedPath(this.event)},configurable:!0}})}else!function(e,t){for(let r=0;r<t.length;r++){let i=t[r];e[i]=function(){return this.node[i].apply(this.node,arguments)}}}(hn.prototype,["cloneNode","appendChild","insertBefore","removeChild","replaceChild","setAttribute","removeAttribute","querySelector","querySelectorAll"]),un(hn.prototype,["parentNode","firstChild","lastChild","nextSibling","previousSibling","firstElementChild","lastElementChild","nextElementSibling","previousElementSibling","childNodes","children","classList"]),function(e,t){for(let r=0;r<t.length;r++){let i=t[r];Object.defineProperty(e,i,{get:function(){return this.node[i]},set:function(e){this.node[i]=e},configurable:!0})}}(hn.prototype,["textContent","innerHTML","className"]);const gn=function(e){if((e=e||document)instanceof mn)return e;if(e instanceof fn)return e;let t=e.__domApi;return t||(t=e instanceof Event?new fn(e):new mn(e),e.__domApi=t),t},yn=window.ShadyDOM,_n=window.ShadyCSS;function bn(e,t){return Dr(e).getRootNode()===t}const vn=e=>{for(;e;){const t=Object.getOwnPropertyDescriptor(e,"observedAttributes");if(t)return t.get;e=Object.getPrototypeOf(e.prototype).constructor}return()=>[]};vr(e=>{const t=eo(e);let r=vn(t);return class extends t{constructor(){super(),this.__isUpgradeDisabled}static get observedAttributes(){return r.call(this).concat("disable-upgrade")}_initializeProperties(){this.hasAttribute("disable-upgrade")?this.__isUpgradeDisabled=!0:super._initializeProperties()}_enableProperties(){this.__isUpgradeDisabled||super._enableProperties()}_canApplyPropertyDefault(e){return super._canApplyPropertyDefault(e)&&!(this.__isUpgradeDisabled&&this._isPropertyPending(e))}attributeChangedCallback(e,t,r,i){"disable-upgrade"==e?this.__isUpgradeDisabled&&null==r&&(super._initializeProperties(),this.__isUpgradeDisabled=!1,Dr(this).isConnected&&super.connectedCallback()):super.attributeChangedCallback(e,t,r,i)}connectedCallback(){this.__isUpgradeDisabled||super.connectedCallback()}disconnectedCallback(){this.__isUpgradeDisabled||super.disconnectedCallback()}}});let wn=window.ShadyCSS;const xn=vr(e=>{const t=Bo(eo(e)),r=Qi?t:Qo(t),i=vn(r),o={x:"pan-x",y:"pan-y",none:"none",all:"auto"};class n extends r{constructor(){super(),this.isAttached,this.__boundListeners,this._debouncers,this.__isUpgradeDisabled,this.__needsAttributesAtConnected,this._legacyForceObservedAttributes}static get importMeta(){return this.prototype.importMeta}created(){}__attributeReaction(e,t,r){(this.__dataAttributes&&this.__dataAttributes[e]||"disable-upgrade"===e)&&this.attributeChangedCallback(e,t,r,null)}setAttribute(e,t){if(yr&&!this._legacyForceObservedAttributes){const r=this.getAttribute(e);super.setAttribute(e,t),this.__attributeReaction(e,r,String(t))}else super.setAttribute(e,t)}removeAttribute(e){if(yr&&!this._legacyForceObservedAttributes){const t=this.getAttribute(e);super.removeAttribute(e),this.__attributeReaction(e,t,null)}else super.removeAttribute(e)}static get observedAttributes(){return yr&&!this.prototype._legacyForceObservedAttributes?(this.hasOwnProperty(JSCompiler_renameProperty("__observedAttributes",this))||(this.__observedAttributes=[],this.prototype),this.__observedAttributes):i.call(this).concat("disable-upgrade")}_enableProperties(){this.__isUpgradeDisabled||super._enableProperties()}_canApplyPropertyDefault(e){return super._canApplyPropertyDefault(e)&&!(this.__isUpgradeDisabled&&this._isPropertyPending(e))}connectedCallback(){this.__needsAttributesAtConnected&&this._takeAttributes(),this.__isUpgradeDisabled||(super.connectedCallback(),this.isAttached=!0,this.attached())}attached(){}disconnectedCallback(){this.__isUpgradeDisabled||(super.disconnectedCallback(),this.isAttached=!1,this.detached())}detached(){}attributeChangedCallback(e,t,r,i){t!==r&&("disable-upgrade"==e?this.__isUpgradeDisabled&&null==r&&(this._initializeProperties(),this.__isUpgradeDisabled=!1,Dr(this).isConnected&&this.connectedCallback()):(super.attributeChangedCallback(e,t,r,i),this.attributeChanged(e,t,r)))}attributeChanged(e,t,r){}_initializeProperties(){if(cr&&this.hasAttribute("disable-upgrade"))this.__isUpgradeDisabled=!0;else{let e=Object.getPrototypeOf(this);e.hasOwnProperty(JSCompiler_renameProperty("__hasRegisterFinished",e))||(this._registered(),e.__hasRegisterFinished=!0),super._initializeProperties(),this.root=this,this.created(),yr&&!this._legacyForceObservedAttributes&&(this.hasAttributes()?this._takeAttributes():this.parentNode||(this.__needsAttributesAtConnected=!0)),this._applyListeners()}}_takeAttributes(){const e=this.attributes;for(let t=0,r=e.length;t<r;t++){const r=e[t];this.__attributeReaction(r.name,null,r.value)}}_registered(){}ready(){this._ensureAttributes(),super.ready()}_ensureAttributes(){}_applyListeners(){}serialize(e){return this._serializeValue(e)}deserialize(e,t){return this._deserializeValue(e,t)}reflectPropertyToAttribute(e,t,r){this._propertyToAttribute(e,t,r)}serializeValueToAttribute(e,t,r){this._valueToNodeAttribute(r||this,e,t)}extend(e,t){if(!e||!t)return e||t;let r=Object.getOwnPropertyNames(t);for(let i,o=0;o<r.length&&(i=r[o]);o++){let r=Object.getOwnPropertyDescriptor(t,i);r&&Object.defineProperty(e,i,r)}return e}mixin(e,t){for(let r in t)e[r]=t[r];return e}chainObject(e,t){return e&&t&&e!==t&&(e.__proto__=t),e}instanceTemplate(e){let t=this.constructor._contentForTemplate(e);return document.importNode(t,!0)}fire(e,t,r){r=r||{},t=null==t?{}:t;let i=new Event(e,{bubbles:void 0===r.bubbles||r.bubbles,cancelable:Boolean(r.cancelable),composed:void 0===r.composed||r.composed});i.detail=t;let o=r.node||this;return Dr(o).dispatchEvent(i),i}listen(e,t,r){e=e||this;let i=this.__boundListeners||(this.__boundListeners=new WeakMap),o=i.get(e);o||(o={},i.set(e,o));let n=t+r;o[n]||(o[n]=this._addMethodEventListenerToNode(e,t,r,this))}unlisten(e,t,r){e=e||this;let i=this.__boundListeners&&this.__boundListeners.get(e),o=t+r,n=i&&i[o];n&&(this._removeEventListenerFromNode(e,t,n),i[o]=null)}setScrollDirection(e,t){Io(t||this,o[e]||"auto")}$$(e){return this.root.querySelector(e)}get domHost(){let e=Dr(this).getRootNode();return e instanceof DocumentFragment?e.host:e}distributeContent(){const e=gn(this);window.ShadyDOM&&e.shadowRoot&&ShadyDOM.flush()}getEffectiveChildNodes(){return gn(this).getEffectiveChildNodes()}queryDistributedElements(e){return gn(this).queryDistributedElements(e)}getEffectiveChildren(){return this.getEffectiveChildNodes().filter((function(e){return e.nodeType===Node.ELEMENT_NODE}))}getEffectiveTextContent(){let e=this.getEffectiveChildNodes(),t=[];for(let r,i=0;r=e[i];i++)r.nodeType!==Node.COMMENT_NODE&&t.push(r.textContent);return t.join("")}queryEffectiveChildren(e){let t=this.queryDistributedElements(e);return t&&t[0]}queryAllEffectiveChildren(e){return this.queryDistributedElements(e)}getContentChildNodes(e){let t=this.root.querySelector(e||"slot");return t?gn(t).getDistributedNodes():[]}getContentChildren(e){return this.getContentChildNodes(e).filter((function(e){return e.nodeType===Node.ELEMENT_NODE}))}isLightDescendant(e){return this!==e&&Dr(this).contains(e)&&Dr(this).getRootNode()===Dr(e).getRootNode()}isLocalDescendant(e){return this.root===Dr(e).getRootNode()}scopeSubtree(e,t=!1){return function(e,t=!1){if(!yn||!_n)return null;if(!yn.handlesDynamicScoping)return null;const r=_n.ScopingShim;if(!r)return null;const i=r.scopeForNode(e),o=Dr(e).getRootNode(),n=e=>{if(!bn(e,o))return;const t=Array.from(yn.nativeMethods.querySelectorAll.call(e,"*"));t.push(e);for(let e=0;e<t.length;e++){const n=t[e];if(!bn(n,o))continue;const a=r.currentScopeForNode(n);a!==i&&(""!==a&&r.unscopeNode(n,a),r.scopeNode(n,i))}};if(n(e),t){const t=new MutationObserver(e=>{for(let t=0;t<e.length;t++){const r=e[t];for(let e=0;e<r.addedNodes.length;e++){const t=r.addedNodes[e];t.nodeType===Node.ELEMENT_NODE&&n(t)}}});return t.observe(e,{childList:!0,subtree:!0}),t}return null}(e,t)}getComputedStyleValue(e){return wn.getComputedStyleValue(this,e)}debounce(e,t,r){return this._debouncers=this._debouncers||{},this._debouncers[e]=to.debounce(this._debouncers[e],r>0?ei.after(r):ri,t.bind(this))}isDebouncerActive(e){this._debouncers=this._debouncers||{};let t=this._debouncers[e];return!(!t||!t.isActive())}flushDebouncer(e){this._debouncers=this._debouncers||{};let t=this._debouncers[e];t&&t.flush()}cancelDebouncer(e){this._debouncers=this._debouncers||{};let t=this._debouncers[e];t&&t.cancel()}async(e,t){return t>0?ei.run(e.bind(this),t):~ri.run(e.bind(this))}cancelAsync(e){e<0?ri.cancel(~e):ei.cancel(e)}create(e,t){let r=document.createElement(e);if(t)if(r.setProperties)r.setProperties(t);else for(let e in t)r[e]=t[e];return r}elementMatches(e,t){return pn(t||this,e)}toggleAttribute(e,t){let r=this;return 3===arguments.length&&(r=arguments[2]),1==arguments.length&&(t=!r.hasAttribute(e)),t?(Dr(r).setAttribute(e,""),!0):(Dr(r).removeAttribute(e),!1)}toggleClass(e,t,r){r=r||this,1==arguments.length&&(t=!r.classList.contains(e)),t?r.classList.add(e):r.classList.remove(e)}transform(e,t){(t=t||this).style.webkitTransform=e,t.style.transform=e}translate3d(e,t,r,i){i=i||this,this.transform("translate3d("+e+","+t+","+r+")",i)}arrayDelete(e,t){let r;if(Array.isArray(e)){if(r=e.indexOf(t),r>=0)return e.splice(r,1)}else{if(r=jr(this,e).indexOf(t),r>=0)return this.splice(e,r,1)}return null}_logger(e,t){switch(Array.isArray(t)&&1===t.length&&Array.isArray(t[0])&&(t=t[0]),e){case"log":case"warn":case"error":console[e](...t)}}_log(...e){this._logger("log",e)}_warn(...e){this._logger("warn",e)}_error(...e){this._logger("error",e)}_logf(e,...t){return["[%s::%s]",this.is,e,...t]}}return n.prototype.is="",n}),kn={attached:!0,detached:!0,ready:!0,created:!0,beforeRegister:!0,registered:!0,attributeChanged:!0,listeners:!0,hostAttributes:!0},Cn={attached:!0,detached:!0,ready:!0,created:!0,beforeRegister:!0,registered:!0,attributeChanged:!0,behaviors:!0,_noAccessors:!0},Pn=Object.assign({listeners:!0,hostAttributes:!0,properties:!0,observers:!0},Cn);function Sn(e,t,r,i){!function(e,t,r){const i=e._noAccessors,o=Object.getOwnPropertyNames(e);for(let n=0;n<o.length;n++){let a=o[n];if(!(a in r))if(i)t[a]=e[a];else{let r=Object.getOwnPropertyDescriptor(e,a);r&&(r.configurable=!0,Object.defineProperty(t,a,r))}}}(t,e,i);for(let e in kn)t[e]&&(r[e]=r[e]||[],r[e].push(t[e]))}function An(e,t){for(const r in t){const i=e[r],o=t[r];e[r]=!("value"in o)&&i&&"value"in i?Object.assign({value:i.value},o):o}}const En=xn(HTMLElement);function On(e,t,r){let i;const o={};class n extends t{static _finalizeClass(){if(this.hasOwnProperty(JSCompiler_renameProperty("generatedFrom",this))){if(i)for(let e,t=0;t<i.length;t++)e=i[t],e.properties&&this.createProperties(e.properties),e.observers&&this.createObservers(e.observers,e.properties);e.properties&&this.createProperties(e.properties),e.observers&&this.createObservers(e.observers,e.properties),this._prepareTemplate()}else t._finalizeClass.call(this)}static get properties(){const t={};if(i)for(let e=0;e<i.length;e++)An(t,i[e].properties);return An(t,e.properties),t}static get observers(){let t=[];if(i)for(let e,r=0;r<i.length;r++)e=i[r],e.observers&&(t=t.concat(e.observers));return e.observers&&(t=t.concat(e.observers)),t}created(){super.created();const e=o.created;if(e)for(let t=0;t<e.length;t++)e[t].call(this)}_registered(){const e=n.prototype;if(!e.hasOwnProperty(JSCompiler_renameProperty("__hasRegisterFinished",e))){e.__hasRegisterFinished=!0,super._registered(),cr&&a(e);const t=Object.getPrototypeOf(this);let r=o.beforeRegister;if(r)for(let e=0;e<r.length;e++)r[e].call(t);if(r=o.registered,r)for(let e=0;e<r.length;e++)r[e].call(t)}}_applyListeners(){super._applyListeners();const e=o.listeners;if(e)for(let t=0;t<e.length;t++){const r=e[t];if(r)for(let e in r)this._addMethodEventListenerToNode(this,e,r[e])}}_ensureAttributes(){const e=o.hostAttributes;if(e)for(let t=e.length-1;t>=0;t--){const r=e[t];for(let e in r)this._ensureAttribute(e,r[e])}super._ensureAttributes()}ready(){super.ready();let e=o.ready;if(e)for(let t=0;t<e.length;t++)e[t].call(this)}attached(){super.attached();let e=o.attached;if(e)for(let t=0;t<e.length;t++)e[t].call(this)}detached(){super.detached();let e=o.detached;if(e)for(let t=0;t<e.length;t++)e[t].call(this)}attributeChanged(e,t,r){super.attributeChanged();let i=o.attributeChanged;if(i)for(let o=0;o<i.length;o++)i[o].call(this,e,t,r)}}if(r){Array.isArray(r)||(r=[r]);let e=t.prototype.behaviors;i=function e(t,r,i){r=r||[];for(let o=t.length-1;o>=0;o--){let n=t[o];n?Array.isArray(n)?e(n,r):r.indexOf(n)<0&&(!i||i.indexOf(n)<0)&&r.unshift(n):console.warn("behavior is null, check for missing or 404 import")}return r}(r,null,e),n.prototype.behaviors=e?e.concat(r):i}const a=t=>{i&&function(e,t,r){for(let i=0;i<t.length;i++)Sn(e,t[i],r,Pn)}(t,i,o),Sn(t,e,o,Cn)};return cr||a(n.prototype),n.generatedFrom=e,n}const Tn=function(e){let t;return t="function"==typeof e?e:Tn.Class(e),e._legacyForceObservedAttributes&&(t.prototype._legacyForceObservedAttributes=e._legacyForceObservedAttributes),customElements.define(t.is,t),t};function Nn(e,t,r,i,o){let n;o&&(n="object"==typeof r&&null!==r,n&&(i=e.__dataTemp[t]));let a=i!==r&&(i==i||r==r);return n&&a&&(e.__dataTemp[t]=r),a}Tn.Class=function(e,t){e||console.warn("Polymer.Class requires `info` argument");let r=t?t(En):En;return r=On(e,r,e.behaviors),r.is=r.prototype.is=e.is,r};const Rn=vr(e=>class extends e{_shouldPropertyChange(e,t,r){return Nn(this,e,t,r,!0)}}),Dn=vr(e=>class extends e{static get properties(){return{mutableData:Boolean}}_shouldPropertyChange(e,t,r){return Nn(this,e,t,r,this.mutableData)}});Rn._mutablePropertyChange=Nn;let In=null;function Ln(){return In}Ln.prototype=Object.create(HTMLTemplateElement.prototype,{constructor:{value:Ln,writable:!0}});const Mn=Zi(Ln),Hn=Rn(Mn);const Fn=Zi(class{});function $n(e,t){for(let r=0;r<t.length;r++){let i=t[r];if(Boolean(e)!=Boolean(i.__hideTemplateChildren__))if(i.nodeType===Node.TEXT_NODE)e?(i.__polymerTextContent__=i.textContent,i.textContent=""):i.textContent=i.__polymerTextContent__;else if("slot"===i.localName)if(e)i.__polymerReplaced__=document.createComment("hidden-slot"),Dr(Dr(i).parentNode).replaceChild(i.__polymerReplaced__,i);else{const e=i.__polymerReplaced__;e&&Dr(Dr(e).parentNode).replaceChild(i,e)}else i.style&&(e?(i.__polymerDisplay__=i.style.display,i.style.display="none"):i.style.display=i.__polymerDisplay__);i.__hideTemplateChildren__=e,i._showHideChildren&&i._showHideChildren(e)}}class zn extends Fn{constructor(e){super(),this._configureProperties(e),this.root=this._stampTemplate(this.__dataHost);let t=[];this.children=t;for(let e=this.root.firstChild;e;e=e.nextSibling)t.push(e),e.__templatizeInstance=this;this.__templatizeOwner&&this.__templatizeOwner.__hideTemplateChildren__&&this._showHideChildren(!0);let r=this.__templatizeOptions;(e&&r.instanceProps||!r.instanceProps)&&this._enableProperties()}_configureProperties(e){if(this.__templatizeOptions.forwardHostProp)for(let e in this.__hostProps)this._setPendingProperty(e,this.__dataHost["_host_"+e]);for(let t in e)this._setPendingProperty(t,e[t])}forwardHostProp(e,t){this._setPendingPropertyOrPath(e,t,!1,!0)&&this.__dataHost._enqueueClient(this)}_addEventListenerToNode(e,t,r){if(this._methodHost&&this.__templatizeOptions.parentModel)this._methodHost._addEventListenerToNode(e,t,e=>{e.model=this,r(e)});else{let i=this.__dataHost.__dataHost;i&&i._addEventListenerToNode(e,t,r)}}_showHideChildren(e){$n(e,this.children)}_setUnmanagedPropertyToNode(e,t,r){e.__hideTemplateChildren__&&e.nodeType==Node.TEXT_NODE&&"textContent"==t?e.__polymerTextContent__=r:super._setUnmanagedPropertyToNode(e,t,r)}get parentModel(){let e=this.__parentModel;if(!e){let t;e=this;do{e=e.__dataHost.__dataHost}while((t=e.__templatizeOptions)&&!t.parentModel);this.__parentModel=e}return e}dispatchEvent(e){return!0}}zn.prototype.__dataHost,zn.prototype.__templatizeOptions,zn.prototype._methodHost,zn.prototype.__templatizeOwner,zn.prototype.__hostProps;const jn=Rn(zn);function Bn(e){let t=e.__dataHost;return t&&t._methodHost||t}function Un(e,t,r){let i=r.mutableData?jn:zn;Jn.mixin&&(i=Jn.mixin(i));let o=class extends i{};return o.prototype.__templatizeOptions=r,o.prototype._bindTemplate(e),function(e,t,r,i){let o=r.hostProps||{};for(let t in i.instanceProps){delete o[t];let r=i.notifyInstanceProp;r&&e.prototype._addPropertyEffect(t,e.prototype.PROPERTY_EFFECT_TYPES.NOTIFY,{fn:Yn(t,r)})}if(i.forwardHostProp&&t.__dataHost)for(let t in o)r.hasHostProps||(r.hasHostProps=!0),e.prototype._addPropertyEffect(t,e.prototype.PROPERTY_EFFECT_TYPES.NOTIFY,{fn:function(e,t,r){e.__dataHost._setPendingPropertyOrPath("_host_"+t,r[t],!0,!0)}})}(o,e,t,r),o}function Vn(e,t,r,i){let o=r.forwardHostProp;if(o&&t.hasHostProps){const n="template"==e.localName;let a=t.templatizeTemplateClass;if(!a){if(n){let e=r.mutableData?Hn:Mn;class i extends e{}a=t.templatizeTemplateClass=i}else{const r=e.constructor;class i extends r{}a=t.templatizeTemplateClass=i}let s=t.hostProps;for(let e in s)a.prototype._addPropertyEffect("_host_"+e,a.prototype.PROPERTY_EFFECT_TYPES.PROPAGATE,{fn:qn(e,o)}),a.prototype._createNotifyingProperty("_host_"+e);dr&&i&&function(e,t,r){const i=r.constructor._properties,{propertyEffects:o}=e,{instanceProps:n}=t;for(let e in o)if(!(i[e]||n&&n[e])){const t=o[e];for(let r=0;r<t.length;r++){const{part:i}=t[r].info;if(!i.signature||!i.signature.static){console.warn(`Property '${e}' used in template but not declared in 'properties'; attribute will not be observed.`);break}}}}(t,r,i)}if(e.__dataProto&&Object.assign(e.__data,e.__dataProto),n)!function(e,t){In=e,Object.setPrototypeOf(e,t.prototype),new t,In=null}(e,a),e.__dataTemp={},e.__dataPending=null,e.__dataOld=null,e._enableProperties();else{Object.setPrototypeOf(e,a.prototype);const r=t.hostProps;for(let t in r)if(t="_host_"+t,t in e){const r=e[t];delete e[t],e.__data[t]=r}}}}function qn(e,t){return function(e,r,i){t.call(e.__templatizeOwner,r.substring("_host_".length),i[r])}}function Yn(e,t){return function(e,r,i){t.call(e.__templatizeOwner,e,r,i[r])}}function Jn(e,t,r){if(sr&&!Bn(e))throw new Error("strictTemplatePolicy: template owner not trusted");if(r=r||{},e.__templatizeOwner)throw new Error("A <template> can only be templatized once");e.__templatizeOwner=t;let i=(t?t.constructor:zn)._parseTemplate(e),o=i.templatizeInstanceClass;o||(o=Un(e,i,r),i.templatizeInstanceClass=o);const n=Bn(e);Vn(e,i,r,n);let a=class extends o{};return a.prototype._methodHost=n,a.prototype.__dataHost=e,a.prototype.__templatizeOwner=t,a.prototype.__hostProps=i.hostProps,a=a,a}let Gn=!1;function Wn(){if(cr&&!rr){if(!Gn){Gn=!0;const e=document.createElement("style");e.textContent="dom-bind,dom-if,dom-repeat{display:none;}",document.head.appendChild(e)}return!0}return!1}const Zn=Bo(Dn(Zi(HTMLElement)));customElements.define("dom-bind",class extends Zn{static get observedAttributes(){return["mutable-data"]}constructor(){if(super(),sr)throw new Error("strictTemplatePolicy: dom-bind not allowed");this.root=null,this.$=null,this.__children=null}attributeChangedCallback(e,t,r,i){this.mutableData=!0}connectedCallback(){Wn()||(this.style.display="none"),this.render()}disconnectedCallback(){this.__removeChildren()}__insertChildren(){Dr(Dr(this).parentNode).insertBefore(this.root,this)}__removeChildren(){if(this.__children)for(let e=0;e<this.__children.length;e++)this.root.appendChild(this.__children[e])}render(){let e;if(!this.__children){if(e=e||this.querySelector("template"),!e){let t=new MutationObserver(()=>{if(e=this.querySelector("template"),!e)throw new Error("dom-bind requires a <template> child");t.disconnect(),this.render()});return void t.observe(this,{childList:!0})}this.root=this._stampTemplate(e),this.$=this.root.$,this.__children=[];for(let e=this.root.firstChild;e;e=e.nextSibling)this.__children[this.__children.length]=e;this._enableProperties()}this.__insertChildren(),this.dispatchEvent(new CustomEvent("dom-change",{bubbles:!0,composed:!0}))}});class Xn{constructor(e){this.value=e.toString()}toString(){return this.value}}function Kn(e){if(e instanceof HTMLTemplateElement)return e.innerHTML;if(e instanceof Xn)return function(e){if(e instanceof Xn)return e.value;throw new Error("non-literal value passed to Polymer's htmlLiteral function: "+e)}(e);throw new Error("non-template value passed to Polymer's html function: "+e)}const Qn=function(e,...t){const r=document.createElement("template");return r.innerHTML=t.reduce((t,r,i)=>t+Kn(r)+e[i+1],e[0]),r},ea=eo(HTMLElement),ta=Dn(ea);class ra extends ta{static get is(){return"dom-repeat"}static get template(){return null}static get properties(){return{items:{type:Array},as:{type:String,value:"item"},indexAs:{type:String,value:"index"},itemsIndexAs:{type:String,value:"itemsIndex"},sort:{type:Function,observer:"__sortChanged"},filter:{type:Function,observer:"__filterChanged"},observe:{type:String,observer:"__observeChanged"},delay:Number,renderedItemCount:{type:Number,notify:!gr,readOnly:!0},initialCount:{type:Number},targetFramerate:{type:Number,value:20},_targetFrameTime:{type:Number,computed:"__computeFrameTime(targetFramerate)"},notifyDomChange:{type:Boolean},reuseChunkedInstances:{type:Boolean}}}static get observers(){return["__itemsChanged(items.*)"]}constructor(){super(),this.__instances=[],this.__renderDebouncer=null,this.__itemsIdxToInstIdx={},this.__chunkCount=null,this.__renderStartTime=null,this.__itemsArrayChanged=!1,this.__shouldMeasureChunk=!1,this.__shouldContinueChunking=!1,this.__chunkingId=0,this.__sortFn=null,this.__filterFn=null,this.__observePaths=null,this.__ctor=null,this.__isDetached=!0,this.template=null,this._templateInfo}disconnectedCallback(){super.disconnectedCallback(),this.__isDetached=!0;for(let e=0;e<this.__instances.length;e++)this.__detachInstance(e)}connectedCallback(){if(super.connectedCallback(),Wn()||(this.style.display="none"),this.__isDetached){this.__isDetached=!1;let e=Dr(Dr(this).parentNode);for(let t=0;t<this.__instances.length;t++)this.__attachInstance(t,e)}}__ensureTemplatized(){if(!this.__ctor){const e=this;let t=this.template=e._templateInfo?e:this.querySelector("template");if(!t){let e=new MutationObserver(()=>{if(!this.querySelector("template"))throw new Error("dom-repeat requires a <template> child");e.disconnect(),this.__render()});return e.observe(this,{childList:!0}),!1}let r={};r[this.as]=!0,r[this.indexAs]=!0,r[this.itemsIndexAs]=!0,this.__ctor=Jn(t,this,{mutableData:this.mutableData,parentModel:!0,instanceProps:r,forwardHostProp:function(e,t){let r=this.__instances;for(let i,o=0;o<r.length&&(i=r[o]);o++)i.forwardHostProp(e,t)},notifyInstanceProp:function(e,t,r){if((i=this.as)===(o=t)||Mr(i,o)||Hr(i,o)){let i=e[this.itemsIndexAs];t==this.as&&(this.items[i]=r);let o=Fr(this.as,`${JSCompiler_renameProperty("items",this)}.${i}`,t);this.notifyPath(o,r)}var i,o}})}return!0}__getMethodHost(){return this.__dataHost._methodHost||this.__dataHost}__functionFromPropertyValue(e){if("string"==typeof e){let t=e,r=this.__getMethodHost();return function(){return r[t].apply(r,arguments)}}return e}__sortChanged(e){this.__sortFn=this.__functionFromPropertyValue(e),this.items&&this.__debounceRender(this.__render)}__filterChanged(e){this.__filterFn=this.__functionFromPropertyValue(e),this.items&&this.__debounceRender(this.__render)}__computeFrameTime(e){return Math.ceil(1e3/e)}__observeChanged(){this.__observePaths=this.observe&&this.observe.replace(".*",".").split(" ")}__handleObservedPaths(e){if(this.__sortFn||this.__filterFn)if(e){if(this.__observePaths){let t=this.__observePaths;for(let r=0;r<t.length;r++)0===e.indexOf(t[r])&&this.__debounceRender(this.__render,this.delay)}}else this.__debounceRender(this.__render,this.delay)}__itemsChanged(e){this.items&&!Array.isArray(this.items)&&console.warn("dom-repeat expected array for `items`, found",this.items),this.__handleItemPath(e.path,e.value)||("items"===e.path&&(this.__itemsArrayChanged=!0),this.__debounceRender(this.__render))}__debounceRender(e,t=0){this.__renderDebouncer=to.debounce(this.__renderDebouncer,t>0?ei.after(t):ri,e.bind(this)),io(this.__renderDebouncer)}render(){this.__debounceRender(this.__render),ln()}__render(){if(!this.__ensureTemplatized())return;let e=this.items||[];const t=this.__sortAndFilterItems(e),r=this.__calculateLimit(t.length);this.__updateInstances(e,r,t),this.initialCount&&(this.__shouldMeasureChunk||this.__shouldContinueChunking)&&(cancelAnimationFrame(this.__chunkingId),this.__chunkingId=requestAnimationFrame(()=>this.__continueChunking())),this._setRenderedItemCount(this.__instances.length),gr&&!this.notifyDomChange||this.dispatchEvent(new CustomEvent("dom-change",{bubbles:!0,composed:!0}))}__sortAndFilterItems(e){let t=new Array(e.length);for(let r=0;r<e.length;r++)t[r]=r;return this.__filterFn&&(t=t.filter((t,r,i)=>this.__filterFn(e[t],r,i))),this.__sortFn&&t.sort((t,r)=>this.__sortFn(e[t],e[r])),t}__calculateLimit(e){let t=e;const r=this.__instances.length;if(this.initialCount){let i;!this.__chunkCount||this.__itemsArrayChanged&&!this.reuseChunkedInstances?(t=Math.min(e,this.initialCount),i=Math.max(t-r,0),this.__chunkCount=i||1):(i=Math.min(Math.max(e-r,0),this.__chunkCount),t=Math.min(r+i,e)),this.__shouldMeasureChunk=i===this.__chunkCount,this.__shouldContinueChunking=t<e,this.__renderStartTime=performance.now()}return this.__itemsArrayChanged=!1,t}__continueChunking(){if(this.__shouldMeasureChunk){const e=performance.now()-this.__renderStartTime,t=this._targetFrameTime/e;this.__chunkCount=Math.round(this.__chunkCount*t)||1}this.__shouldContinueChunking&&this.__debounceRender(this.__render)}__updateInstances(e,t,r){const i=this.__itemsIdxToInstIdx={};let o;for(o=0;o<t;o++){let t=this.__instances[o],n=r[o],a=e[n];i[n]=o,t?(t._setPendingProperty(this.as,a),t._setPendingProperty(this.indexAs,o),t._setPendingProperty(this.itemsIndexAs,n),t._flushProperties()):this.__insertInstance(a,o,n)}for(let e=this.__instances.length-1;e>=o;e--)this.__detachAndRemoveInstance(e)}__detachInstance(e){let t=this.__instances[e];const r=Dr(t.root);for(let e=0;e<t.children.length;e++){let i=t.children[e];r.appendChild(i)}return t}__attachInstance(e,t){let r=this.__instances[e];t.insertBefore(r.root,this)}__detachAndRemoveInstance(e){this.__detachInstance(e),this.__instances.splice(e,1)}__stampInstance(e,t,r){let i={};return i[this.as]=e,i[this.indexAs]=t,i[this.itemsIndexAs]=r,new this.__ctor(i)}__insertInstance(e,t,r){const i=this.__stampInstance(e,t,r);let o=this.__instances[t+1],n=o?o.children[0]:this;return Dr(Dr(this).parentNode).insertBefore(i.root,n),this.__instances[t]=i,i}_showHideChildren(e){for(let t=0;t<this.__instances.length;t++)this.__instances[t]._showHideChildren(e)}__handleItemPath(e,t){let r=e.slice(6),i=r.indexOf("."),o=i<0?r:r.substring(0,i);if(o==parseInt(o,10)){let e=i<0?"":r.substring(i+1);this.__handleObservedPaths(e);let n=this.__itemsIdxToInstIdx[o],a=this.__instances[n];if(a){let r=this.as+(e?"."+e:"");a._setPendingPropertyOrPath(r,t,!1,!0),a._flushProperties()}return!0}}itemForElement(e){let t=this.modelForElement(e);return t&&t[this.as]}indexForElement(e){let t=this.modelForElement(e);return t&&t[this.indexAs]}modelForElement(e){return function(e,t){let r;for(;t;)if(r=t.__dataHost?t:t.__templatizeInstance){if(r.__dataHost==e)return r;t=r.__dataHost}else t=Dr(t).parentNode;return null}(this.template,e)}}customElements.define(ra.is,ra);class ia extends ea{static get is(){return"dom-if"}static get template(){return null}static get properties(){return{if:{type:Boolean,observer:"__debounceRender"},restamp:{type:Boolean,observer:"__debounceRender"},notifyDomChange:{type:Boolean}}}constructor(){super(),this.__renderDebouncer=null,this._lastIf=!1,this.__hideTemplateChildren__=!1,this.__template,this._templateInfo}__debounceRender(){this.__renderDebouncer=to.debounce(this.__renderDebouncer,ri,()=>this.__render()),io(this.__renderDebouncer)}disconnectedCallback(){super.disconnectedCallback();const e=Dr(this).parentNode;e&&(e.nodeType!=Node.DOCUMENT_FRAGMENT_NODE||Dr(e).host)||this.__teardownInstance()}connectedCallback(){super.connectedCallback(),Wn()||(this.style.display="none"),this.if&&this.__debounceRender()}__ensureTemplate(){if(!this.__template){const e=this;let t=e._templateInfo?e:Dr(e).querySelector("template");if(!t){let e=new MutationObserver(()=>{if(!Dr(this).querySelector("template"))throw new Error("dom-if requires a <template> child");e.disconnect(),this.__render()});return e.observe(this,{childList:!0}),!1}this.__template=t}return!0}__ensureInstance(){let e=Dr(this).parentNode;if(this.__hasInstance()){let t=this.__getInstanceNodes();if(t&&t.length){if(Dr(this).previousSibling!==t[t.length-1])for(let r,i=0;i<t.length&&(r=t[i]);i++)Dr(e).insertBefore(r,this)}}else{if(!e)return!1;if(!this.__ensureTemplate())return!1;this.__createAndInsertInstance(e)}return!0}render(){ln()}__render(){if(this.if){if(!this.__ensureInstance())return}else this.restamp&&this.__teardownInstance();this._showHideChildren(),gr&&!this.notifyDomChange||this.if==this._lastIf||(this.dispatchEvent(new CustomEvent("dom-change",{bubbles:!0,composed:!0})),this._lastIf=this.if)}__hasInstance(){}__getInstanceNodes(){}__createAndInsertInstance(e){}__teardownInstance(){}_showHideChildren(){}}const oa=mr?class extends ia{constructor(){super(),this.__instance=null,this.__syncInfo=null}__hasInstance(){return Boolean(this.__instance)}__getInstanceNodes(){return this.__instance.templateInfo.childNodes}__createAndInsertInstance(e){const t=this.__dataHost||this;if(sr&&!this.__dataHost)throw new Error("strictTemplatePolicy: template owner not trusted");const r=t._bindTemplate(this.__template,!0);r.runEffects=(e,t,r)=>{let i=this.__syncInfo;if(this.if)i&&(this.__syncInfo=null,this._showHideChildren(),t=Object.assign(i.changedProps,t)),e(t,r);else if(this.__instance)if(i||(i=this.__syncInfo={runEffects:e,changedProps:{}}),r)for(const e in t){const t=Lr(e);i.changedProps[t]=this.__dataHost[t]}else Object.assign(i.changedProps,t)},this.__instance=t._stampTemplate(this.__template,r),Dr(e).insertBefore(this.__instance,this)}__syncHostProperties(){const e=this.__syncInfo;e&&(this.__syncInfo=null,e.runEffects(e.changedProps,!1))}__teardownInstance(){const e=this.__dataHost||this;this.__instance&&(e._removeBoundDom(this.__instance),this.__instance=null,this.__syncInfo=null)}_showHideChildren(){const e=this.__hideTemplateChildren__||!this.if;this.__instance&&Boolean(this.__instance.__hidden)!==e&&(this.__instance.__hidden=e,$n(e,this.__instance.templateInfo.childNodes)),e||this.__syncHostProperties()}}:class extends ia{constructor(){super(),this.__ctor=null,this.__instance=null,this.__invalidProps=null}__hasInstance(){return Boolean(this.__instance)}__getInstanceNodes(){return this.__instance.children}__createAndInsertInstance(e){this.__ctor||(this.__ctor=Jn(this.__template,this,{mutableData:!0,forwardHostProp:function(e,t){this.__instance&&(this.if?this.__instance.forwardHostProp(e,t):(this.__invalidProps=this.__invalidProps||Object.create(null),this.__invalidProps[Lr(e)]=!0))}})),this.__instance=new this.__ctor,Dr(e).insertBefore(this.__instance.root,this)}__teardownInstance(){if(this.__instance){let e=this.__instance.children;if(e&&e.length){let t=Dr(e[0]).parentNode;if(t){t=Dr(t);for(let r,i=0;i<e.length&&(r=e[i]);i++)t.removeChild(r)}}this.__invalidProps=null,this.__instance=null}}__syncHostProperties(){let e=this.__invalidProps;if(e){this.__invalidProps=null;for(let t in e)this.__instance._setPendingProperty(t,this.__dataHost[t]);this.__instance._flushProperties()}}_showHideChildren(){const e=this.__hideTemplateChildren__||!this.if;this.__instance&&Boolean(this.__instance.__hidden)!==e&&(this.__instance.__hidden=e,this.__instance._showHideChildren(e)),e||this.__syncHostProperties()}};customElements.define(oa.is,oa);let na=vr(e=>{let t=eo(e);return class extends t{static get properties(){return{items:{type:Array},multi:{type:Boolean,value:!1},selected:{type:Object,notify:!0},selectedItem:{type:Object,notify:!0},toggle:{type:Boolean,value:!1}}}static get observers(){return["__updateSelection(multi, items.*)"]}constructor(){super(),this.__lastItems=null,this.__lastMulti=null,this.__selectedMap=null}__updateSelection(e,t){let r=t.path;if(r==JSCompiler_renameProperty("items",this)){let r=t.base||[],i=this.__lastItems;if(e!==this.__lastMulti&&this.clearSelection(),i){let e=on(r,i);this.__applySplices(e)}this.__lastItems=r,this.__lastMulti=e}else if(t.path==JSCompiler_renameProperty("items",this)+".splices")this.__applySplices(t.value.indexSplices);else{let e=r.slice((JSCompiler_renameProperty("items",this)+".").length),t=parseInt(e,10);e.indexOf(".")<0&&e==t&&this.__deselectChangedIdx(t)}}__applySplices(e){let t=this.__selectedMap;for(let r=0;r<e.length;r++){let i=e[r];t.forEach((e,r)=>{e<i.index||(e>=i.index+i.removed.length?t.set(r,e+i.addedCount-i.removed.length):t.set(r,-1))});for(let e=0;e<i.addedCount;e++){let r=i.index+e;t.has(this.items[r])&&t.set(this.items[r],r)}}this.__updateLinks();let r=0;t.forEach((e,i)=>{e<0?(this.multi?this.splice(JSCompiler_renameProperty("selected",this),r,1):this.selected=this.selectedItem=null,t.delete(i)):r++})}__updateLinks(){if(this.__dataLinkedPaths={},this.multi){let e=0;this.__selectedMap.forEach(t=>{t>=0&&this.linkPaths(`${JSCompiler_renameProperty("items",this)}.${t}`,`${JSCompiler_renameProperty("selected",this)}.${e++}`)})}else this.__selectedMap.forEach(e=>{this.linkPaths(JSCompiler_renameProperty("selected",this),`${JSCompiler_renameProperty("items",this)}.${e}`),this.linkPaths(JSCompiler_renameProperty("selectedItem",this),`${JSCompiler_renameProperty("items",this)}.${e}`)})}clearSelection(){this.__dataLinkedPaths={},this.__selectedMap=new Map,this.selected=this.multi?[]:null,this.selectedItem=null}isSelected(e){return this.__selectedMap.has(e)}isIndexSelected(e){return this.isSelected(this.items[e])}__deselectChangedIdx(e){let t=this.__selectedIndexForItemIndex(e);if(t>=0){let e=0;this.__selectedMap.forEach((r,i)=>{t==e++&&this.deselect(i)})}}__selectedIndexForItemIndex(e){let t=this.__dataLinkedPaths[`${JSCompiler_renameProperty("items",this)}.${e}`];if(t)return parseInt(t.slice((JSCompiler_renameProperty("selected",this)+".").length),10)}deselect(e){let t=this.__selectedMap.get(e);if(t>=0){let r;this.__selectedMap.delete(e),this.multi&&(r=this.__selectedIndexForItemIndex(t)),this.__updateLinks(),this.multi?this.splice(JSCompiler_renameProperty("selected",this),r,1):this.selected=this.selectedItem=null}}deselectIndex(e){this.deselect(this.items[e])}select(e){this.selectIndex(this.items.indexOf(e))}selectIndex(e){let t=this.items[e];this.isSelected(t)?this.toggle&&this.deselectIndex(e):(this.multi||this.__selectedMap.clear(),this.__selectedMap.set(t,e),this.__updateLinks(),this.multi?this.push(JSCompiler_renameProperty("selected",this),t):this.selected=this.selectedItem=t)}}})(ea);class aa extends na{static get is(){return"array-selector"}static get template(){return null}}customElements.define(aa.is,aa);const sa=new Yt;window.ShadyCSS||(window.ShadyCSS={prepareTemplate(e,t,r){},prepareTemplateDom(e,t){},prepareTemplateStyles(e,t,r){},styleSubtree(e,t){sa.processStyles(),Pt(e,t)},styleElement(e){sa.processStyles()},styleDocument(e){sa.processStyles(),Pt(document.body,e)},getComputedStyleValue:(e,t)=>St(e,t),flushCustomStyles(){},nativeCss:it,nativeShadow:Ke,cssBuild:et,disableRuntime:rt}),window.ShadyCSS.CustomStyleInterface=sa;const la=window.ShadyCSS.CustomStyleInterface;class ca extends HTMLElement{constructor(){super(),this._style=null,la.addCustomStyle(this)}getStyle(){if(this._style)return this._style;const e=this.querySelector("style");if(!e)return null;this._style=e;const t=e.getAttribute("include");return t&&(e.removeAttribute("include"),e.textContent=function(e){let t=e.trim().split(/\s+/),r="";for(let e=0;e<t.length;e++)r+=Rr(t[e]);return r}(t)+e.textContent),this.ownerDocument!==window.document&&window.document.head.appendChild(this),this._style}}window.customElements.define("custom-style",ca);const da=xn(HTMLElement).prototype,pa=Qn`
<custom-style>
  <style is="custom-style">
    [hidden] {
      display: none !important;
    }
  </style>
</custom-style>
<custom-style>
  <style is="custom-style">
    html {

      --layout: {
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      };

      --layout-inline: {
        display: -ms-inline-flexbox;
        display: -webkit-inline-flex;
        display: inline-flex;
      };

      --layout-horizontal: {
        @apply --layout;

        -ms-flex-direction: row;
        -webkit-flex-direction: row;
        flex-direction: row;
      };

      --layout-horizontal-reverse: {
        @apply --layout;

        -ms-flex-direction: row-reverse;
        -webkit-flex-direction: row-reverse;
        flex-direction: row-reverse;
      };

      --layout-vertical: {
        @apply --layout;

        -ms-flex-direction: column;
        -webkit-flex-direction: column;
        flex-direction: column;
      };

      --layout-vertical-reverse: {
        @apply --layout;

        -ms-flex-direction: column-reverse;
        -webkit-flex-direction: column-reverse;
        flex-direction: column-reverse;
      };

      --layout-wrap: {
        -ms-flex-wrap: wrap;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
      };

      --layout-wrap-reverse: {
        -ms-flex-wrap: wrap-reverse;
        -webkit-flex-wrap: wrap-reverse;
        flex-wrap: wrap-reverse;
      };

      --layout-flex-auto: {
        -ms-flex: 1 1 auto;
        -webkit-flex: 1 1 auto;
        flex: 1 1 auto;
      };

      --layout-flex-none: {
        -ms-flex: none;
        -webkit-flex: none;
        flex: none;
      };

      --layout-flex: {
        -ms-flex: 1 1 0.000000001px;
        -webkit-flex: 1;
        flex: 1;
        -webkit-flex-basis: 0.000000001px;
        flex-basis: 0.000000001px;
      };

      --layout-flex-2: {
        -ms-flex: 2;
        -webkit-flex: 2;
        flex: 2;
      };

      --layout-flex-3: {
        -ms-flex: 3;
        -webkit-flex: 3;
        flex: 3;
      };

      --layout-flex-4: {
        -ms-flex: 4;
        -webkit-flex: 4;
        flex: 4;
      };

      --layout-flex-5: {
        -ms-flex: 5;
        -webkit-flex: 5;
        flex: 5;
      };

      --layout-flex-6: {
        -ms-flex: 6;
        -webkit-flex: 6;
        flex: 6;
      };

      --layout-flex-7: {
        -ms-flex: 7;
        -webkit-flex: 7;
        flex: 7;
      };

      --layout-flex-8: {
        -ms-flex: 8;
        -webkit-flex: 8;
        flex: 8;
      };

      --layout-flex-9: {
        -ms-flex: 9;
        -webkit-flex: 9;
        flex: 9;
      };

      --layout-flex-10: {
        -ms-flex: 10;
        -webkit-flex: 10;
        flex: 10;
      };

      --layout-flex-11: {
        -ms-flex: 11;
        -webkit-flex: 11;
        flex: 11;
      };

      --layout-flex-12: {
        -ms-flex: 12;
        -webkit-flex: 12;
        flex: 12;
      };

      /* alignment in cross axis */

      --layout-start: {
        -ms-flex-align: start;
        -webkit-align-items: flex-start;
        align-items: flex-start;
      };

      --layout-center: {
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      };

      --layout-end: {
        -ms-flex-align: end;
        -webkit-align-items: flex-end;
        align-items: flex-end;
      };

      --layout-baseline: {
        -ms-flex-align: baseline;
        -webkit-align-items: baseline;
        align-items: baseline;
      };

      /* alignment in main axis */

      --layout-start-justified: {
        -ms-flex-pack: start;
        -webkit-justify-content: flex-start;
        justify-content: flex-start;
      };

      --layout-center-justified: {
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
      };

      --layout-end-justified: {
        -ms-flex-pack: end;
        -webkit-justify-content: flex-end;
        justify-content: flex-end;
      };

      --layout-around-justified: {
        -ms-flex-pack: distribute;
        -webkit-justify-content: space-around;
        justify-content: space-around;
      };

      --layout-justified: {
        -ms-flex-pack: justify;
        -webkit-justify-content: space-between;
        justify-content: space-between;
      };

      --layout-center-center: {
        @apply --layout-center;
        @apply --layout-center-justified;
      };

      /* self alignment */

      --layout-self-start: {
        -ms-align-self: flex-start;
        -webkit-align-self: flex-start;
        align-self: flex-start;
      };

      --layout-self-center: {
        -ms-align-self: center;
        -webkit-align-self: center;
        align-self: center;
      };

      --layout-self-end: {
        -ms-align-self: flex-end;
        -webkit-align-self: flex-end;
        align-self: flex-end;
      };

      --layout-self-stretch: {
        -ms-align-self: stretch;
        -webkit-align-self: stretch;
        align-self: stretch;
      };

      --layout-self-baseline: {
        -ms-align-self: baseline;
        -webkit-align-self: baseline;
        align-self: baseline;
      };

      /* multi-line alignment in main axis */

      --layout-start-aligned: {
        -ms-flex-line-pack: start;  /* IE10 */
        -ms-align-content: flex-start;
        -webkit-align-content: flex-start;
        align-content: flex-start;
      };

      --layout-end-aligned: {
        -ms-flex-line-pack: end;  /* IE10 */
        -ms-align-content: flex-end;
        -webkit-align-content: flex-end;
        align-content: flex-end;
      };

      --layout-center-aligned: {
        -ms-flex-line-pack: center;  /* IE10 */
        -ms-align-content: center;
        -webkit-align-content: center;
        align-content: center;
      };

      --layout-between-aligned: {
        -ms-flex-line-pack: justify;  /* IE10 */
        -ms-align-content: space-between;
        -webkit-align-content: space-between;
        align-content: space-between;
      };

      --layout-around-aligned: {
        -ms-flex-line-pack: distribute;  /* IE10 */
        -ms-align-content: space-around;
        -webkit-align-content: space-around;
        align-content: space-around;
      };

      /*******************************
                Other Layout
      *******************************/

      --layout-block: {
        display: block;
      };

      --layout-invisible: {
        visibility: hidden !important;
      };

      --layout-relative: {
        position: relative;
      };

      --layout-fit: {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
      };

      --layout-scroll: {
        -webkit-overflow-scrolling: touch;
        overflow: auto;
      };

      --layout-fullbleed: {
        margin: 0;
        height: 100vh;
      };

      /* fixed position */

      --layout-fixed-top: {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
      };

      --layout-fixed-right: {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
      };

      --layout-fixed-bottom: {
        position: fixed;
        right: 0;
        bottom: 0;
        left: 0;
      };

      --layout-fixed-left: {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
      };

    }
  </style>
</custom-style>`;pa.setAttribute("style","display: none;"),document.head.appendChild(pa.content);var ha=document.createElement("style");ha.textContent="[hidden] { display: none !important; }",document.head.appendChild(ha);const ua=Qn`
<custom-style>
  <style is="custom-style">
    html {

      /* Material Design color palette for Google products */

      --google-red-100: #f4c7c3;
      --google-red-300: #e67c73;
      --google-red-500: #db4437;
      --google-red-700: #c53929;

      --google-blue-100: #c6dafc;
      --google-blue-300: #7baaf7;
      --google-blue-500: #4285f4;
      --google-blue-700: #3367d6;

      --google-green-100: #b7e1cd;
      --google-green-300: #57bb8a;
      --google-green-500: #0f9d58;
      --google-green-700: #0b8043;

      --google-yellow-100: #fce8b2;
      --google-yellow-300: #f7cb4d;
      --google-yellow-500: #f4b400;
      --google-yellow-700: #f09300;

      --google-grey-100: #f5f5f5;
      --google-grey-300: #e0e0e0;
      --google-grey-500: #9e9e9e;
      --google-grey-700: #616161;

      /* Material Design color palette from online spec document */

      --paper-red-50: #ffebee;
      --paper-red-100: #ffcdd2;
      --paper-red-200: #ef9a9a;
      --paper-red-300: #e57373;
      --paper-red-400: #ef5350;
      --paper-red-500: #f44336;
      --paper-red-600: #e53935;
      --paper-red-700: #d32f2f;
      --paper-red-800: #c62828;
      --paper-red-900: #b71c1c;
      --paper-red-a100: #ff8a80;
      --paper-red-a200: #ff5252;
      --paper-red-a400: #ff1744;
      --paper-red-a700: #d50000;

      --paper-pink-50: #fce4ec;
      --paper-pink-100: #f8bbd0;
      --paper-pink-200: #f48fb1;
      --paper-pink-300: #f06292;
      --paper-pink-400: #ec407a;
      --paper-pink-500: #e91e63;
      --paper-pink-600: #d81b60;
      --paper-pink-700: #c2185b;
      --paper-pink-800: #ad1457;
      --paper-pink-900: #880e4f;
      --paper-pink-a100: #ff80ab;
      --paper-pink-a200: #ff4081;
      --paper-pink-a400: #f50057;
      --paper-pink-a700: #c51162;

      --paper-purple-50: #f3e5f5;
      --paper-purple-100: #e1bee7;
      --paper-purple-200: #ce93d8;
      --paper-purple-300: #ba68c8;
      --paper-purple-400: #ab47bc;
      --paper-purple-500: #9c27b0;
      --paper-purple-600: #8e24aa;
      --paper-purple-700: #7b1fa2;
      --paper-purple-800: #6a1b9a;
      --paper-purple-900: #4a148c;
      --paper-purple-a100: #ea80fc;
      --paper-purple-a200: #e040fb;
      --paper-purple-a400: #d500f9;
      --paper-purple-a700: #aa00ff;

      --paper-deep-purple-50: #ede7f6;
      --paper-deep-purple-100: #d1c4e9;
      --paper-deep-purple-200: #b39ddb;
      --paper-deep-purple-300: #9575cd;
      --paper-deep-purple-400: #7e57c2;
      --paper-deep-purple-500: #673ab7;
      --paper-deep-purple-600: #5e35b1;
      --paper-deep-purple-700: #512da8;
      --paper-deep-purple-800: #4527a0;
      --paper-deep-purple-900: #311b92;
      --paper-deep-purple-a100: #b388ff;
      --paper-deep-purple-a200: #7c4dff;
      --paper-deep-purple-a400: #651fff;
      --paper-deep-purple-a700: #6200ea;

      --paper-indigo-50: #e8eaf6;
      --paper-indigo-100: #c5cae9;
      --paper-indigo-200: #9fa8da;
      --paper-indigo-300: #7986cb;
      --paper-indigo-400: #5c6bc0;
      --paper-indigo-500: #3f51b5;
      --paper-indigo-600: #3949ab;
      --paper-indigo-700: #303f9f;
      --paper-indigo-800: #283593;
      --paper-indigo-900: #1a237e;
      --paper-indigo-a100: #8c9eff;
      --paper-indigo-a200: #536dfe;
      --paper-indigo-a400: #3d5afe;
      --paper-indigo-a700: #304ffe;

      --paper-blue-50: #e3f2fd;
      --paper-blue-100: #bbdefb;
      --paper-blue-200: #90caf9;
      --paper-blue-300: #64b5f6;
      --paper-blue-400: #42a5f5;
      --paper-blue-500: #2196f3;
      --paper-blue-600: #1e88e5;
      --paper-blue-700: #1976d2;
      --paper-blue-800: #1565c0;
      --paper-blue-900: #0d47a1;
      --paper-blue-a100: #82b1ff;
      --paper-blue-a200: #448aff;
      --paper-blue-a400: #2979ff;
      --paper-blue-a700: #2962ff;

      --paper-light-blue-50: #e1f5fe;
      --paper-light-blue-100: #b3e5fc;
      --paper-light-blue-200: #81d4fa;
      --paper-light-blue-300: #4fc3f7;
      --paper-light-blue-400: #29b6f6;
      --paper-light-blue-500: #03a9f4;
      --paper-light-blue-600: #039be5;
      --paper-light-blue-700: #0288d1;
      --paper-light-blue-800: #0277bd;
      --paper-light-blue-900: #01579b;
      --paper-light-blue-a100: #80d8ff;
      --paper-light-blue-a200: #40c4ff;
      --paper-light-blue-a400: #00b0ff;
      --paper-light-blue-a700: #0091ea;

      --paper-cyan-50: #e0f7fa;
      --paper-cyan-100: #b2ebf2;
      --paper-cyan-200: #80deea;
      --paper-cyan-300: #4dd0e1;
      --paper-cyan-400: #26c6da;
      --paper-cyan-500: #00bcd4;
      --paper-cyan-600: #00acc1;
      --paper-cyan-700: #0097a7;
      --paper-cyan-800: #00838f;
      --paper-cyan-900: #006064;
      --paper-cyan-a100: #84ffff;
      --paper-cyan-a200: #18ffff;
      --paper-cyan-a400: #00e5ff;
      --paper-cyan-a700: #00b8d4;

      --paper-teal-50: #e0f2f1;
      --paper-teal-100: #b2dfdb;
      --paper-teal-200: #80cbc4;
      --paper-teal-300: #4db6ac;
      --paper-teal-400: #26a69a;
      --paper-teal-500: #009688;
      --paper-teal-600: #00897b;
      --paper-teal-700: #00796b;
      --paper-teal-800: #00695c;
      --paper-teal-900: #004d40;
      --paper-teal-a100: #a7ffeb;
      --paper-teal-a200: #64ffda;
      --paper-teal-a400: #1de9b6;
      --paper-teal-a700: #00bfa5;

      --paper-green-50: #e8f5e9;
      --paper-green-100: #c8e6c9;
      --paper-green-200: #a5d6a7;
      --paper-green-300: #81c784;
      --paper-green-400: #66bb6a;
      --paper-green-500: #4caf50;
      --paper-green-600: #43a047;
      --paper-green-700: #388e3c;
      --paper-green-800: #2e7d32;
      --paper-green-900: #1b5e20;
      --paper-green-a100: #b9f6ca;
      --paper-green-a200: #69f0ae;
      --paper-green-a400: #00e676;
      --paper-green-a700: #00c853;

      --paper-light-green-50: #f1f8e9;
      --paper-light-green-100: #dcedc8;
      --paper-light-green-200: #c5e1a5;
      --paper-light-green-300: #aed581;
      --paper-light-green-400: #9ccc65;
      --paper-light-green-500: #8bc34a;
      --paper-light-green-600: #7cb342;
      --paper-light-green-700: #689f38;
      --paper-light-green-800: #558b2f;
      --paper-light-green-900: #33691e;
      --paper-light-green-a100: #ccff90;
      --paper-light-green-a200: #b2ff59;
      --paper-light-green-a400: #76ff03;
      --paper-light-green-a700: #64dd17;

      --paper-lime-50: #f9fbe7;
      --paper-lime-100: #f0f4c3;
      --paper-lime-200: #e6ee9c;
      --paper-lime-300: #dce775;
      --paper-lime-400: #d4e157;
      --paper-lime-500: #cddc39;
      --paper-lime-600: #c0ca33;
      --paper-lime-700: #afb42b;
      --paper-lime-800: #9e9d24;
      --paper-lime-900: #827717;
      --paper-lime-a100: #f4ff81;
      --paper-lime-a200: #eeff41;
      --paper-lime-a400: #c6ff00;
      --paper-lime-a700: #aeea00;

      --paper-yellow-50: #fffde7;
      --paper-yellow-100: #fff9c4;
      --paper-yellow-200: #fff59d;
      --paper-yellow-300: #fff176;
      --paper-yellow-400: #ffee58;
      --paper-yellow-500: #ffeb3b;
      --paper-yellow-600: #fdd835;
      --paper-yellow-700: #fbc02d;
      --paper-yellow-800: #f9a825;
      --paper-yellow-900: #f57f17;
      --paper-yellow-a100: #ffff8d;
      --paper-yellow-a200: #ffff00;
      --paper-yellow-a400: #ffea00;
      --paper-yellow-a700: #ffd600;

      --paper-amber-50: #fff8e1;
      --paper-amber-100: #ffecb3;
      --paper-amber-200: #ffe082;
      --paper-amber-300: #ffd54f;
      --paper-amber-400: #ffca28;
      --paper-amber-500: #ffc107;
      --paper-amber-600: #ffb300;
      --paper-amber-700: #ffa000;
      --paper-amber-800: #ff8f00;
      --paper-amber-900: #ff6f00;
      --paper-amber-a100: #ffe57f;
      --paper-amber-a200: #ffd740;
      --paper-amber-a400: #ffc400;
      --paper-amber-a700: #ffab00;

      --paper-orange-50: #fff3e0;
      --paper-orange-100: #ffe0b2;
      --paper-orange-200: #ffcc80;
      --paper-orange-300: #ffb74d;
      --paper-orange-400: #ffa726;
      --paper-orange-500: #ff9800;
      --paper-orange-600: #fb8c00;
      --paper-orange-700: #f57c00;
      --paper-orange-800: #ef6c00;
      --paper-orange-900: #e65100;
      --paper-orange-a100: #ffd180;
      --paper-orange-a200: #ffab40;
      --paper-orange-a400: #ff9100;
      --paper-orange-a700: #ff6500;

      --paper-deep-orange-50: #fbe9e7;
      --paper-deep-orange-100: #ffccbc;
      --paper-deep-orange-200: #ffab91;
      --paper-deep-orange-300: #ff8a65;
      --paper-deep-orange-400: #ff7043;
      --paper-deep-orange-500: #ff5722;
      --paper-deep-orange-600: #f4511e;
      --paper-deep-orange-700: #e64a19;
      --paper-deep-orange-800: #d84315;
      --paper-deep-orange-900: #bf360c;
      --paper-deep-orange-a100: #ff9e80;
      --paper-deep-orange-a200: #ff6e40;
      --paper-deep-orange-a400: #ff3d00;
      --paper-deep-orange-a700: #dd2c00;

      --paper-brown-50: #efebe9;
      --paper-brown-100: #d7ccc8;
      --paper-brown-200: #bcaaa4;
      --paper-brown-300: #a1887f;
      --paper-brown-400: #8d6e63;
      --paper-brown-500: #795548;
      --paper-brown-600: #6d4c41;
      --paper-brown-700: #5d4037;
      --paper-brown-800: #4e342e;
      --paper-brown-900: #3e2723;

      --paper-grey-50: #fafafa;
      --paper-grey-100: #f5f5f5;
      --paper-grey-200: #eeeeee;
      --paper-grey-300: #e0e0e0;
      --paper-grey-400: #bdbdbd;
      --paper-grey-500: #9e9e9e;
      --paper-grey-600: #757575;
      --paper-grey-700: #616161;
      --paper-grey-800: #424242;
      --paper-grey-900: #212121;

      --paper-blue-grey-50: #eceff1;
      --paper-blue-grey-100: #cfd8dc;
      --paper-blue-grey-200: #b0bec5;
      --paper-blue-grey-300: #90a4ae;
      --paper-blue-grey-400: #78909c;
      --paper-blue-grey-500: #607d8b;
      --paper-blue-grey-600: #546e7a;
      --paper-blue-grey-700: #455a64;
      --paper-blue-grey-800: #37474f;
      --paper-blue-grey-900: #263238;

      /* opacity for dark text on a light background */
      --dark-divider-opacity: 0.12;
      --dark-disabled-opacity: 0.38; /* or hint text or icon */
      --dark-secondary-opacity: 0.54;
      --dark-primary-opacity: 0.87;

      /* opacity for light text on a dark background */
      --light-divider-opacity: 0.12;
      --light-disabled-opacity: 0.3; /* or hint text or icon */
      --light-secondary-opacity: 0.7;
      --light-primary-opacity: 1.0;

    }

  </style>
</custom-style>
`;ua.setAttribute("style","display: none;"),document.head.appendChild(ua.content);const fa=Qn`
<custom-style>
  <style is="custom-style">
    html {
      /*
       * You can use these generic variables in your elements for easy theming.
       * For example, if all your elements use \`--primary-text-color\` as its main
       * color, then switching from a light to a dark theme is just a matter of
       * changing the value of \`--primary-text-color\` in your application.
       */
      --primary-text-color: var(--light-theme-text-color);
      --primary-background-color: var(--light-theme-background-color);
      --secondary-text-color: var(--light-theme-secondary-color);
      --disabled-text-color: var(--light-theme-disabled-color);
      --divider-color: var(--light-theme-divider-color);
      --error-color: var(--paper-deep-orange-a700);

      /*
       * Primary and accent colors. Also see color.js for more colors.
       */
      --primary-color: var(--paper-indigo-500);
      --light-primary-color: var(--paper-indigo-100);
      --dark-primary-color: var(--paper-indigo-700);

      --accent-color: var(--paper-pink-a200);
      --light-accent-color: var(--paper-pink-a100);
      --dark-accent-color: var(--paper-pink-a400);


      /*
       * Material Design Light background theme
       */
      --light-theme-background-color: #ffffff;
      --light-theme-base-color: #000000;
      --light-theme-text-color: var(--paper-grey-900);
      --light-theme-secondary-color: #737373;  /* for secondary text and icons */
      --light-theme-disabled-color: #9b9b9b;  /* disabled/hint text */
      --light-theme-divider-color: #dbdbdb;

      /*
       * Material Design Dark background theme
       */
      --dark-theme-background-color: var(--paper-grey-900);
      --dark-theme-base-color: #ffffff;
      --dark-theme-text-color: #ffffff;
      --dark-theme-secondary-color: #bcbcbc;  /* for secondary text and icons */
      --dark-theme-disabled-color: #646464;  /* disabled/hint text */
      --dark-theme-divider-color: #3c3c3c;

      /*
       * Deprecated values because of their confusing names.
       */
      --text-primary-color: var(--dark-theme-text-color);
      --default-primary-color: var(--primary-color);
    }
  </style>
</custom-style>`;fa.setAttribute("style","display: none;"),document.head.appendChild(fa.content);const ma=Qn`
<custom-style>
  <style is="custom-style">
    html {

      --shadow-transition: {
        transition: box-shadow 0.28s cubic-bezier(0.4, 0, 0.2, 1);
      };

      --shadow-none: {
        box-shadow: none;
      };

      /* from http://codepen.io/shyndman/pen/c5394ddf2e8b2a5c9185904b57421cdb */

      --shadow-elevation-2dp: {
        box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14),
                    0 1px 5px 0 rgba(0, 0, 0, 0.12),
                    0 3px 1px -2px rgba(0, 0, 0, 0.2);
      };

      --shadow-elevation-3dp: {
        box-shadow: 0 3px 4px 0 rgba(0, 0, 0, 0.14),
                    0 1px 8px 0 rgba(0, 0, 0, 0.12),
                    0 3px 3px -2px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-4dp: {
        box-shadow: 0 4px 5px 0 rgba(0, 0, 0, 0.14),
                    0 1px 10px 0 rgba(0, 0, 0, 0.12),
                    0 2px 4px -1px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-6dp: {
        box-shadow: 0 6px 10px 0 rgba(0, 0, 0, 0.14),
                    0 1px 18px 0 rgba(0, 0, 0, 0.12),
                    0 3px 5px -1px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-8dp: {
        box-shadow: 0 8px 10px 1px rgba(0, 0, 0, 0.14),
                    0 3px 14px 2px rgba(0, 0, 0, 0.12),
                    0 5px 5px -3px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-12dp: {
        box-shadow: 0 12px 16px 1px rgba(0, 0, 0, 0.14),
                    0 4px 22px 3px rgba(0, 0, 0, 0.12),
                    0 6px 7px -4px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-16dp: {
        box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14),
                    0  6px 30px 5px rgba(0, 0, 0, 0.12),
                    0  8px 10px -5px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-24dp: {
        box-shadow: 0 24px 38px 3px rgba(0, 0, 0, 0.14),
                    0 9px 46px 8px rgba(0, 0, 0, 0.12),
                    0 11px 15px -7px rgba(0, 0, 0, 0.4);
      };
    }
  </style>
</custom-style>`;if(ma.setAttribute("style","display: none;"),document.head.appendChild(ma.content),!window.polymerSkipLoadingFontRoboto){const e=document.createElement("link");e.rel="stylesheet",e.type="text/css",e.crossOrigin="anonymous",e.href="https://fonts.googleapis.com/css?family=Roboto+Mono:400,700|Roboto:400,300,300italic,400italic,500,500italic,700,700italic",document.head.appendChild(e)}const ga=Qn`<custom-style>
  <style is="custom-style">
    html {

      /* Shared Styles */
      --paper-font-common-base: {
        font-family: 'Roboto', 'Noto', sans-serif;
        -webkit-font-smoothing: antialiased;
      };

      --paper-font-common-code: {
        font-family: 'Roboto Mono', 'Consolas', 'Menlo', monospace;
        -webkit-font-smoothing: antialiased;
      };

      --paper-font-common-expensive-kerning: {
        text-rendering: optimizeLegibility;
      };

      --paper-font-common-nowrap: {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      };

      /* Material Font Styles */

      --paper-font-display4: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 112px;
        font-weight: 300;
        letter-spacing: -.044em;
        line-height: 120px;
      };

      --paper-font-display3: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 56px;
        font-weight: 400;
        letter-spacing: -.026em;
        line-height: 60px;
      };

      --paper-font-display2: {
        @apply --paper-font-common-base;

        font-size: 45px;
        font-weight: 400;
        letter-spacing: -.018em;
        line-height: 48px;
      };

      --paper-font-display1: {
        @apply --paper-font-common-base;

        font-size: 34px;
        font-weight: 400;
        letter-spacing: -.01em;
        line-height: 40px;
      };

      --paper-font-headline: {
        @apply --paper-font-common-base;

        font-size: 24px;
        font-weight: 400;
        letter-spacing: -.012em;
        line-height: 32px;
      };

      --paper-font-title: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 20px;
        font-weight: 500;
        line-height: 28px;
      };

      --paper-font-subhead: {
        @apply --paper-font-common-base;

        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
      };

      --paper-font-body2: {
        @apply --paper-font-common-base;

        font-size: 14px;
        font-weight: 500;
        line-height: 24px;
      };

      --paper-font-body1: {
        @apply --paper-font-common-base;

        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
      };

      --paper-font-caption: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 12px;
        font-weight: 400;
        letter-spacing: 0.011em;
        line-height: 20px;
      };

      --paper-font-menu: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 13px;
        font-weight: 500;
        line-height: 24px;
      };

      --paper-font-button: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 14px;
        font-weight: 500;
        letter-spacing: 0.018em;
        line-height: 24px;
        text-transform: uppercase;
      };

      --paper-font-code2: {
        @apply --paper-font-common-code;

        font-size: 14px;
        font-weight: 700;
        line-height: 20px;
      };

      --paper-font-code1: {
        @apply --paper-font-common-code;

        font-size: 14px;
        font-weight: 500;
        line-height: 20px;
      };

    }

  </style>
</custom-style>`;ga.setAttribute("style","display: none;"),document.head.appendChild(ga.content);const ya=document.createElement("template");ya.setAttribute("style","display: none;"),ya.innerHTML=`<custom-style>\n  <style>\n    /*\n      Home Assistant default styles.\n\n      In Polymer 2.0, default styles should to be set on the html selector.\n      (Setting all default styles only on body breaks shadyCSS polyfill.)\n      See: https://github.com/home-assistant/home-assistant-polymer/pull/901\n    */\n    html {\n      font-size: 14px;\n      height: 100vh;\n\n      /* text */\n      --primary-text-color: #212121;\n      --secondary-text-color: #727272;\n      --text-primary-color: #ffffff;\n      --text-light-primary-color: #212121;\n      --disabled-text-color: #bdbdbd;\n\n      /* main interface colors */\n      --primary-color: #03a9f4;\n      --dark-primary-color: #0288d1;\n      --light-primary-color: #b3e5fC;\n      --accent-color: #ff9800;\n      --divider-color: rgba(0, 0, 0, .12);\n\n      --scrollbar-thumb-color: rgb(194, 194, 194);\n\n      --error-color: #db4437;\n      --warning-color: #FF9800;\n      --success-color: #0f9d58;\n      --info-color: #4285f4;\n\n      /* background and sidebar */\n      --card-background-color: #ffffff;\n      --primary-background-color: #fafafa;\n      --secondary-background-color: #e5e5e5; /* behind the cards on state */\n\n      /* for header */\n      --header-height: 56px;\n\n      /* for label-badge */\n      --label-badge-red: #DF4C1E;\n      --label-badge-blue: #039be5;\n      --label-badge-green: #0DA035;\n      --label-badge-yellow: #f4b400;\n\n      /* states and badges */\n      --state-icon-color: #44739e;\n      /* an active state is anything that would require attention */ \n      --state-icon-active-color: #FDD835;\n      /* an error state is anything that would be considered an error */\n      /* --state-icon-error-color: #db4437; derived from error-color */\n\n      --state-on-color: #66a61e;\n      --state-off-color: #ff0029;\n      --state-home-color: #66a61e;\n      --state-not_home-color: #ff0029;\n      /* --state-unavailable-color: #a0a0a0; derived from disabled-text-color */\n      --state-unknown-color: #606060;\n      --state-idle-color: #377eb8;\n\n      /* climate state colors */\n      --state-climate-auto-color: #008000;\n      --state-climate-eco-color: #00ff7f;\n      --state-climate-cool-color: #2b9af9;\n      --state-climate-heat-color: #ff8100;\n      --state-climate-manual-color: #44739e;\n      --state-climate-off-color: #8a8a8a;\n      --state-climate-fan_only-color: #8a8a8a;\n      --state-climate-dry-color: #efbd07;\n      --state-climate-idle-color: #8a8a8a;\n\n      /* energy */\n      --energy-grid-consumption-color: #126a9a;\n      --energy-grid-return-color: #673ab7;\n      --energy-solar-color: #ff9800;\n      --energy-non-fossil-color: #0f9d58;\n\n      --rgb-energy-solar-color: 255, 152, 0;\n\n      /*\n        Paper-styles color.html dependency is stripped on build.\n        When a default paper-style color is used, it needs to be copied\n        from paper-styles/color.html to here.\n      */\n\n      --paper-grey-50: #fafafa; /* default for: --mwc-switch-unchecked-button-color */\n      --paper-grey-200: #eeeeee;  /* for ha-date-picker-style */\n      --paper-grey-500: #9e9e9e;  /* --label-badge-grey */\n\n      /* for paper-slider */\n      --paper-green-400: #66bb6a;\n      --paper-blue-400: #42a5f5;\n      --paper-orange-400: #ffa726;\n\n      /* opacity for dark text on a light background */\n      --dark-divider-opacity: 0.12;\n      --dark-disabled-opacity: 0.38; /* or hint text or icon */\n      --dark-secondary-opacity: 0.54;\n      --dark-primary-opacity: 0.87;\n\n      /* opacity for light text on a dark background */\n      --light-divider-opacity: 0.12;\n      --light-disabled-opacity: 0.3; /* or hint text or icon */\n      --light-secondary-opacity: 0.7;\n      --light-primary-opacity: 1.0;\n\n      /* set our slider style */\n      --ha-slider-pin-font-size: 15px;\n\n      /* rgb */\n      --rgb-primary-color: 3, 169, 244;\n      --rgb-accent-color: 255, 152, 0;\n      --rgb-primary-text-color: 33, 33, 33;\n      --rgb-secondary-text-color: 114, 114, 114;\n      --rgb-text-primary-color: 255, 255, 255;\n      --rgb-card-background-color: 255, 255, 255;\n\n      /* Vaadin typography */\n      --material-h6-font-size: 1.25rem;\n      --material-small-font-size: 0.875rem;\n      --material-caption-font-size: 0.75rem;\n      --material-button-font-size: 0.875rem;\n\n      ${Object.entries(Pe).map(([e,t])=>`--${e}: ${t};`).join("")}\n    }\n\n    /*\n      prevent clipping of positioned elements in a small scrollable\n      force smooth scrolling if can scroll\n      use non-shady selectors so this only targets iOS 9\n      conditional mixin set in ha-style-dialog does not work with shadyCSS\n    */\n    paper-dialog-scrollable:not(.can-scroll) > .scrollable {\n      -webkit-overflow-scrolling: auto !important;\n    }\n\n    paper-dialog-scrollable.can-scroll > .scrollable {\n      -webkit-overflow-scrolling: touch !important;\n    }\n\n    /* for paper-dialog */\n    iron-overlay-backdrop {\n      backdrop-filter: var(--dialog-backdrop-filter, none);\n    }\n  </style>\n</custom-style>`,document.head.appendChild(ya.content);let _a=a(null,(function(e,i){class o extends i{constructor(...t){super(...t),e(this)}}return{F:o,d:[{kind:"field",decorators:[_e({attribute:!1})],key:"configuration",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"racelandshop",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"critical",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"lovelace",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"repositories",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"route",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"status",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"removed",value:void 0},{kind:"field",decorators:[_e({type:Boolean})],key:"active",value:()=>!1},{kind:"field",decorators:[_e({type:Boolean})],key:"secondary",value:()=>!1},{kind:"field",decorators:[_e({type:Boolean})],key:"loading",value:()=>!0},{kind:"field",decorators:[_e({type:Boolean})],key:"narrow",value:void 0},{kind:"field",decorators:[_e({type:Boolean})],key:"sidebarDocked",value:void 0},{kind:"method",key:"shouldUpdate",value:function(e){return e.forEach((e,t)=>{"hass"===t&&(this.sidebarDocked='"docked"'===window.localStorage.getItem("dockedSidebar"))}),e.has("sidebarDocked")||e.has("narrow")||e.has("active")||e.has("params")||e.has("_error")||e.has("_progress")||e.has("_releaseNotes")||e.has("_updating")}},{kind:"method",key:"connectedCallback",value:function(){r(t(o.prototype),"connectedCallback",this).call(this),this.sidebarDocked='"docked"'===window.localStorage.getItem("dockedSidebar")}}]}}),me);const ba={"add-repository":()=>import("./c.3d954156.js"),"custom-repositories":()=>import("./c.14c699d0.js"),generic:()=>import("./c.503303b0.js"),install:()=>import("./c.4fb27813.js"),navigate:()=>import("./c.e533c476.js"),removed:()=>import("./c.79553866.js"),update:()=>import("./c.42f996c8.js"),"repository-info":()=>import("./c.09984bc8.js"),progress:()=>import("./c.81c7aaa8.js")};a([ge("racelandshop-event-dialog")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_e({attribute:!1})],key:"params",value:void 0},{kind:"method",key:"render",value:function(){if(!this.active)return G``;const e=this.params.type||"generic";ba[e]();const t=document.createElement(`racelandshop-${e}-dialog`);if(t.active=!0,t.hass=this.hass,t.racelandshop=this.racelandshop,t.narrow=this.narrow,t.configuration=this.configuration,t.lovelace=this.lovelace,t.secondary=this.secondary,t.repositories=this.repositories,t.route=this.route,t.status=this.status,this.params)for(const[e,r]of Object.entries(this.params))t[e]=r;return G`${t}`}}]}}),_a);const va=async e=>await e.connection.sendMessagePromise({type:"racelandshop/config"}),wa=async e=>await e.connection.sendMessagePromise({type:"racelandshop/repositories"}),xa=async e=>await e.connection.sendMessagePromise({type:"racelandshop/get_critical"}),ka=async e=>await e.connection.sendMessagePromise({type:"racelandshop/status"}),Ca=async e=>await e.connection.sendMessagePromise({type:"racelandshop/removed"}),Pa=async(e,t)=>{await e.connection.sendMessagePromise({type:"racelandshop/repository",action:"install",repository:t})},Sa=async(e,t)=>await e.connection.sendMessagePromise({type:"racelandshop/repository",action:"uninstall",repository:t}),Aa=async(e,t)=>await e.connection.sendMessagePromise({type:"racelandshop/repository",action:"release_notes",repository:t}),Ea=async(e,t)=>{await e.connection.sendMessagePromise({type:"racelandshop/repository",action:"toggle_beta",repository:t})},Oa=async(e,t,r)=>{await e.connection.sendMessagePromise({type:"racelandshop/repository/data",action:"install",repository:t,data:r})},Ta=async(e,t,r)=>{await e.connection.sendMessagePromise({type:"racelandshop/repository/data",action:"add",repository:t,data:r})},Na=async(e,t)=>{await e.connection.sendMessagePromise({type:"racelandshop/repository",action:"not_new",repository:t})},Ra=async(e,t)=>{await e.connection.sendMessagePromise({type:"racelandshop/repository",action:"update",repository:t})},Da=async(e,t)=>{await e.connection.sendMessagePromise({type:"racelandshop/repository",action:"delete",repository:t})},Ia=async(e,t)=>{await e.connection.sendMessagePromise({type:"racelandshop/settings",action:"clear_new",categories:t})},La=async e=>{try{return await e.connection.sendMessagePromise({type:"lovelace/resources"})}catch(e){return null}},Ma=e=>e.connection.sendMessagePromise({type:"lovelace/resources"}),Ha=(e,t)=>e.callWS({type:"lovelace/resources/create",...t}),Fa=(e,t)=>e.callWS({type:"lovelace/resources/update",...t}),$a=(e,t)=>e.callWS({type:"lovelace/resources/delete",resource_id:t});var za=Number.isNaN||function(e){return"number"==typeof e&&e!=e};function ja(e,t){if(e.length!==t.length)return!1;for(var r=0;r<e.length;r++)if(i=e[r],o=t[r],!(i===o||za(i)&&za(o)))return!1;var i,o;return!0}function Ba(e,t){var r;void 0===t&&(t=ja);var i,o=[],n=!1;return function(){for(var a=[],s=0;s<arguments.length;s++)a[s]=arguments[s];return n&&r===this&&t(a,o)||(i=e.apply(this,a),n=!0,r=this,o=a),i}}var Ua="M12,4A4,4 0 0,1 16,8A4,4 0 0,1 12,12A4,4 0 0,1 8,8A4,4 0 0,1 12,4M12,14C16.42,14 20,15.79 20,18V20H4V18C4,15.79 7.58,14 12,14Z",Va="M13,13H11V7H13M13,17H11V15H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z",qa="M9,4H15V12H19.84L12,19.84L4.16,12H9V4Z",Ya="M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z",Ja="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z",Ga="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z",Wa="M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z",Za="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z",Xa="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",Ka="M21,16.5C21,16.88 20.79,17.21 20.47,17.38L12.57,21.82C12.41,21.94 12.21,22 12,22C11.79,22 11.59,21.94 11.43,21.82L3.53,17.38C3.21,17.21 3,16.88 3,16.5V7.5C3,7.12 3.21,6.79 3.53,6.62L11.43,2.18C11.59,2.06 11.79,2 12,2C12.21,2 12.41,2.06 12.57,2.18L20.47,6.62C20.79,6.79 21,7.12 21,7.5V16.5M12,4.15L6.04,7.5L12,10.85L17.96,7.5L12,4.15Z",Qa="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",es="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",ts="M10 3H14V14H10V3M10 21V17H14V21H10Z",rs="M12,2A10,10 0 0,0 2,12C2,16.42 4.87,20.17 8.84,21.5C9.34,21.58 9.5,21.27 9.5,21C9.5,20.77 9.5,20.14 9.5,19.31C6.73,19.91 6.14,17.97 6.14,17.97C5.68,16.81 5.03,16.5 5.03,16.5C4.12,15.88 5.1,15.9 5.1,15.9C6.1,15.97 6.63,16.93 6.63,16.93C7.5,18.45 8.97,18 9.54,17.76C9.63,17.11 9.89,16.67 10.17,16.42C7.95,16.17 5.62,15.31 5.62,11.5C5.62,10.39 6,9.5 6.65,8.79C6.55,8.54 6.2,7.5 6.75,6.15C6.75,6.15 7.59,5.88 9.5,7.17C10.29,6.95 11.15,6.84 12,6.84C12.85,6.84 13.71,6.95 14.5,7.17C16.41,5.88 17.25,6.15 17.25,6.15C17.8,7.5 17.45,8.54 17.35,8.79C18,9.5 18.38,10.39 18.38,11.5C18.38,15.32 16.04,16.16 13.81,16.41C14.17,16.72 14.5,17.33 14.5,18.26C14.5,19.6 14.5,20.68 14.5,21C14.5,21.27 14.66,21.59 15.17,21.5C19.14,20.16 22,16.42 22,12A10,10 0 0,0 12,2Z",is="M21.8,13H20V21H13V17.67L15.79,14.88L16.5,15C17.66,15 18.6,14.06 18.6,12.9C18.6,11.74 17.66,10.8 16.5,10.8A2.1,2.1 0 0,0 14.4,12.9L14.5,13.61L13,15.13V9.65C13.66,9.29 14.1,8.6 14.1,7.8A2.1,2.1 0 0,0 12,5.7A2.1,2.1 0 0,0 9.9,7.8C9.9,8.6 10.34,9.29 11,9.65V15.13L9.5,13.61L9.6,12.9A2.1,2.1 0 0,0 7.5,10.8A2.1,2.1 0 0,0 5.4,12.9A2.1,2.1 0 0,0 7.5,15L8.21,14.88L11,17.67V21H4V13H2.25C1.83,13 1.42,13 1.42,12.79C1.43,12.57 1.85,12.15 2.28,11.72L11,3C11.33,2.67 11.67,2.33 12,2.33C12.33,2.33 12.67,2.67 13,3L17,7V6H19V9L21.78,11.78C22.18,12.18 22.59,12.59 22.6,12.8C22.6,13 22.2,13 21.8,13M7.5,12A0.9,0.9 0 0,1 8.4,12.9A0.9,0.9 0 0,1 7.5,13.8A0.9,0.9 0 0,1 6.6,12.9A0.9,0.9 0 0,1 7.5,12M16.5,12C17,12 17.4,12.4 17.4,12.9C17.4,13.4 17,13.8 16.5,13.8A0.9,0.9 0 0,1 15.6,12.9A0.9,0.9 0 0,1 16.5,12M12,6.9C12.5,6.9 12.9,7.3 12.9,7.8C12.9,8.3 12.5,8.7 12,8.7C11.5,8.7 11.1,8.3 11.1,7.8C11.1,7.3 11.5,6.9 12,6.9Z",os="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z",ns="M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z",as="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",ss="M12,17.27L18.18,21L16.54,13.97L22,9.24L14.81,8.62L12,2L9.19,8.62L2,9.24L7.45,13.97L5.82,21L12,17.27Z";class ls{constructor(t){e(this,"prefix",void 0),this.prefix=t?`[RACELANDSHOP.${t}]`:"[RACELANDSHOP]"}info(e){this.log(e)}log(e){console.log(this.prefix,e)}debug(e){console.debug(this.prefix,e)}warn(e){console.warn(this.prefix,e)}error(e){console.error(this.prefix,e)}}const cs={en:{common:{about:"About",add:"add",appdaemon_apps:"AppDaemon Apps",appdaemon_plural:"AppDaemon Apps",appdaemon:"AppDaemon",background_task:"Background task running, this page will reload when it's done.",cancel:"Cancel",check_log_file:"Check your log file for more details.",continue:"Continue",disabled:"Disabled",documentation:"Documentation",element:"element",racelandshop_is_disabled:"RACELANDSHOP is disabled",ignore:"Ignore",install:"Install",installed:"installed",integration_plural:"Integrations",integration:"Integration",integrations:"Integrations",lovelace_element:"Lovelace element",lovelace_elements:"Lovelace elements",lovelace:"Lovelace",manage:"manage",netdaemon_apps:"NetDaemon Apps",netdaemon_plural:"NetDaemon Apps",netdaemon:"NetDaemon",plugin_plural:"Lovelace elements",plugin:"Lovelace",plugins:"Lovelace elements",python_script_plural:"Python Scripts",python_script:"Python Script",python_scripts:"Python Scripts",reload:"Reload",repositories:"Repositories",repository:"Repository",settings:"settings",theme_plural:"Themes",theme:"Theme",themes:"Themes",uninstall:"Uninstall",update:"Update",version:"Version"},confirm:{add_to_lovelace:"Are you sure you want to add this to your Lovelace resources?",bg_task:"Action is disabled while background tasks is running.",cancel:"Cancel",continue:"Are you sure you want to continue?",delete_installed:"'{item}' is installed, you need to uninstall it before you can delete it.",delete:"Are you sure you want to delete '{item}'?",exist:"{item} already exists",generic:"Are you sure?",home_assistant_is_restarting:"Hold on, Home Assistant is now restarting.",home_assistant_version_not_correct:"You are running Home Assistant version '{haversion}', but this repository requires minimum version '{minversion}' to be installed.",no_upgrades:"No upgrades pending",no:"No",ok:"OK",overwrite:"Doing this will overwrite it.",reload_data:"This reloads the data of all repositories RACELANDSHOP knows about, this will take some time to finish.",restart_home_assistant:"Are you sure you want to restart Home Assistant?",uninstall:"Are you sure you want to uninstall '{item}'?",upgrade_all:"This will upgrade all of these repositories, make sure that you have read the release notes for all of them before proceeding.",yes:"Yes"},repository:{add_to_lovelace:"Add to Lovelace",authors:"Authors",available:"Available",back_to:"Back to",changelog:"Change log",downloads:"Downloads",flag_this:"Flag this",frontend_version:"Frontend version",github_stars:"GitHub stars",goto_integrations:"Go to integrations",hide_beta:"Hide beta",hide:"Hide",install:"Install",installed:"Installed",lovelace_copy_example:"Copy the example to your clipboard",lovelace_instruction:"When you add this to your lovelace configuration use this",lovelace_no_js_type:"Could not determine the type of this element, check the repository.",newest:"newest",note_appdaemon:"you still need to add it to your 'apps.yaml' file",note_installed:"When installed, this will be located in",note_integration:"you still need to add it to your 'configuration.yaml' file",note_plugin:"you still need to add it to your lovelace configuration ('ui-lovelace.yaml' or the raw UI config editor)",note_plugin_post_107:"you still need to add it to your lovelace configuration ('configuration.yaml' or the resource editor '/config/lovelace/resources')",open_issue:"Open issue",open_plugin:"Open element",reinstall:"Reinstall",repository:"Repository",restart_home_assistant:"Restart Home Assistant",show_beta:"Show beta",uninstall:"Uninstall",update_information:"Update information",upgrade:"Update"},repository_banner:{config_flow:"This integration supports config_flow, that means that you now can go to the integration section of your UI to configure it.",no_restart_required:"No restart required",not_loaded:"Not loaded",plugin_not_loaded:"This element is not added to your Lovelace resources.",restart_pending:"Restart pending",config_flow_title:"UI Configuration supported",restart:"You need to restart Home Assistant."},sections:{integrations:{title:"Integrations",description:"This is where you find custom integrations (custom_components)"},frontend:{title:"Frontend",description:"This is where you find themes, custom cards and other elements for lovelace"},automation:{title:"Automation",description:"This is where you find python_scripts, AppDaemon apps and NetDaemon apps"},addon:{title:"Add-ons",description:"There are no addons in RACELANDSHOP, but you can click here to get to the supervisor"},about:{title:"About",description:"Show information about RACELANDSHOP"},pending_repository_upgrade:"You are running version {installed}, version {available} is available"},settings:{add_custom_repository:"ADD CUSTOM REPOSITORY",adding_new_repo_category:"With category '{category}'.",adding_new_repo:"Adding new repository '{repo}'",bg_task_custom:"Custom repositories are hidden while background tasks is running.",category:"Category",compact_mode:"Compact mode",custom_repositories:"CUSTOM REPOSITORIES",delete:"Delete",display:"Display",grid:"Grid",racelandshop_repo:"RACELANDSHOP repo",hidden_repositories:"hidden repositories",missing_category:"You need to select a category",open_repository:"Open repository",reload_data:"Reload data",repository_configuration:"Repository configuration",save:"Save",table_view:"Table view",table:"Table",unhide:"unhide",upgrade_all:"Upgrade all"},store:{add:"Explore & add repositories",ascending:"ascending",clear_new:"Clear all new repositories",descending:"descending",last_updated:"Last updated",name:"Name",new_repositories_note:"You have over 10 new repositories showing here, if you want to clear them all click the 3 dots in the top right corner and dismiss all of them.",no_repositories:"No repositories",no_repositories_desc1:"It seems like you don't have any repositories installed in this section yet.",no_repositories_desc2:"Click on the + in the bottom corner to add your first!",no_repositories_found_desc1:'No installed repositories matching "{searchInput}" found in this section.',no_repositories_found_desc2:"Try searching for something else!",new_repositories:"New Repositories",pending_upgrades:"Pending upgrades",placeholder_search:"Please enter a search term...",sort:"sort",stars:"Stars",status:"Status"},time:{one_day_ago:"one day ago",one_hour_ago:"one hour ago",one_minute_ago:"one minute ago",one_month_ago:"one month ago",one_second_ago:"one second ago",one_year_ago:"one year ago",x_days_ago:"{x} days ago",x_hours_ago:"{x} hours ago",x_minutes_ago:"{x} minutes ago",x_months_ago:"{x} months ago",x_seconds_ago:"{x} seconds ago",x_years_ago:"{x} years ago"},dialog_about:{integration_version:"Integration version",frontend_version:"Frontend version",installed_repositories:"Installed repositories",useful_links:"Useful links"},dialog_add_repo:{title:"Add repository",no_match:"No repositories found matching your filter",sort_by:"Sort by"},dialog_removed:{name:"Repository name",type:"Removal type",reason:"Removal reason",link:"External link to more information"},dialog_custom_repositories:{title:"Custom repositories",url_placeholder:"Add custom repository URL",category:"Category",no_repository:"Missing repository",no_category:"Missing category"},dialog_install:{type:"Type",url:"URL",select_version:"Select version",show_beta:"Show beta versions",restart:"Remember that you need to restart Home Assistant before changes to integrations (custom_components) are applied."},dialog_info:{version_installed:"Version installed",open_issues:"Open issues",stars:"Stars",downloads:"Downloads",author:"Author",no_info:"The developer has not provided any more information for this repository",open_repo:"Open repository",install:"Install this repository in RACELANDSHOP"},dialog_update:{title:"Update pending",installed_version:"Installed version",available_version:"Available version",changelog:"Changelog",releasenotes:"Release notes for {release}",message:"A new version of the {name} is available",no_info:"The author has not provided any information for this release"},repository_card:{pending_update:"Pending update",pending_restart:"Pending restart",not_loaded:"Not loaded",new_repository:"New repository",hide:"Hide",dismiss:"dismiss",open_source:"Open source",open_issue:"Open issue",reinstall:"Reinstall",report:"Request for removal",information:"Information",update_information:"Update information"},search:{placeholder:"Search for repository",installed:"Search for installed repositories",installed_new:"Search for installed or new repositories"},menu:{about:"About RACELANDSHOP",custom_repositories:"Custom repositories",open_issue:"Open issue",dismiss:"Dismiss all new repositories",documentation:"Documentation"},dialog:{reload:{description:"You need to reload your browser for the updated resources to be used.",confirm:"Do you want to do that now?"},uninstall:{title:"Uninstall",message:"Do you really want to uninstall {name}?"}},entry:{messages:{setup:{title:"RACELANDSHOP is setting up",content:"RACELANDSHOP is setting up, during this time some information might be missing or incorrect"},waiting:{title:"RACELANDSHOP is waiting",content:"RACELANDSHOP is waiting for Home Assistant to finish startup before starting startup tasks"},startup:{title:"RACELANDSHOP is starting up",content:"RACELANDSHOP is starting up, during this time some information might be missing or incorrect"},has_pending_tasks:{title:"Background tasks pending",content:"Some repositories might not show until this is completed"},disabled:{title:"RACELANDSHOP is disabled",rate_limit:{title:"Ratelimited",description:"GitHub API calls are ratelimited, this will clear in less than 1 hour."},removed:{title:"Removed",description:"RACELANDSHOP is removed, restart Home Assistant."},invalid_token:{title:"Invalid token",description:"Reconfigure RACELANDSHOP and restart Home Assistant."},constrains:{title:"Constraints",description:"Your environment is not compatible to run RACELANDSHOP, check your logfile for more details."},load_racelandshop:{title:"RACELANDSHOP could not load",description:"Check your log file for more details"},restore:{title:"Restore of RACELANDSHOP failed",description:"Check your log file for more details"}},wrong_frontend_loaded:{title:"Unexpected frontend version",content:"You are running version {running} of the RACELANDSHOP frontend, but version {expected} was expected, you should clear your browser cache."},wrong_frontend_installed:{title:"Unexpected frontend version",content:"You have {running} of the RACELANDSHOP frontend installed, but version {expected} was expected, if this you see this message Home Assistant was not able to install the new version, try restarting Home Assistant."},resources:{title:"Not loaded in Lovelace",content:"You have {number} Lovelace elements that are not loaded properly in Lovelace."},restart:{title:"Pending restart",content:"You have {number} {pluralWording} for which a restart of Home Assistant is required. You can do that from the 'Server Controls' section under the configuration part of Home Assistant UI."},removed:"Removed repository '{repository}'"},intro:"Updates and important messages will show here if there are any",information:"Information",pending_updates:"Pending updates"}}},ds={language:[],sting:{}};function ps(e,t,r){let i;const o=new ls("localize"),n=t.split("."),a=(e||localStorage.getItem("selectedLanguage")||"en").replace(/['"]+/g,"").replace("-","_");cs[a]||ds.language.includes(a)||(ds.language.push(a),o.warn(`Language '${a.replace("_","-")}' is not added to RACELANDSHOP. https://racelandshop.xyz/docs/developer/translation`));try{i=cs[a],n.forEach(e=>{i=i[e]})}catch(e){cs[a]&&!ds.sting[a]&&(ds.sting[a]=[]),cs[a]&&!ds.sting[a].includes(t)&&(ds.sting[a].push(t),o.warn(`Translation string '${t}' for '${a.replace("_","-")}' is not added to RACELANDSHOP. https://racelandshop.xyz/docs/developer/translation`)),i=void 0}if(void 0===i&&(i=cs.en,n.forEach(e=>{i=i[e]})),r){const e=Object.keys(r);for(const n of e)i.includes(n)?i=i.replace(`{${n}}`,r[n]):o.error(`Variable '${n}' does not exist in '${t}' with '${a}'`);(i.includes("{")||i.includes("}"))&&o.error(`Translation for '${t}' with '${a}' is missing variables`)}return i}const hs=e=>({updates:[],messages:[],subsections:{main:[{categories:["integration"],iconPath:"M20.5,11H19V7C19,5.89 18.1,5 17,5H13V3.5A2.5,2.5 0 0,0 10.5,1A2.5,2.5 0 0,0 8,3.5V5H4A2,2 0 0,0 2,7V10.8H3.5C5,10.8 6.2,12 6.2,13.5C6.2,15 5,16.2 3.5,16.2H2V20A2,2 0 0,0 4,22H7.8V20.5C7.8,19 9,17.8 10.5,17.8C12,17.8 13.2,19 13.2,20.5V22H17A2,2 0 0,0 19,20V16H20.5A2.5,2.5 0 0,0 23,13.5A2.5,2.5 0 0,0 20.5,11Z",id:"integrations",info:ps(e,"sections.integrations.description"),name:ps(e,"sections.integrations.title"),path:"/racelandshop/integrations",core:!0},{categories:["plugin","theme"],iconPath:"M17.5,12A1.5,1.5 0 0,1 16,10.5A1.5,1.5 0 0,1 17.5,9A1.5,1.5 0 0,1 19,10.5A1.5,1.5 0 0,1 17.5,12M14.5,8A1.5,1.5 0 0,1 13,6.5A1.5,1.5 0 0,1 14.5,5A1.5,1.5 0 0,1 16,6.5A1.5,1.5 0 0,1 14.5,8M9.5,8A1.5,1.5 0 0,1 8,6.5A1.5,1.5 0 0,1 9.5,5A1.5,1.5 0 0,1 11,6.5A1.5,1.5 0 0,1 9.5,8M6.5,12A1.5,1.5 0 0,1 5,10.5A1.5,1.5 0 0,1 6.5,9A1.5,1.5 0 0,1 8,10.5A1.5,1.5 0 0,1 6.5,12M12,3A9,9 0 0,0 3,12A9,9 0 0,0 12,21A1.5,1.5 0 0,0 13.5,19.5C13.5,19.11 13.35,18.76 13.11,18.5C12.88,18.23 12.73,17.88 12.73,17.5A1.5,1.5 0 0,1 14.23,16H16A5,5 0 0,0 21,11C21,6.58 16.97,3 12,3Z",id:"frontend",info:ps(e,"sections.frontend.description"),name:ps(e,"sections.frontend.title"),path:"/racelandshop/frontend",core:!0},{categories:["python_script","appdaemon","netdaemon"],iconPath:"M12,2A2,2 0 0,1 14,4C14,4.74 13.6,5.39 13,5.73V7H14A7,7 0 0,1 21,14H22A1,1 0 0,1 23,15V18A1,1 0 0,1 22,19H21V20A2,2 0 0,1 19,22H5A2,2 0 0,1 3,20V19H2A1,1 0 0,1 1,18V15A1,1 0 0,1 2,14H3A7,7 0 0,1 10,7H11V5.73C10.4,5.39 10,4.74 10,4A2,2 0 0,1 12,2M7.5,13A2.5,2.5 0 0,0 5,15.5A2.5,2.5 0 0,0 7.5,18A2.5,2.5 0 0,0 10,15.5A2.5,2.5 0 0,0 7.5,13M16.5,13A2.5,2.5 0 0,0 14,15.5A2.5,2.5 0 0,0 16.5,18A2.5,2.5 0 0,0 19,15.5A2.5,2.5 0 0,0 16.5,13Z",id:"automation",info:ps(e,"sections.automation.description"),name:ps(e,"sections.automation.title"),path:"/racelandshop/automation",core:!0}]}}),us=Ba((e,t)=>hs(e).subsections.main.filter(e=>{const r=e.categories;return 0!==(null==r?void 0:r.filter(e=>{var r;return null==t||null===(r=t.categories)||void 0===r?void 0:r.includes(e)}).length)})),fs=(e,t)=>{const r=t.path.replace("/","");return hs(e).subsections.main.find(e=>e.id==r)},ms=e=>`/racelandshopfiles/${e.repository.full_name.split("/")[1]}/${e.repository.file_name}${e.skipTag?"":"?racelandshoptag="+((e,t)=>String(`${e.id}${(t||e.installed_version||e.selected_tag||e.available_version).replace(/\D+/g,"")}`))(e.repository,e.version)}`,gs=(e,t)=>{var r,i;if(!t.installed)return!0;if("plugin"!==t.category)return!0;if("storage"!==(null===(r=e.status)||void 0===r?void 0:r.lovelace_mode))return!0;const o=ms({repository:t,skipTag:!0});return(null===(i=e.resources)||void 0===i?void 0:i.some(e=>e.url.includes(o)))||!1};let ys=a(null,(function(e,i){class o extends i{constructor(...t){super(...t),e(this)}}return{F:o,d:[{kind:"field",decorators:[_e({attribute:!1})],key:"racelandshop",value:void 0},{kind:"method",key:"connectedCallback",value:function(){r(t(o.prototype),"connectedCallback",this).call(this),void 0===this.racelandshop&&(this.racelandshop={language:"en",messages:[],updates:[],resources:[],repositories:[],removed:[],sections:[],configuration:{},status:{},addedToLovelace:gs,localize:(e,t)=>{var r;return ps((null===(r=this.racelandshop)||void 0===r?void 0:r.language)||"en",e,t)},log:new ls}),this.addEventListener("update-racelandshop",e=>this._updateRacelandshop(e.detail))}},{kind:"method",key:"_updateRacelandshop",value:function(e){let t=!1;Object.keys(e).forEach(r=>{JSON.stringify(this.racelandshop[r])!==JSON.stringify(e[r])&&(t=!0)}),t&&(this.racelandshop={...this.racelandshop,...e})}},{kind:"method",key:"updated",value:function(){this.racelandshop.sections=us(this.racelandshop.language,this.racelandshop.configuration)}}]}}),(_s=me,class extends _s{constructor(...t){super(...t),e(this,"hass",void 0),e(this,"__provideHass",[])}provideHass(e){this.__provideHass.push(e),e.hass=this.hass}updated(e){super.updated(e),e.has("hass")&&this.__provideHass.forEach(e=>{e.hass=this.hass})}}));var _s;const bs=(e,t)=>{const r=matchMedia(e),i=e=>t(e.matches);return r.addListener(i),t(r.matches),()=>r.removeListener(i)};var vs=function(e,t){return(vs=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r])})(e,t)};function ws(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Class extends value "+String(t)+" is not a constructor or null");function r(){this.constructor=e}vs(e,t),e.prototype=null===t?Object.create(t):(r.prototype=t.prototype,new r)}var xs=function(){return(xs=Object.assign||function(e){for(var t,r=1,i=arguments.length;r<i;r++)for(var o in t=arguments[r])Object.prototype.hasOwnProperty.call(t,o)&&(e[o]=t[o]);return e}).apply(this,arguments)};function ks(e,t,r,i){var o,n=arguments.length,a=n<3?t:null===i?i=Object.getOwnPropertyDescriptor(t,r):i;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,r,i);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(n<3?o(a):n>3?o(t,r,a):o(t,r))||a);return n>3&&a&&Object.defineProperty(t,r,a),a}function Cs(e){var t="function"==typeof Symbol&&Symbol.iterator,r=t&&e[t],i=0;if(r)return r.call(e);if(e&&"number"==typeof e.length)return{next:function(){return e&&i>=e.length&&(e=void 0),{value:e&&e[i++],done:!e}}};throw new TypeError(t?"Object is not iterable.":"Symbol.iterator is not defined.")}console.warn("The main 'lit-element' module entrypoint is deprecated. Please update your imports to use the 'lit' package: 'lit' and 'lit/decorators.ts' or import from 'lit-element/lit-element.ts'.");const Ps=y`:host{font-family:var(--mdc-icon-font, "Material Icons");font-weight:normal;font-style:normal;font-size:var(--mdc-icon-size, 24px);line-height:1;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;-moz-osx-font-smoothing:grayscale;font-feature-settings:"liga"}`;let Ss=class extends me{render(){return G`<slot></slot>`}};function As(e,t){if(e.closest)return e.closest(t);for(var r=e;r;){if(Es(r,t))return r;r=r.parentElement}return null}function Es(e,t){return(e.matches||e.webkitMatchesSelector||e.msMatchesSelector).call(e,t)}Ss.styles=[Ps],Ss=ks([ge("mwc-icon")],Ss);const Os=e=>e.nodeType===Node.ELEMENT_NODE;function Ts(e){return{addClass:t=>{e.classList.add(t)},removeClass:t=>{e.classList.remove(t)},hasClass:t=>e.classList.contains(t)}}const Ns=()=>{},Rs={get passive(){return!1}};document.addEventListener("x",Ns,Rs),document.removeEventListener("x",Ns);const Ds=(e=window.document)=>{let t=e.activeElement;const r=[];if(!t)return r;for(;t&&(r.push(t),t.shadowRoot);)t=t.shadowRoot.activeElement;return r},Is=e=>{const t=Ds();if(!t.length)return!1;const r=t[t.length-1],i=new Event("check-if-focused",{bubbles:!0,composed:!0});let o=[];const n=e=>{o=e.composedPath()};return document.body.addEventListener("check-if-focused",n),r.dispatchEvent(i),document.body.removeEventListener("check-if-focused",n),-1!==o.indexOf(e)};class Ls extends me{click(){if(this.mdcRoot)return this.mdcRoot.focus(),void this.mdcRoot.click();super.click()}createFoundation(){void 0!==this.mdcFoundation&&this.mdcFoundation.destroy(),this.mdcFoundationClass&&(this.mdcFoundation=new this.mdcFoundationClass(this.createAdapter()),this.mdcFoundation.init())}firstUpdated(){this.createFoundation()}}var Ms=function(){function e(e){void 0===e&&(e={}),this.adapter=e}return Object.defineProperty(e,"cssClasses",{get:function(){return{}},enumerable:!1,configurable:!0}),Object.defineProperty(e,"strings",{get:function(){return{}},enumerable:!1,configurable:!0}),Object.defineProperty(e,"numbers",{get:function(){return{}},enumerable:!1,configurable:!0}),Object.defineProperty(e,"defaultAdapter",{get:function(){return{}},enumerable:!1,configurable:!0}),e.prototype.init=function(){},e.prototype.destroy=function(){},e}(),Hs={BG_FOCUSED:"mdc-ripple-upgraded--background-focused",FG_ACTIVATION:"mdc-ripple-upgraded--foreground-activation",FG_DEACTIVATION:"mdc-ripple-upgraded--foreground-deactivation",ROOT:"mdc-ripple-upgraded",UNBOUNDED:"mdc-ripple-upgraded--unbounded"},Fs={VAR_FG_SCALE:"--mdc-ripple-fg-scale",VAR_FG_SIZE:"--mdc-ripple-fg-size",VAR_FG_TRANSLATE_END:"--mdc-ripple-fg-translate-end",VAR_FG_TRANSLATE_START:"--mdc-ripple-fg-translate-start",VAR_LEFT:"--mdc-ripple-left",VAR_TOP:"--mdc-ripple-top"},$s={DEACTIVATION_TIMEOUT_MS:225,FG_DEACTIVATION_MS:150,INITIAL_ORIGIN_SCALE:.6,PADDING:10,TAP_DELAY_MS:300};var zs=["touchstart","pointerdown","mousedown","keydown"],js=["touchend","pointerup","mouseup","contextmenu"],Bs=[],Us=function(e){function t(r){var i=e.call(this,xs(xs({},t.defaultAdapter),r))||this;return i.activationAnimationHasEnded=!1,i.activationTimer=0,i.fgDeactivationRemovalTimer=0,i.fgScale="0",i.frame={width:0,height:0},i.initialSize=0,i.layoutFrame=0,i.maxRadius=0,i.unboundedCoords={left:0,top:0},i.activationState=i.defaultActivationState(),i.activationTimerCallback=function(){i.activationAnimationHasEnded=!0,i.runDeactivationUXLogicIfReady()},i.activateHandler=function(e){i.activateImpl(e)},i.deactivateHandler=function(){i.deactivateImpl()},i.focusHandler=function(){i.handleFocus()},i.blurHandler=function(){i.handleBlur()},i.resizeHandler=function(){i.layout()},i}return ws(t,e),Object.defineProperty(t,"cssClasses",{get:function(){return Hs},enumerable:!1,configurable:!0}),Object.defineProperty(t,"strings",{get:function(){return Fs},enumerable:!1,configurable:!0}),Object.defineProperty(t,"numbers",{get:function(){return $s},enumerable:!1,configurable:!0}),Object.defineProperty(t,"defaultAdapter",{get:function(){return{addClass:function(){},browserSupportsCssVars:function(){return!0},computeBoundingRect:function(){return{top:0,right:0,bottom:0,left:0,width:0,height:0}},containsEventTarget:function(){return!0},deregisterDocumentInteractionHandler:function(){},deregisterInteractionHandler:function(){},deregisterResizeHandler:function(){},getWindowPageOffset:function(){return{x:0,y:0}},isSurfaceActive:function(){return!0},isSurfaceDisabled:function(){return!0},isUnbounded:function(){return!0},registerDocumentInteractionHandler:function(){},registerInteractionHandler:function(){},registerResizeHandler:function(){},removeClass:function(){},updateCssVariable:function(){}}},enumerable:!1,configurable:!0}),t.prototype.init=function(){var e=this,r=this.supportsPressRipple();if(this.registerRootHandlers(r),r){var i=t.cssClasses,o=i.ROOT,n=i.UNBOUNDED;requestAnimationFrame((function(){e.adapter.addClass(o),e.adapter.isUnbounded()&&(e.adapter.addClass(n),e.layoutInternal())}))}},t.prototype.destroy=function(){var e=this;if(this.supportsPressRipple()){this.activationTimer&&(clearTimeout(this.activationTimer),this.activationTimer=0,this.adapter.removeClass(t.cssClasses.FG_ACTIVATION)),this.fgDeactivationRemovalTimer&&(clearTimeout(this.fgDeactivationRemovalTimer),this.fgDeactivationRemovalTimer=0,this.adapter.removeClass(t.cssClasses.FG_DEACTIVATION));var r=t.cssClasses,i=r.ROOT,o=r.UNBOUNDED;requestAnimationFrame((function(){e.adapter.removeClass(i),e.adapter.removeClass(o),e.removeCssVars()}))}this.deregisterRootHandlers(),this.deregisterDeactivationHandlers()},t.prototype.activate=function(e){this.activateImpl(e)},t.prototype.deactivate=function(){this.deactivateImpl()},t.prototype.layout=function(){var e=this;this.layoutFrame&&cancelAnimationFrame(this.layoutFrame),this.layoutFrame=requestAnimationFrame((function(){e.layoutInternal(),e.layoutFrame=0}))},t.prototype.setUnbounded=function(e){var r=t.cssClasses.UNBOUNDED;e?this.adapter.addClass(r):this.adapter.removeClass(r)},t.prototype.handleFocus=function(){var e=this;requestAnimationFrame((function(){return e.adapter.addClass(t.cssClasses.BG_FOCUSED)}))},t.prototype.handleBlur=function(){var e=this;requestAnimationFrame((function(){return e.adapter.removeClass(t.cssClasses.BG_FOCUSED)}))},t.prototype.supportsPressRipple=function(){return this.adapter.browserSupportsCssVars()},t.prototype.defaultActivationState=function(){return{activationEvent:void 0,hasDeactivationUXRun:!1,isActivated:!1,isProgrammatic:!1,wasActivatedByPointer:!1,wasElementMadeActive:!1}},t.prototype.registerRootHandlers=function(e){var t,r;if(e){try{for(var i=Cs(zs),o=i.next();!o.done;o=i.next()){var n=o.value;this.adapter.registerInteractionHandler(n,this.activateHandler)}}catch(e){t={error:e}}finally{try{o&&!o.done&&(r=i.return)&&r.call(i)}finally{if(t)throw t.error}}this.adapter.isUnbounded()&&this.adapter.registerResizeHandler(this.resizeHandler)}this.adapter.registerInteractionHandler("focus",this.focusHandler),this.adapter.registerInteractionHandler("blur",this.blurHandler)},t.prototype.registerDeactivationHandlers=function(e){var t,r;if("keydown"===e.type)this.adapter.registerInteractionHandler("keyup",this.deactivateHandler);else try{for(var i=Cs(js),o=i.next();!o.done;o=i.next()){var n=o.value;this.adapter.registerDocumentInteractionHandler(n,this.deactivateHandler)}}catch(e){t={error:e}}finally{try{o&&!o.done&&(r=i.return)&&r.call(i)}finally{if(t)throw t.error}}},t.prototype.deregisterRootHandlers=function(){var e,t;try{for(var r=Cs(zs),i=r.next();!i.done;i=r.next()){var o=i.value;this.adapter.deregisterInteractionHandler(o,this.activateHandler)}}catch(t){e={error:t}}finally{try{i&&!i.done&&(t=r.return)&&t.call(r)}finally{if(e)throw e.error}}this.adapter.deregisterInteractionHandler("focus",this.focusHandler),this.adapter.deregisterInteractionHandler("blur",this.blurHandler),this.adapter.isUnbounded()&&this.adapter.deregisterResizeHandler(this.resizeHandler)},t.prototype.deregisterDeactivationHandlers=function(){var e,t;this.adapter.deregisterInteractionHandler("keyup",this.deactivateHandler);try{for(var r=Cs(js),i=r.next();!i.done;i=r.next()){var o=i.value;this.adapter.deregisterDocumentInteractionHandler(o,this.deactivateHandler)}}catch(t){e={error:t}}finally{try{i&&!i.done&&(t=r.return)&&t.call(r)}finally{if(e)throw e.error}}},t.prototype.removeCssVars=function(){var e=this,r=t.strings;Object.keys(r).forEach((function(t){0===t.indexOf("VAR_")&&e.adapter.updateCssVariable(r[t],null)}))},t.prototype.activateImpl=function(e){var t=this;if(!this.adapter.isSurfaceDisabled()){var r=this.activationState;if(!r.isActivated){var i=this.previousActivationEvent;if(!(i&&void 0!==e&&i.type!==e.type))r.isActivated=!0,r.isProgrammatic=void 0===e,r.activationEvent=e,r.wasActivatedByPointer=!r.isProgrammatic&&(void 0!==e&&("mousedown"===e.type||"touchstart"===e.type||"pointerdown"===e.type)),void 0!==e&&Bs.length>0&&Bs.some((function(e){return t.adapter.containsEventTarget(e)}))?this.resetActivationState():(void 0!==e&&(Bs.push(e.target),this.registerDeactivationHandlers(e)),r.wasElementMadeActive=this.checkElementMadeActive(e),r.wasElementMadeActive&&this.animateActivation(),requestAnimationFrame((function(){Bs=[],r.wasElementMadeActive||void 0===e||" "!==e.key&&32!==e.keyCode||(r.wasElementMadeActive=t.checkElementMadeActive(e),r.wasElementMadeActive&&t.animateActivation()),r.wasElementMadeActive||(t.activationState=t.defaultActivationState())})))}}},t.prototype.checkElementMadeActive=function(e){return void 0===e||"keydown"!==e.type||this.adapter.isSurfaceActive()},t.prototype.animateActivation=function(){var e=this,r=t.strings,i=r.VAR_FG_TRANSLATE_START,o=r.VAR_FG_TRANSLATE_END,n=t.cssClasses,a=n.FG_DEACTIVATION,s=n.FG_ACTIVATION,l=t.numbers.DEACTIVATION_TIMEOUT_MS;this.layoutInternal();var c="",d="";if(!this.adapter.isUnbounded()){var p=this.getFgTranslationCoordinates(),h=p.startPoint,u=p.endPoint;c=h.x+"px, "+h.y+"px",d=u.x+"px, "+u.y+"px"}this.adapter.updateCssVariable(i,c),this.adapter.updateCssVariable(o,d),clearTimeout(this.activationTimer),clearTimeout(this.fgDeactivationRemovalTimer),this.rmBoundedActivationClasses(),this.adapter.removeClass(a),this.adapter.computeBoundingRect(),this.adapter.addClass(s),this.activationTimer=setTimeout((function(){e.activationTimerCallback()}),l)},t.prototype.getFgTranslationCoordinates=function(){var e,t=this.activationState,r=t.activationEvent;return{startPoint:e={x:(e=t.wasActivatedByPointer?function(e,t,r){if(!e)return{x:0,y:0};var i,o,n=t.x,a=t.y,s=n+r.left,l=a+r.top;if("touchstart"===e.type){var c=e;i=c.changedTouches[0].pageX-s,o=c.changedTouches[0].pageY-l}else{var d=e;i=d.pageX-s,o=d.pageY-l}return{x:i,y:o}}(r,this.adapter.getWindowPageOffset(),this.adapter.computeBoundingRect()):{x:this.frame.width/2,y:this.frame.height/2}).x-this.initialSize/2,y:e.y-this.initialSize/2},endPoint:{x:this.frame.width/2-this.initialSize/2,y:this.frame.height/2-this.initialSize/2}}},t.prototype.runDeactivationUXLogicIfReady=function(){var e=this,r=t.cssClasses.FG_DEACTIVATION,i=this.activationState,o=i.hasDeactivationUXRun,n=i.isActivated;(o||!n)&&this.activationAnimationHasEnded&&(this.rmBoundedActivationClasses(),this.adapter.addClass(r),this.fgDeactivationRemovalTimer=setTimeout((function(){e.adapter.removeClass(r)}),$s.FG_DEACTIVATION_MS))},t.prototype.rmBoundedActivationClasses=function(){var e=t.cssClasses.FG_ACTIVATION;this.adapter.removeClass(e),this.activationAnimationHasEnded=!1,this.adapter.computeBoundingRect()},t.prototype.resetActivationState=function(){var e=this;this.previousActivationEvent=this.activationState.activationEvent,this.activationState=this.defaultActivationState(),setTimeout((function(){return e.previousActivationEvent=void 0}),t.numbers.TAP_DELAY_MS)},t.prototype.deactivateImpl=function(){var e=this,t=this.activationState;if(t.isActivated){var r=xs({},t);t.isProgrammatic?(requestAnimationFrame((function(){e.animateDeactivation(r)})),this.resetActivationState()):(this.deregisterDeactivationHandlers(),requestAnimationFrame((function(){e.activationState.hasDeactivationUXRun=!0,e.animateDeactivation(r),e.resetActivationState()})))}},t.prototype.animateDeactivation=function(e){var t=e.wasActivatedByPointer,r=e.wasElementMadeActive;(t||r)&&this.runDeactivationUXLogicIfReady()},t.prototype.layoutInternal=function(){var e=this;this.frame=this.adapter.computeBoundingRect();var r=Math.max(this.frame.height,this.frame.width);this.maxRadius=this.adapter.isUnbounded()?r:Math.sqrt(Math.pow(e.frame.width,2)+Math.pow(e.frame.height,2))+t.numbers.PADDING;var i=Math.floor(r*t.numbers.INITIAL_ORIGIN_SCALE);this.adapter.isUnbounded()&&i%2!=0?this.initialSize=i-1:this.initialSize=i,this.fgScale=""+this.maxRadius/this.initialSize,this.updateLayoutCssVars()},t.prototype.updateLayoutCssVars=function(){var e=t.strings,r=e.VAR_FG_SIZE,i=e.VAR_LEFT,o=e.VAR_TOP,n=e.VAR_FG_SCALE;this.adapter.updateCssVariable(r,this.initialSize+"px"),this.adapter.updateCssVariable(n,this.fgScale),this.adapter.isUnbounded()&&(this.unboundedCoords={left:Math.round(this.frame.width/2-this.initialSize/2),top:Math.round(this.frame.height/2-this.initialSize/2)},this.adapter.updateCssVariable(i,this.unboundedCoords.left+"px"),this.adapter.updateCssVariable(o,this.unboundedCoords.top+"px"))},t}(Ms);const Vs=1,qs=e=>(...t)=>({_$litDirective$:e,values:t});class Ys{constructor(e){}T(e,t,r){this.Σdt=e,this.M=t,this.Σct=r}S(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}}const Js=qs(class extends Ys{constructor(e){var t;if(super(e),e.type!==Vs||"class"!==e.name||(null===(t=e.strings)||void 0===t?void 0:t.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(e){return Object.keys(e).filter(t=>e[t]).join(" ")}update(e,[t]){if(void 0===this.bt){this.bt=new Set;for(const e in t)t[e]&&this.bt.add(e);return this.render(t)}const r=e.element.classList;this.bt.forEach(e=>{e in t||(r.remove(e),this.bt.delete(e))});for(const e in t){const i=!!t[e];i!==this.bt.has(e)&&(i?(r.add(e),this.bt.add(e)):(r.remove(e),this.bt.delete(e)))}return Z}}),Gs=qs(class extends Ys{constructor(e){var t;if(super(e),e.type!==Vs||"style"!==e.name||(null===(t=e.strings)||void 0===t?void 0:t.length)>2)throw Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.")}render(e){return Object.keys(e).reduce((t,r)=>{const i=e[r];return null==i?t:t+`${r=r.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g,"-$&").toLowerCase()}:${i};`},"")}update(e,[t]){const{style:r}=e.element;if(void 0===this.St){this.St=new Set;for(const e in t)this.St.add(e);return this.render(t)}this.St.forEach(e=>{null==t[e]&&(this.St.delete(e),e.includes("-")?r.removeProperty(e):r[e]="")});for(const e in t){const i=t[e];null!=i&&(this.St.add(e),e.includes("-")?r.setProperty(e,i):r[e]=i)}return Z}});class Ws extends Ls{constructor(){super(...arguments),this.primary=!1,this.accent=!1,this.unbounded=!1,this.disabled=!1,this.activated=!1,this.selected=!1,this.internalUseStateLayerCustomProperties=!1,this.hovering=!1,this.bgFocused=!1,this.fgActivation=!1,this.fgDeactivation=!1,this.fgScale="",this.fgSize="",this.translateStart="",this.translateEnd="",this.leftPos="",this.topPos="",this.mdcFoundationClass=Us}get isActive(){return Es(this.parentElement||this,":active")}createAdapter(){return{browserSupportsCssVars:()=>!0,isUnbounded:()=>this.unbounded,isSurfaceActive:()=>this.isActive,isSurfaceDisabled:()=>this.disabled,addClass:e=>{switch(e){case"mdc-ripple-upgraded--background-focused":this.bgFocused=!0;break;case"mdc-ripple-upgraded--foreground-activation":this.fgActivation=!0;break;case"mdc-ripple-upgraded--foreground-deactivation":this.fgDeactivation=!0}},removeClass:e=>{switch(e){case"mdc-ripple-upgraded--background-focused":this.bgFocused=!1;break;case"mdc-ripple-upgraded--foreground-activation":this.fgActivation=!1;break;case"mdc-ripple-upgraded--foreground-deactivation":this.fgDeactivation=!1}},containsEventTarget:()=>!0,registerInteractionHandler:()=>{},deregisterInteractionHandler:()=>{},registerDocumentInteractionHandler:()=>{},deregisterDocumentInteractionHandler:()=>{},registerResizeHandler:()=>{},deregisterResizeHandler:()=>{},updateCssVariable:(e,t)=>{switch(e){case"--mdc-ripple-fg-scale":this.fgScale=t;break;case"--mdc-ripple-fg-size":this.fgSize=t;break;case"--mdc-ripple-fg-translate-end":this.translateEnd=t;break;case"--mdc-ripple-fg-translate-start":this.translateStart=t;break;case"--mdc-ripple-left":this.leftPos=t;break;case"--mdc-ripple-top":this.topPos=t}},computeBoundingRect:()=>(this.parentElement||this).getBoundingClientRect(),getWindowPageOffset:()=>({x:window.pageXOffset,y:window.pageYOffset})}}startPress(e){this.waitForFoundation(()=>{this.mdcFoundation.activate(e)})}endPress(){this.waitForFoundation(()=>{this.mdcFoundation.deactivate()})}startFocus(){this.waitForFoundation(()=>{this.mdcFoundation.handleFocus()})}endFocus(){this.waitForFoundation(()=>{this.mdcFoundation.handleBlur()})}startHover(){this.hovering=!0}endHover(){this.hovering=!1}waitForFoundation(e){this.mdcFoundation?e():this.updateComplete.then(e)}update(e){e.has("disabled")&&this.disabled&&this.endHover(),super.update(e)}render(){const e=this.activated&&(this.primary||!this.accent),t=this.selected&&(this.primary||!this.accent),r={"mdc-ripple-surface--accent":this.accent,"mdc-ripple-surface--primary--activated":e,"mdc-ripple-surface--accent--activated":this.accent&&this.activated,"mdc-ripple-surface--primary--selected":t,"mdc-ripple-surface--accent--selected":this.accent&&this.selected,"mdc-ripple-surface--disabled":this.disabled,"mdc-ripple-surface--hover":this.hovering,"mdc-ripple-surface--primary":this.primary,"mdc-ripple-surface--selected":this.selected,"mdc-ripple-upgraded--background-focused":this.bgFocused,"mdc-ripple-upgraded--foreground-activation":this.fgActivation,"mdc-ripple-upgraded--foreground-deactivation":this.fgDeactivation,"mdc-ripple-upgraded--unbounded":this.unbounded,"mdc-ripple-surface--internal-use-state-layer-custom-properties":this.internalUseStateLayerCustomProperties};return G`
        <div class="mdc-ripple-surface mdc-ripple-upgraded ${Js(r)}"
          style="${Gs({"--mdc-ripple-fg-scale":this.fgScale,"--mdc-ripple-fg-size":this.fgSize,"--mdc-ripple-fg-translate-end":this.translateEnd,"--mdc-ripple-fg-translate-start":this.translateStart,"--mdc-ripple-left":this.leftPos,"--mdc-ripple-top":this.topPos})}"></div>`}}ks([xe(".mdc-ripple-surface")],Ws.prototype,"mdcRoot",void 0),ks([_e({type:Boolean})],Ws.prototype,"primary",void 0),ks([_e({type:Boolean})],Ws.prototype,"accent",void 0),ks([_e({type:Boolean})],Ws.prototype,"unbounded",void 0),ks([_e({type:Boolean})],Ws.prototype,"disabled",void 0),ks([_e({type:Boolean})],Ws.prototype,"activated",void 0),ks([_e({type:Boolean})],Ws.prototype,"selected",void 0),ks([_e({type:Boolean})],Ws.prototype,"internalUseStateLayerCustomProperties",void 0),ks([be()],Ws.prototype,"hovering",void 0),ks([be()],Ws.prototype,"bgFocused",void 0),ks([be()],Ws.prototype,"fgActivation",void 0),ks([be()],Ws.prototype,"fgDeactivation",void 0),ks([be()],Ws.prototype,"fgScale",void 0),ks([be()],Ws.prototype,"fgSize",void 0),ks([be()],Ws.prototype,"translateStart",void 0),ks([be()],Ws.prototype,"translateEnd",void 0),ks([be()],Ws.prototype,"leftPos",void 0),ks([be()],Ws.prototype,"topPos",void 0);const Zs=y`.mdc-ripple-surface{--mdc-ripple-fg-size: 0;--mdc-ripple-left: 0;--mdc-ripple-top: 0;--mdc-ripple-fg-scale: 1;--mdc-ripple-fg-translate-end: 0;--mdc-ripple-fg-translate-start: 0;-webkit-tap-highlight-color:rgba(0,0,0,0);will-change:transform,opacity;position:relative;outline:none;overflow:hidden}.mdc-ripple-surface::before,.mdc-ripple-surface::after{position:absolute;border-radius:50%;opacity:0;pointer-events:none;content:""}.mdc-ripple-surface::before{transition:opacity 15ms linear,background-color 15ms linear;z-index:1;z-index:var(--mdc-ripple-z-index, 1)}.mdc-ripple-surface::after{z-index:0;z-index:var(--mdc-ripple-z-index, 0)}.mdc-ripple-surface.mdc-ripple-upgraded::before{transform:scale(var(--mdc-ripple-fg-scale, 1))}.mdc-ripple-surface.mdc-ripple-upgraded::after{top:0;left:0;transform:scale(0);transform-origin:center center}.mdc-ripple-surface.mdc-ripple-upgraded--unbounded::after{top:var(--mdc-ripple-top, 0);left:var(--mdc-ripple-left, 0)}.mdc-ripple-surface.mdc-ripple-upgraded--foreground-activation::after{animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards}.mdc-ripple-surface.mdc-ripple-upgraded--foreground-deactivation::after{animation:mdc-ripple-fg-opacity-out 150ms;transform:translate(var(--mdc-ripple-fg-translate-end, 0)) scale(var(--mdc-ripple-fg-scale, 1))}.mdc-ripple-surface::before,.mdc-ripple-surface::after{top:calc(50% - 100%);left:calc(50% - 100%);width:200%;height:200%}.mdc-ripple-surface.mdc-ripple-upgraded::after{width:var(--mdc-ripple-fg-size, 100%);height:var(--mdc-ripple-fg-size, 100%)}.mdc-ripple-surface[data-mdc-ripple-is-unbounded],.mdc-ripple-upgraded--unbounded{overflow:visible}.mdc-ripple-surface[data-mdc-ripple-is-unbounded]::before,.mdc-ripple-surface[data-mdc-ripple-is-unbounded]::after,.mdc-ripple-upgraded--unbounded::before,.mdc-ripple-upgraded--unbounded::after{top:calc(50% - 50%);left:calc(50% - 50%);width:100%;height:100%}.mdc-ripple-surface[data-mdc-ripple-is-unbounded].mdc-ripple-upgraded::before,.mdc-ripple-surface[data-mdc-ripple-is-unbounded].mdc-ripple-upgraded::after,.mdc-ripple-upgraded--unbounded.mdc-ripple-upgraded::before,.mdc-ripple-upgraded--unbounded.mdc-ripple-upgraded::after{top:var(--mdc-ripple-top, calc(50% - 50%));left:var(--mdc-ripple-left, calc(50% - 50%));width:var(--mdc-ripple-fg-size, 100%);height:var(--mdc-ripple-fg-size, 100%)}.mdc-ripple-surface[data-mdc-ripple-is-unbounded].mdc-ripple-upgraded::after,.mdc-ripple-upgraded--unbounded.mdc-ripple-upgraded::after{width:var(--mdc-ripple-fg-size, 100%);height:var(--mdc-ripple-fg-size, 100%)}.mdc-ripple-surface::before,.mdc-ripple-surface::after{background-color:#000;background-color:var(--mdc-ripple-color, #000)}.mdc-ripple-surface:hover::before,.mdc-ripple-surface.mdc-ripple-surface--hover::before{opacity:0.04;opacity:var(--mdc-ripple-hover-opacity, 0.04)}.mdc-ripple-surface.mdc-ripple-upgraded--background-focused::before,.mdc-ripple-surface:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:0.12;opacity:var(--mdc-ripple-focus-opacity, 0.12)}.mdc-ripple-surface:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:0.12;opacity:var(--mdc-ripple-press-opacity, 0.12)}.mdc-ripple-surface.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity, 0.12)}@keyframes mdc-ripple-fg-radius-in{from{animation-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transform:translate(var(--mdc-ripple-fg-translate-start, 0)) scale(1)}to{transform:translate(var(--mdc-ripple-fg-translate-end, 0)) scale(var(--mdc-ripple-fg-scale, 1))}}@keyframes mdc-ripple-fg-opacity-in{from{animation-timing-function:linear;opacity:0}to{opacity:var(--mdc-ripple-fg-opacity, 0)}}@keyframes mdc-ripple-fg-opacity-out{from{animation-timing-function:linear;opacity:var(--mdc-ripple-fg-opacity, 0)}to{opacity:0}}:host{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;display:block}:host .mdc-ripple-surface{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;will-change:unset}.mdc-ripple-surface--primary::before,.mdc-ripple-surface--primary::after{background-color:#6200ee;background-color:var(--mdc-ripple-color, var(--mdc-theme-primary, #6200ee))}.mdc-ripple-surface--primary:hover::before,.mdc-ripple-surface--primary.mdc-ripple-surface--hover::before{opacity:0.04;opacity:var(--mdc-ripple-hover-opacity, 0.04)}.mdc-ripple-surface--primary.mdc-ripple-upgraded--background-focused::before,.mdc-ripple-surface--primary:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:0.12;opacity:var(--mdc-ripple-focus-opacity, 0.12)}.mdc-ripple-surface--primary:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface--primary:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:0.12;opacity:var(--mdc-ripple-press-opacity, 0.12)}.mdc-ripple-surface--primary.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity, 0.12)}.mdc-ripple-surface--primary--activated::before{opacity:0.12;opacity:var(--mdc-ripple-activated-opacity, 0.12)}.mdc-ripple-surface--primary--activated::before,.mdc-ripple-surface--primary--activated::after{background-color:#6200ee;background-color:var(--mdc-ripple-color, var(--mdc-theme-primary, #6200ee))}.mdc-ripple-surface--primary--activated:hover::before,.mdc-ripple-surface--primary--activated.mdc-ripple-surface--hover::before{opacity:0.16;opacity:var(--mdc-ripple-hover-opacity, 0.16)}.mdc-ripple-surface--primary--activated.mdc-ripple-upgraded--background-focused::before,.mdc-ripple-surface--primary--activated:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:0.24;opacity:var(--mdc-ripple-focus-opacity, 0.24)}.mdc-ripple-surface--primary--activated:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface--primary--activated:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:0.24;opacity:var(--mdc-ripple-press-opacity, 0.24)}.mdc-ripple-surface--primary--activated.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity, 0.24)}.mdc-ripple-surface--primary--selected::before{opacity:0.08;opacity:var(--mdc-ripple-selected-opacity, 0.08)}.mdc-ripple-surface--primary--selected::before,.mdc-ripple-surface--primary--selected::after{background-color:#6200ee;background-color:var(--mdc-ripple-color, var(--mdc-theme-primary, #6200ee))}.mdc-ripple-surface--primary--selected:hover::before,.mdc-ripple-surface--primary--selected.mdc-ripple-surface--hover::before{opacity:0.12;opacity:var(--mdc-ripple-hover-opacity, 0.12)}.mdc-ripple-surface--primary--selected.mdc-ripple-upgraded--background-focused::before,.mdc-ripple-surface--primary--selected:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:0.2;opacity:var(--mdc-ripple-focus-opacity, 0.2)}.mdc-ripple-surface--primary--selected:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface--primary--selected:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:0.2;opacity:var(--mdc-ripple-press-opacity, 0.2)}.mdc-ripple-surface--primary--selected.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity, 0.2)}.mdc-ripple-surface--accent::before,.mdc-ripple-surface--accent::after{background-color:#018786;background-color:var(--mdc-ripple-color, var(--mdc-theme-secondary, #018786))}.mdc-ripple-surface--accent:hover::before,.mdc-ripple-surface--accent.mdc-ripple-surface--hover::before{opacity:0.04;opacity:var(--mdc-ripple-hover-opacity, 0.04)}.mdc-ripple-surface--accent.mdc-ripple-upgraded--background-focused::before,.mdc-ripple-surface--accent:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:0.12;opacity:var(--mdc-ripple-focus-opacity, 0.12)}.mdc-ripple-surface--accent:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface--accent:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:0.12;opacity:var(--mdc-ripple-press-opacity, 0.12)}.mdc-ripple-surface--accent.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity, 0.12)}.mdc-ripple-surface--accent--activated::before{opacity:0.12;opacity:var(--mdc-ripple-activated-opacity, 0.12)}.mdc-ripple-surface--accent--activated::before,.mdc-ripple-surface--accent--activated::after{background-color:#018786;background-color:var(--mdc-ripple-color, var(--mdc-theme-secondary, #018786))}.mdc-ripple-surface--accent--activated:hover::before,.mdc-ripple-surface--accent--activated.mdc-ripple-surface--hover::before{opacity:0.16;opacity:var(--mdc-ripple-hover-opacity, 0.16)}.mdc-ripple-surface--accent--activated.mdc-ripple-upgraded--background-focused::before,.mdc-ripple-surface--accent--activated:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:0.24;opacity:var(--mdc-ripple-focus-opacity, 0.24)}.mdc-ripple-surface--accent--activated:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface--accent--activated:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:0.24;opacity:var(--mdc-ripple-press-opacity, 0.24)}.mdc-ripple-surface--accent--activated.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity, 0.24)}.mdc-ripple-surface--accent--selected::before{opacity:0.08;opacity:var(--mdc-ripple-selected-opacity, 0.08)}.mdc-ripple-surface--accent--selected::before,.mdc-ripple-surface--accent--selected::after{background-color:#018786;background-color:var(--mdc-ripple-color, var(--mdc-theme-secondary, #018786))}.mdc-ripple-surface--accent--selected:hover::before,.mdc-ripple-surface--accent--selected.mdc-ripple-surface--hover::before{opacity:0.12;opacity:var(--mdc-ripple-hover-opacity, 0.12)}.mdc-ripple-surface--accent--selected.mdc-ripple-upgraded--background-focused::before,.mdc-ripple-surface--accent--selected:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:0.2;opacity:var(--mdc-ripple-focus-opacity, 0.2)}.mdc-ripple-surface--accent--selected:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface--accent--selected:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:0.2;opacity:var(--mdc-ripple-press-opacity, 0.2)}.mdc-ripple-surface--accent--selected.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity, 0.2)}.mdc-ripple-surface--disabled{opacity:0}.mdc-ripple-surface--internal-use-state-layer-custom-properties::before,.mdc-ripple-surface--internal-use-state-layer-custom-properties::after{background-color:#000;background-color:var(--mdc-ripple-hover-state-layer-color, #000)}.mdc-ripple-surface--internal-use-state-layer-custom-properties:hover::before,.mdc-ripple-surface--internal-use-state-layer-custom-properties.mdc-ripple-surface--hover::before{opacity:0.04;opacity:var(--mdc-ripple-hover-state-layer-opacity, 0.04)}.mdc-ripple-surface--internal-use-state-layer-custom-properties.mdc-ripple-upgraded--background-focused::before,.mdc-ripple-surface--internal-use-state-layer-custom-properties:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:0.12;opacity:var(--mdc-ripple-focus-state-layer-opacity, 0.12)}.mdc-ripple-surface--internal-use-state-layer-custom-properties:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface--internal-use-state-layer-custom-properties:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:0.12;opacity:var(--mdc-ripple-pressed-state-layer-opacity, 0.12)}.mdc-ripple-surface--internal-use-state-layer-custom-properties.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-pressed-state-layer-opacity, 0.12)}`;let Xs=class extends Ws{};Xs.styles=[Zs],Xs=ks([ge("mwc-ripple")],Xs);class Ks{constructor(e){this.startPress=t=>{e().then(e=>{e&&e.startPress(t)})},this.endPress=()=>{e().then(e=>{e&&e.endPress()})},this.startFocus=()=>{e().then(e=>{e&&e.startFocus()})},this.endFocus=()=>{e().then(e=>{e&&e.endFocus()})},this.startHover=()=>{e().then(e=>{e&&e.startHover()})},this.endHover=()=>{e().then(e=>{e&&e.endHover()})}}}class Qs extends me{constructor(){super(...arguments),this.raised=!1,this.unelevated=!1,this.outlined=!1,this.dense=!1,this.disabled=!1,this.trailingIcon=!1,this.fullwidth=!1,this.icon="",this.label="",this.expandContent=!1,this.shouldRenderRipple=!1,this.rippleHandlers=new Ks(()=>(this.shouldRenderRipple=!0,this.ripple))}renderOverlay(){return G``}renderRipple(){const e=this.raised||this.unelevated;return this.shouldRenderRipple?G`<mwc-ripple class="ripple" .primary="${!e}" .disabled="${this.disabled}"></mwc-ripple>`:""}focus(){const e=this.buttonElement;e&&(this.rippleHandlers.startFocus(),e.focus())}blur(){const e=this.buttonElement;e&&(this.rippleHandlers.endFocus(),e.blur())}getRenderClasses(){return Js({"mdc-button--raised":this.raised,"mdc-button--unelevated":this.unelevated,"mdc-button--outlined":this.outlined,"mdc-button--dense":this.dense})}render(){return G`
      <button
          id="button"
          class="mdc-button ${this.getRenderClasses()}"
          ?disabled="${this.disabled}"
          aria-label="${this.label||this.icon}"
          @focus="${this.handleRippleFocus}"
          @blur="${this.handleRippleBlur}"
          @mousedown="${this.handleRippleActivate}"
          @mouseenter="${this.handleRippleMouseEnter}"
          @mouseleave="${this.handleRippleMouseLeave}"
          @touchstart="${this.handleRippleActivate}"
          @touchend="${this.handleRippleDeactivate}"
          @touchcancel="${this.handleRippleDeactivate}">
        ${this.renderOverlay()}
        ${this.renderRipple()}
        <span class="leading-icon">
          <slot name="icon">
            ${this.icon&&!this.trailingIcon?this.renderIcon():""}
          </slot>
        </span>
        <span class="mdc-button__label">${this.label}</span>
        <span class="slot-container ${Js({flex:this.expandContent})}">
          <slot></slot>
        </span>
        <span class="trailing-icon">
          <slot name="trailingIcon">
            ${this.icon&&this.trailingIcon?this.renderIcon():""}
          </slot>
        </span>
      </button>`}renderIcon(){return G`
    <mwc-icon class="mdc-button__icon">
      ${this.icon}
    </mwc-icon>`}handleRippleActivate(e){const t=()=>{window.removeEventListener("mouseup",t),this.handleRippleDeactivate()};window.addEventListener("mouseup",t),this.rippleHandlers.startPress(e)}handleRippleDeactivate(){this.rippleHandlers.endPress()}handleRippleMouseEnter(){this.rippleHandlers.startHover()}handleRippleMouseLeave(){this.rippleHandlers.endHover()}handleRippleFocus(){this.rippleHandlers.startFocus()}handleRippleBlur(){this.rippleHandlers.endFocus()}}Qs.shadowRootOptions={mode:"open",delegatesFocus:!0},ks([_e({type:Boolean,reflect:!0})],Qs.prototype,"raised",void 0),ks([_e({type:Boolean,reflect:!0})],Qs.prototype,"unelevated",void 0),ks([_e({type:Boolean,reflect:!0})],Qs.prototype,"outlined",void 0),ks([_e({type:Boolean})],Qs.prototype,"dense",void 0),ks([_e({type:Boolean,reflect:!0})],Qs.prototype,"disabled",void 0),ks([_e({type:Boolean,attribute:"trailingicon"})],Qs.prototype,"trailingIcon",void 0),ks([_e({type:Boolean,reflect:!0})],Qs.prototype,"fullwidth",void 0),ks([_e({type:String})],Qs.prototype,"icon",void 0),ks([_e({type:String})],Qs.prototype,"label",void 0),ks([_e({type:Boolean})],Qs.prototype,"expandContent",void 0),ks([xe("#button")],Qs.prototype,"buttonElement",void 0),ks([ke("mwc-ripple")],Qs.prototype,"ripple",void 0),ks([be()],Qs.prototype,"shouldRenderRipple",void 0),ks([we({passive:!0})],Qs.prototype,"handleRippleActivate",null);const el=y`.mdc-touch-target-wrapper{display:inline}.mdc-elevation-overlay{position:absolute;border-radius:inherit;pointer-events:none;opacity:0;opacity:var(--mdc-elevation-overlay-opacity, 0);transition:opacity 280ms cubic-bezier(0.4, 0, 0.2, 1);background-color:#fff;background-color:var(--mdc-elevation-overlay-color, #fff)}.mdc-button{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto, sans-serif;font-family:var(--mdc-typography-button-font-family, var(--mdc-typography-font-family, Roboto, sans-serif));font-size:0.875rem;font-size:var(--mdc-typography-button-font-size, 0.875rem);line-height:2.25rem;line-height:var(--mdc-typography-button-line-height, 2.25rem);font-weight:500;font-weight:var(--mdc-typography-button-font-weight, 500);letter-spacing:0.0892857143em;letter-spacing:var(--mdc-typography-button-letter-spacing, 0.0892857143em);text-decoration:none;text-decoration:var(--mdc-typography-button-text-decoration, none);text-transform:uppercase;text-transform:var(--mdc-typography-button-text-transform, uppercase);position:relative;display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;min-width:64px;border:none;outline:none;line-height:inherit;user-select:none;-webkit-appearance:none;overflow:visible;vertical-align:middle;background:transparent}.mdc-button .mdc-elevation-overlay{width:100%;height:100%;top:0;left:0}.mdc-button::-moz-focus-inner{padding:0;border:0}.mdc-button:active{outline:none}.mdc-button:hover{cursor:pointer}.mdc-button:disabled{cursor:default;pointer-events:none}.mdc-button .mdc-button__icon{margin-left:0;margin-right:8px;display:inline-block;position:relative;font-size:1.125rem;height:1.125rem;vertical-align:top;width:1.125rem}[dir=rtl] .mdc-button .mdc-button__icon,.mdc-button .mdc-button__icon[dir=rtl]{margin-left:8px;margin-right:0}.mdc-button .mdc-button__touch{position:absolute;top:50%;height:48px;left:0;right:0;transform:translateY(-50%)}.mdc-button__label+.mdc-button__icon{margin-left:8px;margin-right:0}[dir=rtl] .mdc-button__label+.mdc-button__icon,.mdc-button__label+.mdc-button__icon[dir=rtl]{margin-left:0;margin-right:8px}svg.mdc-button__icon{fill:currentColor}.mdc-button--raised .mdc-button__icon,.mdc-button--unelevated .mdc-button__icon,.mdc-button--outlined .mdc-button__icon{margin-left:-4px;margin-right:8px}[dir=rtl] .mdc-button--raised .mdc-button__icon,[dir=rtl] .mdc-button--unelevated .mdc-button__icon,[dir=rtl] .mdc-button--outlined .mdc-button__icon,.mdc-button--raised .mdc-button__icon[dir=rtl],.mdc-button--unelevated .mdc-button__icon[dir=rtl],.mdc-button--outlined .mdc-button__icon[dir=rtl]{margin-left:8px;margin-right:-4px}.mdc-button--raised .mdc-button__label+.mdc-button__icon,.mdc-button--unelevated .mdc-button__label+.mdc-button__icon,.mdc-button--outlined .mdc-button__label+.mdc-button__icon{margin-left:8px;margin-right:-4px}[dir=rtl] .mdc-button--raised .mdc-button__label+.mdc-button__icon,[dir=rtl] .mdc-button--unelevated .mdc-button__label+.mdc-button__icon,[dir=rtl] .mdc-button--outlined .mdc-button__label+.mdc-button__icon,.mdc-button--raised .mdc-button__label+.mdc-button__icon[dir=rtl],.mdc-button--unelevated .mdc-button__label+.mdc-button__icon[dir=rtl],.mdc-button--outlined .mdc-button__label+.mdc-button__icon[dir=rtl]{margin-left:-4px;margin-right:8px}.mdc-button--touch{margin-top:6px;margin-bottom:6px}.mdc-button--raised{box-shadow:0px 3px 1px -2px rgba(0, 0, 0, 0.2),0px 2px 2px 0px rgba(0, 0, 0, 0.14),0px 1px 5px 0px rgba(0,0,0,.12);transition:box-shadow 280ms cubic-bezier(0.4, 0, 0.2, 1)}.mdc-button--raised:hover,.mdc-button--raised:focus{box-shadow:0px 2px 4px -1px rgba(0, 0, 0, 0.2),0px 4px 5px 0px rgba(0, 0, 0, 0.14),0px 1px 10px 0px rgba(0,0,0,.12)}.mdc-button--raised:active{box-shadow:0px 5px 5px -3px rgba(0, 0, 0, 0.2),0px 8px 10px 1px rgba(0, 0, 0, 0.14),0px 3px 14px 2px rgba(0,0,0,.12)}.mdc-button--raised:disabled{box-shadow:0px 0px 0px 0px rgba(0, 0, 0, 0.2),0px 0px 0px 0px rgba(0, 0, 0, 0.14),0px 0px 0px 0px rgba(0,0,0,.12)}.mdc-button--outlined{border-style:solid}.mdc-button{height:36px;border-radius:4px;border-radius:var(--mdc-shape-small, 4px);padding:0 8px 0 8px}.mdc-button:not(:disabled){color:#6200ee;color:var(--mdc-theme-primary, #6200ee)}.mdc-button:disabled{color:rgba(0, 0, 0, 0.38)}.mdc-button .mdc-button__ripple{border-radius:4px;border-radius:var(--mdc-shape-small, 4px)}.mdc-button--raised,.mdc-button--unelevated{padding:0 16px 0 16px;height:36px;border-radius:4px;border-radius:var(--mdc-shape-small, 4px)}.mdc-button--raised:not(:disabled),.mdc-button--unelevated:not(:disabled){background-color:#6200ee;background-color:var(--mdc-theme-primary, #6200ee)}.mdc-button--raised:disabled,.mdc-button--unelevated:disabled{background-color:rgba(0, 0, 0, 0.12)}.mdc-button--raised:not(:disabled),.mdc-button--unelevated:not(:disabled){color:#fff;color:var(--mdc-theme-on-primary, #fff)}.mdc-button--raised:disabled,.mdc-button--unelevated:disabled{color:rgba(0, 0, 0, 0.38)}.mdc-button--raised .mdc-button__ripple,.mdc-button--unelevated .mdc-button__ripple{border-radius:4px;border-radius:var(--mdc-shape-small, 4px)}.mdc-button--outlined{height:36px;border-radius:4px;border-radius:var(--mdc-shape-small, 4px);padding:0 15px 0 15px;border-width:1px}.mdc-button--outlined:not(:disabled){color:#6200ee;color:var(--mdc-theme-primary, #6200ee)}.mdc-button--outlined:disabled{color:rgba(0, 0, 0, 0.38)}.mdc-button--outlined .mdc-button__ripple{border-radius:4px;border-radius:var(--mdc-shape-small, 4px)}.mdc-button--outlined:not(:disabled){border-color:rgba(0, 0, 0, 0.12)}.mdc-button--outlined:disabled{border-color:rgba(0, 0, 0, 0.12)}.mdc-button--outlined.mdc-button--icon-trailing{padding:0 11px 0 15px}.mdc-button--outlined.mdc-button--icon-leading{padding:0 15px 0 11px}.mdc-button--outlined .mdc-button__ripple{top:-1px;left:-1px;border:1px solid transparent}.mdc-button--outlined .mdc-button__touch{left:-1px;width:calc(100% + 2 * 1px)}:host{display:inline-flex;outline:none;-webkit-tap-highlight-color:transparent;vertical-align:top}:host([fullwidth]){width:100%}:host([raised]),:host([unelevated]){--mdc-ripple-color:#fff;--mdc-ripple-focus-opacity:0.24;--mdc-ripple-hover-opacity:0.08;--mdc-ripple-press-opacity:0.24}.trailing-icon ::slotted(*),.trailing-icon .mdc-button__icon,.leading-icon ::slotted(*),.leading-icon .mdc-button__icon{margin-left:0;margin-right:8px;display:inline-block;position:relative;font-size:1.125rem;height:1.125rem;vertical-align:top;width:1.125rem}[dir=rtl] .trailing-icon ::slotted(*),[dir=rtl] .trailing-icon .mdc-button__icon,[dir=rtl] .leading-icon ::slotted(*),[dir=rtl] .leading-icon .mdc-button__icon,.trailing-icon ::slotted(*[dir=rtl]),.trailing-icon .mdc-button__icon[dir=rtl],.leading-icon ::slotted(*[dir=rtl]),.leading-icon .mdc-button__icon[dir=rtl]{margin-left:8px;margin-right:0}.trailing-icon ::slotted(*),.trailing-icon .mdc-button__icon{margin-left:8px;margin-right:0}[dir=rtl] .trailing-icon ::slotted(*),[dir=rtl] .trailing-icon .mdc-button__icon,.trailing-icon ::slotted(*[dir=rtl]),.trailing-icon .mdc-button__icon[dir=rtl]{margin-left:0;margin-right:8px}.slot-container{display:inline-flex;align-items:center;justify-content:center}.slot-container.flex{flex:auto}.mdc-button{flex:auto;overflow:hidden;padding-left:8px;padding-left:var(--mdc-button-horizontal-padding, 8px);padding-right:8px;padding-right:var(--mdc-button-horizontal-padding, 8px)}.mdc-button--raised{box-shadow:0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);box-shadow:var(--mdc-button-raised-box-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12))}.mdc-button--raised:focus{box-shadow:0px 2px 4px -1px rgba(0, 0, 0, 0.2), 0px 4px 5px 0px rgba(0, 0, 0, 0.14), 0px 1px 10px 0px rgba(0, 0, 0, 0.12);box-shadow:var(--mdc-button-raised-box-shadow-focus, var(--mdc-button-raised-box-shadow-hover, 0px 2px 4px -1px rgba(0, 0, 0, 0.2), 0px 4px 5px 0px rgba(0, 0, 0, 0.14), 0px 1px 10px 0px rgba(0, 0, 0, 0.12)))}.mdc-button--raised:hover{box-shadow:0px 2px 4px -1px rgba(0, 0, 0, 0.2), 0px 4px 5px 0px rgba(0, 0, 0, 0.14), 0px 1px 10px 0px rgba(0, 0, 0, 0.12);box-shadow:var(--mdc-button-raised-box-shadow-hover, 0px 2px 4px -1px rgba(0, 0, 0, 0.2), 0px 4px 5px 0px rgba(0, 0, 0, 0.14), 0px 1px 10px 0px rgba(0, 0, 0, 0.12))}.mdc-button--raised:active{box-shadow:0px 5px 5px -3px rgba(0, 0, 0, 0.2), 0px 8px 10px 1px rgba(0, 0, 0, 0.14), 0px 3px 14px 2px rgba(0, 0, 0, 0.12);box-shadow:var(--mdc-button-raised-box-shadow-active, 0px 5px 5px -3px rgba(0, 0, 0, 0.2), 0px 8px 10px 1px rgba(0, 0, 0, 0.14), 0px 3px 14px 2px rgba(0, 0, 0, 0.12))}.mdc-button--raised:disabled{box-shadow:0px 0px 0px 0px rgba(0, 0, 0, 0.2), 0px 0px 0px 0px rgba(0, 0, 0, 0.14), 0px 0px 0px 0px rgba(0, 0, 0, 0.12);box-shadow:var(--mdc-button-raised-box-shadow-disabled, 0px 0px 0px 0px rgba(0, 0, 0, 0.2), 0px 0px 0px 0px rgba(0, 0, 0, 0.14), 0px 0px 0px 0px rgba(0, 0, 0, 0.12))}.mdc-button--raised,.mdc-button--unelevated{padding-left:16px;padding-left:var(--mdc-button-horizontal-padding, 16px);padding-right:16px;padding-right:var(--mdc-button-horizontal-padding, 16px)}.mdc-button--outlined{border-width:1px;border-width:var(--mdc-button-outline-width, 1px);padding-left:calc(16px - 1px);padding-left:calc(var(--mdc-button-horizontal-padding, 16px) - var(--mdc-button-outline-width, 1px));padding-right:calc(16px - 1px);padding-right:calc(var(--mdc-button-horizontal-padding, 16px) - var(--mdc-button-outline-width, 1px))}.mdc-button--outlined:not(:disabled){border-color:rgba(0, 0, 0, 0.12);border-color:var(--mdc-button-outline-color, rgba(0, 0, 0, 0.12))}.mdc-button--outlined .ripple{top:calc(-1 * 1px);top:calc(-1 * var(--mdc-button-outline-width, 1px));left:calc(-1 * 1px);left:calc(-1 * var(--mdc-button-outline-width, 1px));right:initial;right:initial;border-width:1px;border-width:var(--mdc-button-outline-width, 1px);border-style:solid;border-color:transparent}[dir=rtl] .mdc-button--outlined .ripple,.mdc-button--outlined .ripple[dir=rtl]{left:initial;left:initial;right:calc(-1 * 1px);right:calc(-1 * var(--mdc-button-outline-width, 1px))}.mdc-button--dense{height:28px;margin-top:0;margin-bottom:0}.mdc-button--dense .mdc-button__touch{display:none}:host([disabled]){pointer-events:none}:host([disabled]) .mdc-button{color:rgba(0, 0, 0, 0.38);color:var(--mdc-button-disabled-ink-color, rgba(0, 0, 0, 0.38))}:host([disabled]) .mdc-button--raised,:host([disabled]) .mdc-button--unelevated{background-color:rgba(0, 0, 0, 0.12);background-color:var(--mdc-button-disabled-fill-color, rgba(0, 0, 0, 0.12))}:host([disabled]) .mdc-button--outlined{border-color:rgba(0, 0, 0, 0.12);border-color:var(--mdc-button-disabled-outline-color, rgba(0, 0, 0, 0.12))}`;let tl=class extends Qs{};function rl(e,t,r){if(void 0!==t)return function(e,t,r){const i=e.constructor;if(!r){const e="__"+t;if(!(r=i.getPropertyDescriptor(t,e)))throw new Error("@ariaProperty must be used after a @property decorator")}const o=r;let n="";if(!o.set)throw new Error("@ariaProperty requires a setter for "+t);const a={configurable:!0,enumerable:!0,set(e){if(""===n){const e=i.getPropertyOptions(t);n=e.attribute}this.hasAttribute(n)&&this.removeAttribute(n),o.set.call(this,e)}};return o.get&&(a.get=function(){return o.get.call(this)}),a}(e,t,r);throw new Error("@ariaProperty only supports TypeScript Decorators")}tl.styles=[el],tl=ks([ge("mwc-button")],tl);class il extends me{constructor(){super(...arguments),this.disabled=!1,this.icon="",this.shouldRenderRipple=!1,this.rippleHandlers=new Ks(()=>(this.shouldRenderRipple=!0,this.ripple))}renderRipple(){return this.shouldRenderRipple?G`
            <mwc-ripple
                .disabled="${this.disabled}"
                unbounded>
            </mwc-ripple>`:""}focus(){const e=this.buttonElement;e&&(this.rippleHandlers.startFocus(),e.focus())}blur(){const e=this.buttonElement;e&&(this.rippleHandlers.endFocus(),e.blur())}render(){return G`<button
        class="mdc-icon-button"
        aria-label="${this.ariaLabel||this.icon}"
        ?disabled="${this.disabled}"
        @focus="${this.handleRippleFocus}"
        @blur="${this.handleRippleBlur}"
        @mousedown="${this.handleRippleMouseDown}"
        @mouseenter="${this.handleRippleMouseEnter}"
        @mouseleave="${this.handleRippleMouseLeave}"
        @touchstart="${this.handleRippleTouchStart}"
        @touchend="${this.handleRippleDeactivate}"
        @touchcancel="${this.handleRippleDeactivate}"
    >${this.renderRipple()}
    <i class="material-icons">${this.icon}</i>
    <span
      ><slot></slot
    ></span>
  </button>`}handleRippleMouseDown(e){const t=()=>{window.removeEventListener("mouseup",t),this.handleRippleDeactivate()};window.addEventListener("mouseup",t),this.rippleHandlers.startPress(e)}handleRippleTouchStart(e){this.rippleHandlers.startPress(e)}handleRippleDeactivate(){this.rippleHandlers.endPress()}handleRippleMouseEnter(){this.rippleHandlers.startHover()}handleRippleMouseLeave(){this.rippleHandlers.endHover()}handleRippleFocus(){this.rippleHandlers.startFocus()}handleRippleBlur(){this.rippleHandlers.endFocus()}}ks([_e({type:Boolean,reflect:!0})],il.prototype,"disabled",void 0),ks([_e({type:String})],il.prototype,"icon",void 0),ks([rl,_e({type:String,attribute:"aria-label"})],il.prototype,"ariaLabel",void 0),ks([xe("button")],il.prototype,"buttonElement",void 0),ks([ke("mwc-ripple")],il.prototype,"ripple",void 0),ks([be()],il.prototype,"shouldRenderRipple",void 0),ks([we({passive:!0})],il.prototype,"handleRippleMouseDown",null),ks([we({passive:!0})],il.prototype,"handleRippleTouchStart",null);const ol=y`.material-icons{font-family:var(--mdc-icon-font, "Material Icons");font-weight:normal;font-style:normal;font-size:var(--mdc-icon-size, 24px);line-height:1;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;-moz-osx-font-smoothing:grayscale;font-feature-settings:"liga"}.mdc-icon-button{display:inline-block;position:relative;box-sizing:border-box;border:none;outline:none;background-color:transparent;fill:currentColor;color:inherit;font-size:24px;text-decoration:none;cursor:pointer;user-select:none;width:48px;height:48px;padding:12px}.mdc-icon-button svg,.mdc-icon-button img{width:24px;height:24px}.mdc-icon-button:disabled{color:rgba(0, 0, 0, 0.38);color:var(--mdc-theme-text-disabled-on-light, rgba(0, 0, 0, 0.38))}.mdc-icon-button:disabled{cursor:default;pointer-events:none}.mdc-icon-button .mdc-icon-button__touch{position:absolute;top:50%;height:48px;left:50%;width:48px;transform:translate(-50%, -50%)}.mdc-icon-button__icon{display:inline-block}.mdc-icon-button__icon.mdc-icon-button__icon--on{display:none}.mdc-icon-button--on .mdc-icon-button__icon{display:none}.mdc-icon-button--on .mdc-icon-button__icon.mdc-icon-button__icon--on{display:inline-block}.mdc-icon-button--touch{margin-top:0px;margin-bottom:0px}:host{display:inline-block;outline:none;--mdc-ripple-color: currentcolor;-webkit-tap-highlight-color:transparent}:host([disabled]){pointer-events:none}:host,.mdc-icon-button{vertical-align:top}.mdc-icon-button{width:var(--mdc-icon-button-size, 48px);height:var(--mdc-icon-button-size, 48px);padding:calc( (var(--mdc-icon-button-size, 48px) - var(--mdc-icon-size, 24px)) / 2 )}.mdc-icon-button>i{position:absolute;top:0;padding-top:inherit}.mdc-icon-button i,.mdc-icon-button svg,.mdc-icon-button img,.mdc-icon-button ::slotted(*){display:block;width:var(--mdc-icon-size, 24px);height:var(--mdc-icon-size, 24px)}`;let nl=class extends il{};nl.styles=[ol],nl=ks([ge("mwc-icon-button")],nl);let al=a([ge("ha-svg-icon")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_e()],key:"path",value:void 0},{kind:"field",decorators:[_e()],key:"viewBox",value:void 0},{kind:"method",key:"render",value:function(){return W`
    <svg
      viewBox=${this.viewBox||"0 0 24 24"}
      preserveAspectRatio="xMidYMid meet"
      focusable="false">
      <g>
      ${this.path?W`<path d=${this.path}></path>`:""}
      </g>
    </svg>`}},{kind:"get",static:!0,key:"styles",value:function(){return y`
      :host {
        display: var(--ha-icon-display, inline-flex);
        align-items: center;
        justify-content: center;
        position: relative;
        vertical-align: middle;
        fill: currentcolor;
        width: var(--mdc-icon-size, 24px);
        height: var(--mdc-icon-size, 24px);
      }
      svg {
        width: 100%;
        height: 100%;
        pointer-events: none;
        display: block;
      }
    `}}]}}),me);a([ge("ha-icon-button-arrow-prev")],(function(e,i){class o extends i{constructor(...t){super(...t),e(this)}}return{F:o,d:[{kind:"field",decorators:[_e({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_e({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_e()],key:"label",value:void 0},{kind:"field",decorators:[be()],key:"_icon",value:()=>Ya},{kind:"method",key:"connectedCallback",value:function(){r(t(o.prototype),"connectedCallback",this).call(this),setTimeout(()=>{this._icon="ltr"===window.getComputedStyle(this).direction?Ya:Ja},100)}},{kind:"method",key:"render",value:function(){var e;return G`
      <mwc-icon-button
        .disabled=${this.disabled}
        .label=${this.label||(null===(e=this.hass)||void 0===e?void 0:e.localize("ui.common.back"))||"Back"}
      >
        <ha-svg-icon .path=${this._icon}></ha-svg-icon>
      </mwc-icon-button>
    `}}]}}),me);const sl=e=>{let t=[];function r(r,i){e=i?r:Object.assign(Object.assign({},e),r);let o=t;for(let t=0;t<o.length;t++)o[t](e)}return{get state(){return e},action(t){function i(e){r(e,!1)}return function(){let r=[e];for(let e=0;e<arguments.length;e++)r.push(arguments[e]);let o=t.apply(this,r);if(null!=o)return o instanceof Promise?o.then(i):i(o)}},setState:r,subscribe:e=>(t.push(e),()=>{!function(e){let r=[];for(let i=0;i<t.length;i++)t[i]===e?e=null:r.push(t[i]);t=r}(e)})}},ll=(e,t,r,i,o)=>((e,t,r,i)=>{if(e[t])return e[t];let o,n=0,a=sl();const s=()=>r(e).then(e=>a.setState(e,!0)),l=()=>s().catch(t=>{if(e.connected)throw t});return e[t]={get state(){return a.state},refresh:s,subscribe(t){n++,1===n&&(i&&(o=i(e,a)),e.addEventListener("ready",l),l());const r=a.subscribe(t);return void 0!==a.state&&setTimeout(()=>t(a.state),0),()=>{r(),n--,n||(o&&o.then(e=>{e()}),e.removeEventListener("ready",s))}}},e[t]})(i,e,t,r).subscribe(o),cl=e=>e.sendMessagePromise({type:"persistent_notification/get"}),dl=(e,t)=>e.subscribeEvents(()=>cl(e).then(e=>t.setState(e,!0)),"persistent_notifications_updated");a([ge("ha-menu-button")],(function(e,i){class o extends i{constructor(...t){super(...t),e(this)}}return{F:o,d:[{kind:"field",decorators:[_e({type:Boolean})],key:"hassio",value:()=>!1},{kind:"field",decorators:[_e()],key:"narrow",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[be()],key:"_hasNotifications",value:()=>!1},{kind:"field",key:"_alwaysVisible",value:()=>!1},{kind:"field",key:"_attachNotifOnConnect",value:()=>!1},{kind:"field",key:"_unsubNotifications",value:void 0},{kind:"method",key:"connectedCallback",value:function(){r(t(o.prototype),"connectedCallback",this).call(this),this._attachNotifOnConnect&&(this._attachNotifOnConnect=!1,this._subscribeNotifications())}},{kind:"method",key:"disconnectedCallback",value:function(){r(t(o.prototype),"disconnectedCallback",this).call(this),this._unsubNotifications&&(this._attachNotifOnConnect=!0,this._unsubNotifications(),this._unsubNotifications=void 0)}},{kind:"method",key:"render",value:function(){const e=(this.narrow||"always_hidden"===this.hass.dockedSidebar)&&(this._hasNotifications||Object.keys(this.hass.states).some(e=>"configurator"===(e=>e.substr(0,e.indexOf(".")))(e)));return G`
      <mwc-icon-button
        aria-label=${this.hass.localize("ui.sidebar.sidebar_toggle")}
        @click=${this._toggleMenu}
      >
        <ha-svg-icon .path=${"M3,6H21V8H3V6M3,11H21V13H3V11M3,16H21V18H3V16Z"}></ha-svg-icon>
      </mwc-icon-button>
      ${e?G` <div class="dot"></div> `:""}
    `}},{kind:"method",key:"firstUpdated",value:function(e){r(t(o.prototype),"firstUpdated",this).call(this,e),this.hassio&&(this._alwaysVisible=(Number(window.parent.frontendVersion)||0)<20190710)}},{kind:"method",key:"updated",value:function(e){if(r(t(o.prototype),"updated",this).call(this,e),!e.has("narrow")&&!e.has("hass"))return;const i=e.get("hass"),n=e.get("narrow")||i&&"always_hidden"===i.dockedSidebar,a=this.narrow||"always_hidden"===this.hass.dockedSidebar;n!==a&&(this.style.display=a||this._alwaysVisible?"initial":"none",a?this._subscribeNotifications():this._unsubNotifications&&(this._unsubNotifications(),this._unsubNotifications=void 0))}},{kind:"method",key:"_subscribeNotifications",value:function(){var e;this._unsubNotifications=(e=this.hass.connection,ll("_ntf",cl,dl,e,e=>{this._hasNotifications=e.length>0}))}},{kind:"method",key:"_toggleMenu",value:function(){Je(this,"hass-toggle-menu")}},{kind:"get",static:!0,key:"styles",value:function(){return y`
      :host {
        position: relative;
      }
      .dot {
        pointer-events: none;
        position: absolute;
        background-color: var(--accent-color);
        width: 12px;
        height: 12px;
        top: 9px;
        right: 7px;
        border-radius: 50%;
        border: 2px solid var(--app-header-background-color);
      }
    `}}]}}),me),a([ge("hass-error-screen")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_e({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_e({type:Boolean})],key:"toolbar",value:()=>!0},{kind:"field",decorators:[_e({type:Boolean})],key:"rootnav",value:()=>!1},{kind:"field",decorators:[_e({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[_e()],key:"error",value:void 0},{kind:"method",key:"render",value:function(){var e,t;return G`
      ${this.toolbar?G`<div class="toolbar">
            ${this.rootnav||null!==(e=history.state)&&void 0!==e&&e.root?G`
                  <ha-menu-button
                    .hass=${this.hass}
                    .narrow=${this.narrow}
                  ></ha-menu-button>
                `:G`
                  <ha-icon-button-arrow-prev
                    .hass=${this.hass}
                    @click=${this._handleBack}
                  ></ha-icon-button-arrow-prev>
                `}
          </div>`:""}
      <div class="content">
        <h3>${this.error}</h3>
        <slot>
          <mwc-button @click=${this._handleBack}>
            ${(null===(t=this.hass)||void 0===t?void 0:t.localize("ui.panel.error.go_back"))||"go back"}
          </mwc-button>
        </slot>
      </div>
    `}},{kind:"method",key:"_handleBack",value:function(){history.back()}},{kind:"get",static:!0,key:"styles",value:function(){return[y`
        :host {
          display: block;
          height: 100%;
          background-color: var(--primary-background-color);
        }
        .toolbar {
          display: flex;
          align-items: center;
          font-size: 20px;
          height: var(--header-height);
          padding: 0 16px;
          pointer-events: none;
          background-color: var(--app-header-background-color);
          font-weight: 400;
          color: var(--app-header-text-color, white);
          border-bottom: var(--app-header-border-bottom, none);
          box-sizing: border-box;
        }
        ha-icon-button-arrow-prev {
          pointer-events: auto;
        }
        .content {
          color: var(--primary-text-color);
          height: calc(100% - var(--header-height));
          display: flex;
          padding: 16px;
          align-items: center;
          justify-content: center;
          flex-direction: column;
        }
        a {
          color: var(--primary-color);
        }
      `]}}]}}),me),Tn({_template:Qn`
    <style>

      :host {
        @apply --layout-horizontal;
        @apply --layout-center;
        position: relative;
        height: 64px;
        padding: 0 16px;
        pointer-events: none;
        font-size: var(--app-toolbar-font-size, 20px);
      }

      :host ::slotted(*) {
        pointer-events: auto;
      }

      :host ::slotted(paper-icon-button) {
        /* paper-icon-button/issues/33 */
        font-size: 0;
      }

      :host ::slotted([main-title]),
      :host ::slotted([condensed-title]) {
        pointer-events: none;
        @apply --layout-flex;
      }

      :host ::slotted([bottom-item]) {
        position: absolute;
        right: 0;
        bottom: 0;
        left: 0;
      }

      :host ::slotted([top-item]) {
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
      }

      :host ::slotted([spacer]) {
        margin-left: 64px;
      }
    </style>

    <slot></slot>
`,is:"app-toolbar"});const pl=e=>null!=e?e:X;class hl extends me{constructor(){super(...arguments),this.indeterminate=!1,this.progress=0,this.density=0,this.closed=!1}open(){this.closed=!1}close(){this.closed=!0}render(){const e={"mdc-circular-progress--closed":this.closed,"mdc-circular-progress--indeterminate":this.indeterminate},t=48+4*this.density,r={width:t+"px",height:t+"px"};return G`
      <div
        class="mdc-circular-progress ${Js(e)}"
        style="${Gs(r)}"
        role="progressbar"
        aria-label="${pl(this.ariaLabel)}"
        aria-valuemin="0"
        aria-valuemax="1"
        aria-valuenow="${pl(this.indeterminate?void 0:this.progress)}">
        ${this.renderDeterminateContainer()}
        ${this.renderIndeterminateContainer()}
      </div>`}renderDeterminateContainer(){const e=48+4*this.density,t=e/2,r=this.density>=-3?18+11*this.density/6:12.5+5*(this.density+3)/4,i=6.2831852*r,o=(1-this.progress)*i,n=this.density>=-3?4+this.density*(1/3):3+(this.density+3)*(1/6);return G`
      <div class="mdc-circular-progress__determinate-container">
        <svg class="mdc-circular-progress__determinate-circle-graphic"
             viewBox="0 0 ${e} ${e}">
          <circle class="mdc-circular-progress__determinate-track"
                  cx="${t}" cy="${t}" r="${r}"
                  stroke-width="${n}"></circle>
          <circle class="mdc-circular-progress__determinate-circle"
                  cx="${t}" cy="${t}" r="${r}"
                  stroke-dasharray="${6.2831852*r}"
                  stroke-dashoffset="${o}"
                  stroke-width="${n}"></circle>
        </svg>
      </div>`}renderIndeterminateContainer(){return G`
      <div class="mdc-circular-progress__indeterminate-container">
        <div class="mdc-circular-progress__spinner-layer">
          ${this.renderIndeterminateSpinnerLayer()}
        </div>
      </div>`}renderIndeterminateSpinnerLayer(){const e=48+4*this.density,t=e/2,r=this.density>=-3?18+11*this.density/6:12.5+5*(this.density+3)/4,i=6.2831852*r,o=.5*i,n=this.density>=-3?4+this.density*(1/3):3+(this.density+3)*(1/6);return G`
        <div class="mdc-circular-progress__circle-clipper mdc-circular-progress__circle-left">
          <svg class="mdc-circular-progress__indeterminate-circle-graphic"
               viewBox="0 0 ${e} ${e}">
            <circle cx="${t}" cy="${t}" r="${r}"
                    stroke-dasharray="${i}"
                    stroke-dashoffset="${o}"
                    stroke-width="${n}"></circle>
          </svg>
        </div>
        <div class="mdc-circular-progress__gap-patch">
          <svg class="mdc-circular-progress__indeterminate-circle-graphic"
               viewBox="0 0 ${e} ${e}">
            <circle cx="${t}" cy="${t}" r="${r}"
                    stroke-dasharray="${i}"
                    stroke-dashoffset="${o}"
                    stroke-width="${.8*n}"></circle>
          </svg>
        </div>
        <div class="mdc-circular-progress__circle-clipper mdc-circular-progress__circle-right">
          <svg class="mdc-circular-progress__indeterminate-circle-graphic"
               viewBox="0 0 ${e} ${e}">
            <circle cx="${t}" cy="${t}" r="${r}"
                    stroke-dasharray="${i}"
                    stroke-dashoffset="${o}"
                    stroke-width="${n}"></circle>
          </svg>
        </div>`}update(e){super.update(e),e.has("progress")&&(this.progress>1&&(this.progress=1),this.progress<0&&(this.progress=0))}}ks([_e({type:Boolean,reflect:!0})],hl.prototype,"indeterminate",void 0),ks([_e({type:Number,reflect:!0})],hl.prototype,"progress",void 0),ks([_e({type:Number,reflect:!0})],hl.prototype,"density",void 0),ks([_e({type:Boolean,reflect:!0})],hl.prototype,"closed",void 0),ks([rl,_e({type:String,attribute:"aria-label"})],hl.prototype,"ariaLabel",void 0);const ul=y`.mdc-circular-progress__determinate-circle,.mdc-circular-progress__indeterminate-circle-graphic{stroke:#6200ee;stroke:var(--mdc-theme-primary, #6200ee)}.mdc-circular-progress__determinate-track{stroke:transparent}@keyframes mdc-circular-progress-container-rotate{to{transform:rotate(360deg)}}@keyframes mdc-circular-progress-spinner-layer-rotate{12.5%{transform:rotate(135deg)}25%{transform:rotate(270deg)}37.5%{transform:rotate(405deg)}50%{transform:rotate(540deg)}62.5%{transform:rotate(675deg)}75%{transform:rotate(810deg)}87.5%{transform:rotate(945deg)}100%{transform:rotate(1080deg)}}@keyframes mdc-circular-progress-color-1-fade-in-out{from{opacity:.99}25%{opacity:.99}26%{opacity:0}89%{opacity:0}90%{opacity:.99}to{opacity:.99}}@keyframes mdc-circular-progress-color-2-fade-in-out{from{opacity:0}15%{opacity:0}25%{opacity:.99}50%{opacity:.99}51%{opacity:0}to{opacity:0}}@keyframes mdc-circular-progress-color-3-fade-in-out{from{opacity:0}40%{opacity:0}50%{opacity:.99}75%{opacity:.99}76%{opacity:0}to{opacity:0}}@keyframes mdc-circular-progress-color-4-fade-in-out{from{opacity:0}65%{opacity:0}75%{opacity:.99}90%{opacity:.99}to{opacity:0}}@keyframes mdc-circular-progress-left-spin{from{transform:rotate(265deg)}50%{transform:rotate(130deg)}to{transform:rotate(265deg)}}@keyframes mdc-circular-progress-right-spin{from{transform:rotate(-265deg)}50%{transform:rotate(-130deg)}to{transform:rotate(-265deg)}}.mdc-circular-progress{display:inline-flex;position:relative;direction:ltr;line-height:0;transition:opacity 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1)}.mdc-circular-progress__determinate-container,.mdc-circular-progress__indeterminate-circle-graphic,.mdc-circular-progress__indeterminate-container,.mdc-circular-progress__spinner-layer{position:absolute;width:100%;height:100%}.mdc-circular-progress__determinate-container{transform:rotate(-90deg)}.mdc-circular-progress__indeterminate-container{font-size:0;letter-spacing:0;white-space:nowrap;opacity:0}.mdc-circular-progress__determinate-circle-graphic,.mdc-circular-progress__indeterminate-circle-graphic{fill:transparent}.mdc-circular-progress__determinate-circle{transition:stroke-dashoffset 500ms 0ms cubic-bezier(0, 0, 0.2, 1)}.mdc-circular-progress__gap-patch{position:absolute;top:0;left:47.5%;box-sizing:border-box;width:5%;height:100%;overflow:hidden}.mdc-circular-progress__gap-patch .mdc-circular-progress__indeterminate-circle-graphic{left:-900%;width:2000%;transform:rotate(180deg)}.mdc-circular-progress__circle-clipper{display:inline-flex;position:relative;width:50%;height:100%;overflow:hidden}.mdc-circular-progress__circle-clipper .mdc-circular-progress__indeterminate-circle-graphic{width:200%}.mdc-circular-progress__circle-right .mdc-circular-progress__indeterminate-circle-graphic{left:-100%}.mdc-circular-progress--indeterminate .mdc-circular-progress__determinate-container{opacity:0}.mdc-circular-progress--indeterminate .mdc-circular-progress__indeterminate-container{opacity:1}.mdc-circular-progress--indeterminate .mdc-circular-progress__indeterminate-container{animation:mdc-circular-progress-container-rotate 1568.2352941176ms linear infinite}.mdc-circular-progress--indeterminate .mdc-circular-progress__spinner-layer{animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(0.4, 0, 0.2, 1) infinite both}.mdc-circular-progress--indeterminate .mdc-circular-progress__color-1{animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(0.4, 0, 0.2, 1) infinite both,mdc-circular-progress-color-1-fade-in-out 5332ms cubic-bezier(0.4, 0, 0.2, 1) infinite both}.mdc-circular-progress--indeterminate .mdc-circular-progress__color-2{animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(0.4, 0, 0.2, 1) infinite both,mdc-circular-progress-color-2-fade-in-out 5332ms cubic-bezier(0.4, 0, 0.2, 1) infinite both}.mdc-circular-progress--indeterminate .mdc-circular-progress__color-3{animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(0.4, 0, 0.2, 1) infinite both,mdc-circular-progress-color-3-fade-in-out 5332ms cubic-bezier(0.4, 0, 0.2, 1) infinite both}.mdc-circular-progress--indeterminate .mdc-circular-progress__color-4{animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(0.4, 0, 0.2, 1) infinite both,mdc-circular-progress-color-4-fade-in-out 5332ms cubic-bezier(0.4, 0, 0.2, 1) infinite both}.mdc-circular-progress--indeterminate .mdc-circular-progress__circle-left .mdc-circular-progress__indeterminate-circle-graphic{animation:mdc-circular-progress-left-spin 1333ms cubic-bezier(0.4, 0, 0.2, 1) infinite both}.mdc-circular-progress--indeterminate .mdc-circular-progress__circle-right .mdc-circular-progress__indeterminate-circle-graphic{animation:mdc-circular-progress-right-spin 1333ms cubic-bezier(0.4, 0, 0.2, 1) infinite both}.mdc-circular-progress--closed{opacity:0}:host{display:inline-flex}.mdc-circular-progress__determinate-track{stroke:transparent;stroke:var(--mdc-circular-progress-track-color, transparent)}`;let fl=class extends hl{};fl.styles=[ul],fl=ks([ge("mwc-circular-progress")],fl),a([ge("ha-circular-progress")],(function(e,i){class o extends i{constructor(...t){super(...t),e(this)}}return{F:o,d:[{kind:"field",decorators:[_e({type:Boolean})],key:"active",value:()=>!1},{kind:"field",decorators:[_e()],key:"alt",value:()=>"Loading"},{kind:"field",decorators:[_e()],key:"size",value:()=>"medium"},{kind:"set",key:"density",value:function(e){}},{kind:"get",key:"density",value:function(){switch(this.size){case"tiny":return-8;case"small":return-5;case"medium":return 0;case"large":return 5;default:return 0}}},{kind:"set",key:"indeterminate",value:function(e){}},{kind:"get",key:"indeterminate",value:function(){return this.active}},{kind:"get",static:!0,key:"styles",value:function(){return[r(t(o),"styles",this),y`
        :host {
          overflow: hidden;
        }
      `]}}]}}),fl),a([ge("hass-loading-screen")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_e({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_e({type:Boolean,attribute:"no-toolbar"})],key:"noToolbar",value:()=>!1},{kind:"field",decorators:[_e({type:Boolean})],key:"rootnav",value:()=>!1},{kind:"field",decorators:[_e({type:Boolean})],key:"narrow",value:()=>!1},{kind:"method",key:"render",value:function(){var e;return G`
      ${this.noToolbar?"":G`<div class="toolbar">
            ${this.rootnav||null!==(e=history.state)&&void 0!==e&&e.root?G`
                  <ha-menu-button
                    .hass=${this.hass}
                    .narrow=${this.narrow}
                  ></ha-menu-button>
                `:G`
                  <ha-icon-button-arrow-prev
                    .hass=${this.hass}
                    @click=${this._handleBack}
                  ></ha-icon-button-arrow-prev>
                `}
          </div>`}
      <div class="content">
        <ha-circular-progress active></ha-circular-progress>
      </div>
    `}},{kind:"method",key:"_handleBack",value:function(){history.back()}},{kind:"get",static:!0,key:"styles",value:function(){return[Ae,y`
        :host {
          display: block;
          height: 100%;
          background-color: var(--primary-background-color);
        }
        .toolbar {
          display: flex;
          align-items: center;
          font-size: 20px;
          height: var(--header-height);
          padding: 0 16px;
          pointer-events: none;
          background-color: var(--app-header-background-color);
          font-weight: 400;
          color: var(--app-header-text-color, white);
          border-bottom: var(--app-header-border-bottom, none);
          box-sizing: border-box;
        }
        ha-menu-button,
        ha-icon-button-arrow-prev {
          pointer-events: auto;
        }
        .content {
          height: calc(100% - var(--header-height));
          display: flex;
          align-items: center;
          justify-content: center;
        }
      `]}}]}}),me);let ml=a(null,(function(e,i){class o extends i{constructor(...t){super(...t),e(this)}}return{F:o,d:[{kind:"field",decorators:[_e()],key:"route",value:void 0},{kind:"field",key:"routerOptions",value:void 0},{kind:"field",key:"_currentPage",value:()=>""},{kind:"field",key:"_currentLoadProm",value:void 0},{kind:"field",key:"_cache",value:()=>({})},{kind:"field",key:"_initialLoadDone",value:()=>!1},{kind:"field",key:"_computeTail",value:()=>Ba(e=>{const t=e.path.indexOf("/",1);return-1===t?{prefix:e.prefix+e.path,path:""}:{prefix:e.prefix+e.path.substr(0,t),path:e.path.substr(t)}})},{kind:"method",key:"createRenderRoot",value:function(){return this}},{kind:"method",key:"update",value:function(e){r(t(o.prototype),"update",this).call(this,e);const i=this.routerOptions||{routes:{}};if(i&&i.initialLoad&&!this._initialLoadDone)return;if(!e.has("route"))return void(this.lastChild&&!this._currentLoadProm&&this.updatePageEl(this.lastChild,e));const n=this.route,a=i.defaultPage;n&&""===n.path&&void 0!==a&&We(`${n.prefix}/${a}`,{replace:!0});let s=n?((e,t)=>{if(""===e)return t;const r=e.indexOf("/",1);return-1===r?e.substr(1):e.substr(1,r-1)})(n.path,a||""):"not_found",l=i.routes[s];for(;"string"==typeof l;)s=l,l=i.routes[s];if(i.beforeRender){const e=i.beforeRender(s);if(void 0!==e){for(s=e,l=i.routes[s];"string"==typeof l;)s=l,l=i.routes[s];n&&We(`${n.prefix}/${e}`,{replace:!0})}}if(this._currentPage===s)return void(this.lastChild&&this.updatePageEl(this.lastChild,e));if(!l)return this._currentPage="",void(this.lastChild&&this.removeChild(this.lastChild));this._currentPage=s;const c=l.load?l.load():Promise.resolve();let d;if(c.catch(e=>{console.error("Error loading page",s,e),this._currentPage===s&&(this.lastChild&&this.removeChild(this.lastChild),d&&clearTimeout(d),this.appendChild(this.createErrorScreen(`Error while loading page ${s}.`)))}),!i.showLoading)return void this._createPanel(i,s,l);let p=!1;d=window.setTimeout(()=>{p||this._currentPage!==s||(this.lastChild&&this.removeChild(this.lastChild),this.appendChild(this.createLoadingScreen()))},400),this._currentLoadProm=c.then(()=>{this._currentLoadProm=void 0,this._currentPage===s&&(p=!0,this._createPanel(i,s,l))},()=>{this._currentLoadProm=void 0})}},{kind:"method",key:"firstUpdated",value:function(e){r(t(o.prototype),"firstUpdated",this).call(this,e);const i=this.routerOptions;i&&(i.preloadAll&&Object.values(i.routes).forEach(e=>"object"==typeof e&&e.load&&e.load()),i.initialLoad&&(setTimeout(()=>{this._initialLoadDone||this.appendChild(this.createLoadingScreen())},400),i.initialLoad().then(()=>{this._initialLoadDone=!0,this.requestUpdate("route")})))}},{kind:"method",key:"createLoadingScreen",value:function(){return document.createElement("hass-loading-screen")}},{kind:"method",key:"createErrorScreen",value:function(e){const t=document.createElement("hass-error-screen");return t.error=e,t}},{kind:"method",key:"rebuild",value:async function(){const e=this.route;void 0!==e&&(this.route=void 0,await this.updateComplete,void 0===this.route&&(this.route=e))}},{kind:"get",key:"pageRendered",value:function(){return this.updateComplete.then(()=>this._currentLoadProm)}},{kind:"method",key:"createElement",value:function(e){return document.createElement(e)}},{kind:"method",key:"updatePageEl",value:function(e,t){}},{kind:"get",key:"routeTail",value:function(){return this._computeTail(this.route)}},{kind:"method",key:"_createPanel",value:function(e,t,r){this.lastChild&&this.removeChild(this.lastChild);const i=this._cache[t]||this.createElement(r.tag);this.updatePageEl(i),this.appendChild(i),(e.cacheAll||r.cache)&&(this._cache[t]=i)}}]}}),S);a([ge("racelandshop-router")],(function(e,i){class o extends i{constructor(...t){super(...t),e(this)}}return{F:o,d:[{kind:"field",decorators:[_e({attribute:!1})],key:"racelandshop",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"configuration",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"critical",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"lovelace",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"removed",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"repositories",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"route",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"status",value:void 0},{kind:"field",decorators:[_e({type:Boolean})],key:"narrow",value:void 0},{kind:"field",decorators:[be()],key:"_wideSidebar",value:()=>!1},{kind:"field",decorators:[be()],key:"_wide",value:()=>!1},{kind:"field",key:"_listeners",value:()=>[]},{kind:"method",key:"connectedCallback",value:function(){r(t(o.prototype),"connectedCallback",this).call(this),this._listeners.push(bs("(min-width: 1040px)",e=>{this._wide=e})),this._listeners.push(bs("(min-width: 1296px)",e=>{this._wideSidebar=e}))}},{kind:"method",key:"disconnectedCallback",value:function(){for(r(t(o.prototype),"disconnectedCallback",this).call(this);this._listeners.length;)this._listeners.pop()()}},{kind:"field",key:"routerOptions",value:()=>({defaultPage:"entry",routes:{entry:{tag:"racelandshop-entry-panel",load:()=>import("./c.88a63ccc.js")},integrations:{tag:"racelandshop-store-panel",load:()=>import("./c.bc715c40.js")},frontend:{tag:"racelandshop-store-panel",load:()=>import("./c.bc715c40.js")},automation:{tag:"racelandshop-store-panel",load:()=>import("./c.bc715c40.js")}}})},{kind:"method",key:"updatePageEl",value:function(e){const t=this.route.path.replace("/",""),r="docked"===this.hass.dockedSidebar?this._wideSidebar:this._wide;e.hass=this.hass,e.racelandshop=this.racelandshop,e.route=this.route,e.narrow=this.narrow,e.isWide=r,e.configuration=this.configuration,e.critical=this.critical,e.lovelace=this.lovelace,e.removed=this.removed,e.repositories=this.repositories,e.status=this.status,e.section=t}}]}}),ml);const gl=y`
  a {
    text-decoration: var(--hcv-text-decoration-link);
    color: var(--hcv-text-color-link);
  }
`,yl=y`
  mwc-button[raised] {
    border-radius: 10px;
  }
`,_l=y`
  paper-menu-button,
  ha-icon {
    color: var(--hcv-color-icon);
  }
`,bl=y`
  hass-tabs-subpage {
    font-family: var(--paper-font-body1_-_font-family);
    -webkit-font-smoothing: var(--paper-font-body1_-_-webkit-font-smoothing);
    font-size: var(--paper-font-body1_-_font-size);
    font-weight: var(--paper-font-body1_-_font-weight);
    line-height: var(--paper-font-body1_-_line-height);
  }
`,vl=y`
  mwc-fab {
    position: fixed;
    bottom: 100px;
    right: 24px;
    z-index: 1;
    margin-bottom: -80px;
    transition: margin-bottom 0.3s;
  }

  mwc-fab[is-wide] {
    bottom: 100px;
    right: 24px;
  }
  mwc-fab[narrow] {
    bottom: 152px;
  }
  mwc-fab[dirty] {
    margin-bottom: 0;
  }

  mwc-fab.rtl {
    right: auto;
    right: 24px;
  }

  mwc-fab[is-wide].rtl {
    bottom: 100px;
    right: auto;
    left: 24px;
  }
`,wl=y`
  search-input.header {
    display: block;
    position: relative;
    left: -22px;
    top: -7px;
    color: var(--secondary-text-color);
    margin-left: 0;
  }
  .search {
    padding: 0 16px;
    background: var(--sidebar-background-color);
    border-bottom: 1px solid var(--divider-color);
  }
  .search search-input {
    position: relative;
    top: 2px;
  }

  search-input {
    --layout-fit_-_right: 100vw;
  }
`,xl=y`
  *::-webkit-scrollbar {
    width: 0.4rem;
    height: 0.4rem;
  }

  *::-webkit-scrollbar-track {
    -webkit-border-radius: 4px;
    border-radius: 4px;
    background: var(--scrollbar-thumb-color);
  }

  *::-webkit-scrollbar-thumb {
    background-color: var(--accent-color);
    border-radius: 0.3em;
  }
  .scroll {
    overflow-y: auto;
    scrollbar-color: var(--scrollbar-thumb-color) transparent;
    scrollbar-width: thin;
  }
`,kl=[Ee,y``],Cl=y`
  .warning {
    color: var(--hcv-color-warning);
  }
  .pending_update {
    color: var(--hcv-color-update);
  }
  .pending_restart,
  .error,
  .uninstall {
    color: var(--hcv-color-error);
    --mdc-theme-primary: var(--hcv-color-error);
  }
  .header {
    font-size: var(--paper-font-headline_-_font-size);
    opacity: var(--dark-primary-opacity);
    padding: 8px 0 4px 16px;
  }
`,Pl=[Ae,_l,yl,Cl,gl],Sl=y`
  :host {
    --hcv-color-error: var(--racelandshop-error-color, var(--google-red-500, #f44336));
    --hcv-color-warning: var(--racelandshop-warning-color, #ff8c00);
    --hcv-color-update: var(--racelandshop-update-color, #f4b400);
    --hcv-color-new: var(--racelandshop-new-color, var(--google-blue-500, #2196f3));
    --hcv-color-icon: var(--racelandshop--default-icon-color, var(--sidebar-icon-color));
    --hcv-color-markdown-background: var(--markdown-code-background-color, #f6f8fa);

    --hcv-text-color-primary: var(--primary-text-color);
    --hcv-text-color-on-background: var(--text-primary-color);
    --hcv-text-color-secondary: var(--secondary-text-color);
    --hcv-text-color-link: var(--link-text-color, var(--accent-color));

    --mdc-dialog-heading-ink-color: var(--hcv-text-color-primary);
    --mdc-dialog-content-ink-color: var(--hcv-text-color-primary);

    /*racelandshop-fab*/
    --hcv-color-fab: var(--racelandshop-fab-color, var(--accent-color));
    --hcv-text-color-fab: var(--racelandshop-fab-text-color, var(--hcv-text-color-on-background));

    /*racelandshop-chip*/
    --hcv-color-chip: var(--racelandshop-chip-color, var(--accent-color));
    --hcv-text-color-chip: var(--racelandshop-chip-text-color, var(--hcv-text-color-on-background));

    /*racelandshop-link*/
    --hcv-text-decoration-link: var(--racelandshop-link-text-decoration, none);
  }
`;a([ge("racelandshop-frontend")],(function(e,i){class o extends i{constructor(...t){super(...t),e(this)}}return{F:o,d:[{kind:"field",decorators:[_e({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"configuration",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"critical",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"lovelace",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"narrow",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"removed",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"repositories",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"route",value:void 0},{kind:"field",decorators:[_e({attribute:!1})],key:"status",value:void 0},{kind:"field",decorators:[xe("#racelandshop-dialog")],key:"_racelandshopDialog",value:void 0},{kind:"field",decorators:[xe("#racelandshop-dialog-secondary")],key:"_racelandshopDialogSecondary",value:void 0},{kind:"method",key:"firstUpdated",value:function(e){r(t(o.prototype),"firstUpdated",this).call(this,e),this.racelandshop.language=this.hass.language,this.addEventListener("racelandshop-location-changed",e=>this._setRoute(e)),this.addEventListener("racelandshop-dialog",e=>this._showDialog(e)),this.addEventListener("racelandshop-dialog-secondary",e=>this._showDialogSecondary(e)),this.hass.connection.subscribeEvents(async()=>await this._updateProperties("configuration"),"racelandshop/config"),this.hass.connection.subscribeEvents(async()=>await this._updateProperties("status"),"racelandshop/status"),this.hass.connection.subscribeEvents(async()=>await this._updateProperties("status"),"racelandshop/stage"),this.hass.connection.subscribeEvents(async()=>await this._updateProperties("repositories"),"racelandshop/repository"),this.hass.connection.subscribeEvents(async()=>await this._updateProperties("lovelace"),"lovelace_updated"),Xe(this,this.shadowRoot),this._updateProperties(),""===this.route.path&&We("/racelandshop/entry",{replace:!0}),this._applyTheme()}},{kind:"method",key:"_updateProperties",value:async function(e="all"){const t={},r={};"all"===e?([r.repositories,r.configuration,r.status,r.critical,r.resources,r.removed]=await Promise.all([wa(this.hass),va(this.hass),ka(this.hass),xa(this.hass),La(this.hass),Ca(this.hass)]),this.lovelace=r.resources,this.repositories=r.repositories):"configuration"===e?r.configuration=await va(this.hass):"status"===e?r.status=await ka(this.hass):"repositories"===e?(r.repositories=await wa(this.hass),this.repositories=r.repositories):"lovelace"===e&&(r.resources=await La(this.hass)),Object.keys(r).forEach(e=>{void 0!==r[e]&&(t[e]=r[e])}),t&&this._updateRacelandshop(t)}},{kind:"method",key:"render",value:function(){return this.hass&&this.racelandshop?G`
      <racelandshop-router
        .hass=${this.hass}
        .racelandshop=${this.racelandshop}
        .route=${this.route}
        .narrow=${this.narrow}
        .configuration=${this.configuration}
        .lovelace=${this.lovelace}
        .status=${this.status}
        .critical=${this.critical}
        .removed=${this.removed}
        .repositories=${this.repositories}
      ></racelandshop-router>
      <racelandshop-event-dialog
        .hass=${this.hass}
        .racelandshop=${this.racelandshop}
        .route=${this.route}
        .narrow=${this.narrow}
        .configuration=${this.configuration}
        .lovelace=${this.lovelace}
        .status=${this.status}
        .removed=${this.removed}
        .repositories=${this.repositories}
        id="racelandshop-dialog"
      ></racelandshop-event-dialog>
      <racelandshop-event-dialog
        .hass=${this.hass}
        .racelandshop=${this.racelandshop}
        .route=${this.route}
        .narrow=${this.narrow}
        .configuration=${this.configuration}
        .lovelace=${this.lovelace}
        .status=${this.status}
        .removed=${this.removed}
        .repositories=${this.repositories}
        id="racelandshop-dialog-secondary"
      ></racelandshop-event-dialog>
    `:G``}},{kind:"get",static:!0,key:"styles",value:function(){return[Pl,Sl]}},{kind:"method",key:"_showDialog",value:function(e){const t=e.detail;this._racelandshopDialog.active=!0,this._racelandshopDialog.params=t,this.addEventListener("racelandshop-dialog-closed",()=>this._racelandshopDialog.active=!1)}},{kind:"method",key:"_showDialogSecondary",value:function(e){const t=e.detail;this._racelandshopDialogSecondary.active=!0,this._racelandshopDialogSecondary.secondary=!0,this._racelandshopDialogSecondary.params=t,this.addEventListener("racelandshop-secondary-dialog-closed",()=>this._racelandshopDialogSecondary.active=!1)}},{kind:"method",key:"_setRoute",value:function(e){this.route=e.detail.route,We(this.route.path,{replace:!0}),this.requestUpdate()}},{kind:"method",key:"_applyTheme",value:function(){var e,t;let r;const i=(null===(e=this.hass.selectedTheme)||void 0===e?void 0:e.theme)||(this.hass.themes.darkMode&&this.hass.themes.default_dark_theme?this.hass.themes.default_dark_theme:this.hass.themes.default_theme);r=this.hass.selectedTheme,"default"===i&&void 0===(null===(t=r)||void 0===t?void 0:t.dark)&&(r={...this.hass.selectedTheme}),qe(this.parentElement,this.hass.themes,i,{...r,dark:this.hass.themes.darkMode}),this.parentElement.style.backgroundColor="var(--primary-background-color)"}}]}}),ys);export{ke as $,ks as A,Ls as B,Ts as C,Es as D,As as E,r as F,t as G,da as H,be as I,Qa as J,Ta as K,xn as L,Ms as M,wa as N,Da as O,Tn as P,We as Q,_a as R,Ra as S,G as T,ms as U,Ea as V,Oa as W,Pa as X,Ge as Y,rl as Z,a as _,fs as a,we as a0,Ks as a1,pl as a2,ls as a3,Ma as a4,Fa as a5,Ha as a6,ve as a7,Gs as a8,$a as a9,Ia as aA,as as aB,bl as aC,vl as aD,Ee as aE,Sa as aa,Ga as ab,Aa as ac,Ja as ad,Ka as ae,Ua as af,qa as ag,ss as ah,ts as ai,to as aj,ti as ak,io as al,al as am,Za as an,Wa as ao,gs as ap,Va as aq,is as ar,ns as as,Ae as at,es as au,Na as av,Os as aw,Is as ax,Ds as ay,Cs as az,Js as b,rs as c,xl as d,_e as e,gn as f,Yr as g,Qn as h,y as i,No as j,me as k,os as l,Ba as m,ge as n,xe as o,Xa as p,Je as q,Pl as r,wl as s,jo as t,rr as u,kl as v,Dr as w,ea as x,ws as y,xs as z};
